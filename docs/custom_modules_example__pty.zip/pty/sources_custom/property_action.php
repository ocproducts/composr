<?php /*

 ocPortal
 Copyright (c) ocProducts, 2004-2008

 You may not distribute a modified version of this file, unless it is solely as an ocPortal modification.
 See text/en/licence.txt for full licencing information.

*/

function add_property_listing($types,$will_buy,$will_rent,$locations,$guide_price,$monthly_rent,$num_bedrooms,$market_position,$features,$further_details,$display_all_details,$display_time_days,$validated,$notes,$submitter=NULL,$add_time=NULL,$edit_time=NULL)
{
	if (is_null($submitter)) $submitter=get_member();
	if (is_null($add_time)) $add_time=time();
	if (is_null($edit_time)) $edit_time=NULL;

	if (!has_specific_permission($submitter,'bypass_validation_midrange_content','property')) $validated=0;

	$id=$GLOBALS['SITE_DB']->query_insert('property_wanted',array(
		'p_will_buy'=>$will_buy,
		'p_will_rent'=>$will_rent,
		'p_guide_price'=>is_null($guide_price)?'':$guide_price,
		'p_monthly_rent'=>is_null($monthly_rent)?'':$monthly_rent,
		'p_num_bedrooms'=>$num_bedrooms,
		'p_market_position'=>$market_position,
		'p_display_all_details'=>$display_all_details,
		'p_display_time_days'=>$display_time_days,
		'p_further_details'=>insert_lang_comcode($further_details,2),
		'p_add_time'=>$add_time,
		'p_edit_time'=>$edit_time,
		'p_validated'=>$validated,
		'p_submitter'=>$submitter,
		'p_notes'=>$notes,
		'p_views'=>0,
		'p_delisting_sent'=>0,
	),true);

	_insert_property_bits($id,$types,$locations,$features);

	log_it('ADD_PROPERTY',strval($id));

	return $id;
}

function _insert_property_bits($id,$types,$locations,$features)
{
	foreach ($types as $type_id=>$settings)
	{
		$GLOBALS['SITE_DB']->query_insert('property_wanted_types',array(
			't_property_id'=>$id,
			't_type_id'=>$type_id,
			't_desired'=>$settings['CHECKED']?1:0,
		));
	}
	
	foreach ($locations as $location_id)
	{
		$GLOBALS['SITE_DB']->query_insert('property_wanted_locations',array(
			'w_property_id'=>$id,
			'w_location_id'=>$location_id,
		));
	}

	foreach ($features as $feature_id=>$settings)
	{
		$GLOBALS['SITE_DB']->query_insert('property_wanted_features',array(
			'f_property_id'=>$id,
			'f_feature_id'=>$feature_id,
			'f_desired'=>$settings['CHECKED']?1:0,
		));
	}
}

function _delete_property_bits($id)
{
	$GLOBALS['SITE_DB']->query_delete('property_wanted_types',array(
		't_property_id'=>$id,
	));
	$GLOBALS['SITE_DB']->query_delete('property_wanted_locations',array(
		'w_property_id'=>$id,
	));
	$GLOBALS['SITE_DB']->query_delete('property_wanted_features',array(
		'f_property_id'=>$id,
	));
}

function edit_property_listing($id,$types,$will_buy,$will_rent,$locations,$guide_price,$monthly_rent,$num_bedrooms,$market_position,$features,$further_details,$display_all_details,$display_time_days,$validated,$notes)
{
	if (!has_specific_permission(get_member(),'bypass_validation_midrange_content','property')) $validated=0;

	$_further_details=$GLOBALS['SITE_DB']->query_value_null_ok('property_wanted','p_further_details',array('id'=>$id));
	if (is_null($_further_details)) warn_exit(do_lang_tempcode('MISSING_RESOURCE'));

	$map=array(
		'p_will_buy'=>$will_buy,
		'p_will_rent'=>$will_rent,
		'p_guide_price'=>is_null($guide_price)?'':$guide_price,
		'p_monthly_rent'=>is_null($monthly_rent)?'':$monthly_rent,
		'p_num_bedrooms'=>$num_bedrooms,
		'p_market_position'=>$market_position,
		'p_display_all_details'=>$display_all_details,
		'p_display_time_days'=>$display_time_days,
		'p_further_details'=>lang_remap_comcode($_further_details,$further_details),
		'p_edit_time'=>time(),
		'p_notes'=>$notes,
		'p_delisting_sent'=>0,
	);
	if (!is_null($validated)) $map['p_validated']=$validated;
	$GLOBALS['SITE_DB']->query_update('property_wanted',$map,array('id'=>$id),'',1);

	_delete_property_bits($id);
	_insert_property_bits($id,$types,$locations,$features);

	log_it('EDIT_PROPERTY',strval($id));
}

function delete_property_listing($id)
{
	$_further_details=$GLOBALS['SITE_DB']->query_value_null_ok('property_wanted','p_further_details',array('id'=>$id));
	if (is_null($_further_details)) warn_exit(do_lang_tempcode('MISSING_RESOURCE'));
	$GLOBALS['SITE_DB']->query_delete('property_wanted',array('id'=>$id),'',1);
	delete_lang($_further_details);

	_delete_property_bits($id);

	log_it('DELETE_PROPERTY',strval($id));
}
