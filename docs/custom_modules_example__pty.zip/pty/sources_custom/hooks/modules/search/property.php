<?php /*

 ocPortal
 Copyright (c) ocProducts, 2004-2008

 You may not distribute a modified version of this file, unless it is solely as an ocPortal modification.
 See text/en/licence.txt for full licencing information.

*/

class Hook_search_property
{
	
	/**
	 * Standard modular info function.
	 *
	 * @return ?array	 Map of module info (NULL: module is disabled).
	 */
	function info()
	{
		$test=$GLOBALS['SITE_DB']->query_value_null_ok('modules','module_version',array('module_the_name'=>'property'));
		if (is_null($test)) return NULL;

		if (!has_actual_page_access(get_member(),'property')) return NULL;

		require_lang('property');
	
		$info=array();
		$info['lang']=do_lang('PROPERTY');
		$info['default']=false;
		$info['category']='p_county';
		$info['integer_category']=false;

		return $info;
	}

	/**
	 * Get a list of entries for the content covered by this search hook. In hierarchical list selection format.
	 *
	 * @param  string			The default selected item
	 * @return tempcode		 Tree structure
	 */
	function get_tree($selected)
	{
		require_code('property');
		$counties=get_counties_for();
		$list=new ocp_tempcode();
		foreach ($counties as $county)
		{
			$list->attach(form_input_list_entry($county,$county==$selected));
		}
		return $list;
	}

	/**
	 * Standard modular run function for search results.
	 *
	 * @param  boolean		Whether to only do a META (tags) search
	 * @param  ID_TEXT		Order direction
	 * @param  integer		Start position in total results
	 * @param  integer		Maximum results to return in total
	 * @param  boolean		Whether only to search titles (as opposed to both titles and content)
	 * @param  string			Where clause that selects the content according to the main search string (SQL query fragment) (blank: full-text search)
	 * @param  SHORT_TEXT	Username/Author to match for
	 * @param  ?MEMBER		Member-ID to match for (NULL: unknown)
	 * @param  TIME			Cutoff date
	 * @param  string			The sort type (gets remapped to a field in this function)
	 * @set    title add_date
	 * @param  array			A list of words for the boolean search
	 * @param  integer		Limit to this number of results
	 * @param  string			What kind of boolean search to do
	 * @set    or and
	 * @param  string			Where constraints known by the main search code (SQL query fragment)
	 * @param  ID_TEXT		Category to search under
	 * @param  BINARY			Whether it is a boolean search
	 * @return array			List of maps (template, orderer)
	 */
	function run($content_explode,$only_search_meta,$direction,$max,$start,$only_titles,$content_where,$author,$author_id,$cutoff,$sort,$content_explode,$limit_to,$boolean_operator,$where_clause,$search_under,$boolean_search)
	{
		require_lang('property');

		$remapped_orderer='';
		switch ($sort)
		{
			case 'add_date':
				$remapped_orderer='p_add_time';
				break;
		}

		// Calculate our where clause (search)
		$sq=build_search_submitter_clauses('p_submitter',$author_id,$author);
		if (is_null($sq)) return array(); else $where_clause.=$sq;
		if (!is_null($cutoff))
		{
			if ($where_clause!='') $where_clause.=' AND ';
			$where_clause.='p_add_time>'.$cutoff;
		}

		// Calculate and perform query
		$rows=get_search_rows(NULL,NULL,$content_explode,$only_search_meta,$direction,$max,$start,$only_titles,'property_wanted r LEFT JOIN '.get_table_prefix().'property_wanted_locations w ON w.w_property_id=r.id LEFT JOIN '.get_table_prefix().'property_locations l ON l.id=w.w_location_id',array(),$where_clause,$content_where,$remapped_orderer,'r.*',array('l.l_county','l.l_outcode','l.l_town','r.p_further_details'));

		$out=array();
		$done=array();
		foreach ($rows as $i=>$row)
		{
			if (in_array($row['id'],$done)) { unset($out[$i]); continue; } //$out[$i]['data']['restricted']=true;
			$out[$i]['data']=$row;
			if ($remapped_orderer!='') $out[$i]['orderer']=$row[$remapped_orderer];
			$done[]=$row['id'];
		}

		return $out;
	}

	/**
	 * Standard modular run function for rendering a search result.
	 *
	 * @param  array		 The data row stored when we retrieved the result
	 * @return tempcode	 The output
	 */
	function render($row)
	{
		require_code('property');
		return render_property_wanted_box($row,false,get_property_types($row['id']),get_property_features($row['id']),get_property_locations($row['id']));
	}

}
