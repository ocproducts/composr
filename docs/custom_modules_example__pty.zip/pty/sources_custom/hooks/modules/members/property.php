<?php /*

 ocPortal
 Copyright (c) ocProducts, 2004-2006

 You may not distribute a modified version of this file, unless it is solely as an ocPortal modification.
 See text/en/licence.txt for full licencing information.

*/

class Hook_members_property
{

	/**
	 * Standard modular run function.
	 *
	 * @param  MEMBER			The ID of the member we are getting link hooks for
	 * @return array			List of tuples for results. Each tuple is: type,title,url
	 */
	function run($member_id)
	{
		//removed-assert

		if (!has_actual_page_access(get_member(),'property',get_module_zone('property'))) return array();

		require_lang('property');

		$username=$GLOBALS['FORUM_DRIVER']->get_username($member_id);

		$result=array();
		if (has_actual_page_access(get_member(),'search')) $result[]=array('content',do_lang('PROPERTY_SEARCH'),build_url(array('page'=>'search','type'=>'results','content'=>'','days'=>-1,'sort'=>'','direction'=>'ASC','author'=>$username,'id'=>'property'),get_module_zone('search')));
		$result[]=array('content',do_lang('PROPERTY_PROFILE'),build_url(array('page'=>'property','type'=>'my_listings','member_id'=>$member_id),get_module_zone('property')));
		
		return $result;
	}

}
