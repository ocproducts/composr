<?php /*

 ocPortal
 Copyright (c) ocProducts, 2004-2008

 You may not distribute a modified version of this file, unless it is solely as an ocPortal modification.
 See text/en/licence.txt for full licencing information.

*/

class Hook_cron_propertys_entry_timeouts
{
	/**
	 * Standard modular run function for CRON hooks. Searches for tasks to perform.
	 */
	function run()
	{
		// Warnings
		$spec=' AND (p_add_time<'.strval(time()).'-(p_display_time_days-5)*60*60*24 AND (p_edit_time IS NULL OR p_edit_time<'.strval(time()).'-(p_display_time_days-5)*60*60*24))';
		$query='SELECT id,p_submitter FROM '.$GLOBALS['SITE_DB']->get_table_prefix().'property_wanted WHERE p_validated=1 AND p_delisting_sent=0'.$spec;
		$rows=$GLOBALS['SITE_DB']->query($query);
		if (count($rows)!=0)
		{
			require_code('mail');
			require_lang('property');
			foreach ($rows as $row)
			{
				$GLOBALS['SITE_DB']->query_update('property_wanted',array('p_delisting_sent'=>1),array('id'=>$row['id']),'',1);
				
				$to_email=$GLOBALS['FORUM_DRIVER']->get_member_email_address($row['p_submitter']);
				$to_name=$GLOBALS['FORUM_DRIVER']->get_username($row['p_submitter']);
				$subject_tag=do_lang('MAIL_WARNING_TIMEOUT_SUBJECT');
				$edit_url=build_url(array('page'=>'property','type'=>'_ed','id'=>$row['id']),get_module_zone('property'));
				if (is_object($edit_url)) $edit_url=$edit_url->evaluate();
				$renew_url=build_url(array('page'=>'property','type'=>'_renew','id'=>$row['id']),get_module_zone('property'));
				if (is_object($renew_url)) $renew_url=$renew_url->evaluate();
				$feedback_url=build_url(array('page'=>'feedback'),'');
				if (is_object($feedback_url)) $feedback_url=$feedback_url->evaluate();
				$message_raw=do_lang('MAIL_WARNING_TIMEOUT_BODY',$renew_url,$edit_url,$feedback_url);
				mail_wrap($subject_tag,$message_raw,array($to_email),$to_name);
			}
		}
		
		// Actual de-listing
		$spec=' AND (p_add_time<'.strval(time()).'-(p_display_time_days)*60*60*24 AND (p_edit_time IS NULL OR p_edit_time<'.strval(time()).'-(p_display_time_days)*60*60*24))';
		$query='UPDATE '.$GLOBALS['SITE_DB']->get_table_prefix().'property_wanted SET p_validated=0 WHERE p_validated=1'.$spec;
		$GLOBALS['SITE_DB']->query($query);
	}

}

