<?php /*

 ocPortal
 Copyright (c) ocProducts, 2004-2008

 You may not distribute a modified version of this file, unless it is solely as an ocPortal modification.
 See text/en/licence.txt for full licencing information.

*/

class Hook_cron_property_email_alerts
{
	/**
	 * Standard modular run function for CRON hooks. Searches for tasks to perform.
	 */
	function run()
	{
		$time=time();

		$last_alert_send_time=get_value('last_alert_send_time');
		if ((is_null($last_alert_send_time)) || ((intval($last_alert_send_time)<$time-60*60*24) && (intval(date('H',$time))==3))) // daily, 3-4AM
		{
			require_code('mail');
			require_lang('property');
			require_code('ocf_groups');
			require_code('property');
			
			$detached_feature_id=$GLOBALS['SITE_DB']->query_value('property_features','id',array('f_text'=>do_lang('DETACHED')));

			// For all members receiving alerts
			$all_members=$GLOBALS['FORUM_DB']->query_select('f_members m LEFT JOIN '.$GLOBALS['FORUM_DB']->get_table_prefix().'f_member_custom_fields f ON m.id=f.mf_member_id',array('m.id','f.*'),array('field_27'=>'1')); /* field_27 is for the "I want emails" tickbox */
			foreach ($all_members as $member)
			{
				if ($member['id']==$GLOBALS['FORUM_DRIVER']->get_guest_id()) continue;
				
				// Read in filters from CPF's 
				$buy_filter=($member['field_28']=='Property for sale only')?1:NULL;
				$rent_filter=($member['field_28']=='Property for rent only')?1:NULL;
				$lowlevel_region_filter=($member['field_29']=='')?array():explode('|',$member['field_29']);
				$type_filter=($member['field_30']=='Any')?NULL:$GLOBALS['SITE_DB']->query_value_null_ok('property_types','id',array('t_text'=>$member['field_30']));
				$guide_price_filter=$member['field_31'];
				if (($guide_price_filter=='Any') || ($guide_price_filter=='')) $guide_price_filter=NULL;
				$num_bedrooms_filter=$member['field_32'];
				if (($num_bedrooms_filter=='Any') || ($num_bedrooms_filter=='')) $num_bedrooms_filter=NULL;
				$features_filter=array();
				//if (($member['field_33']!="I don't mind") && ($member['field_33']!='')) $features_filter[$detached_feature_id]=($member['field_33']=='Lister specified detached');
				if ($member['field_33']=="1") $features_filter[$detached_feature_id]=true;

				// Get and process all new properties matching filters and thus requiring alerts
				list($new_properties,)=get_property_wanted_rows(0,NULL,$buy_filter,$rent_filter,$type_filter,'',$features_filter,'id','DESC',$lowlevel_region_filter,is_null($last_alert_send_time)?($time-60*60*24):intval($last_alert_send_time),1,$guide_price_filter,$num_bedrooms_filter);
				if (count($new_properties)!=0)
				{
					$_new_listings='';
					foreach ($new_properties as $i=>$property)
					{
						$url=build_url(array('page'=>'property','type'=>'view','id'=>$property['id']),get_page_zone('property'));
						if (is_object($url)) $url=$url->evaluate();
						$username=$GLOBALS['FORUM_DRIVER']->get_username($property['p_submitter']);
						$primary_group_name=get_translated_text(ocf_get_group_property($GLOBALS['FORUM_DRIVER']->get_member_row_field($property['p_submitter'],'m_primary_group'),'name'),$GLOBALS['FORUM_DB']);
						$_new_listings.=$url.chr(10).chr(10);//do_lang('P_ADMIN_BY',$url,$username,$primary_group_name).chr(10).chr(10);
					}

					$edit_profile_link=build_url(array('page'=>'editprofile','type'=>'misc','id'=>$member['id']),get_module_zone('editprofile'));
					if (is_object($edit_profile_link)) $edit_profile_link=$edit_profile_link->evaluate();
					$mail=do_lang('NEW_LISTINGS_ADDED_MESSAGE',$_new_listings,$edit_profile_link);
					mail_wrap(do_lang('NEW_LISTINGS_ADDED_SUBJECT'),$mail);
				}
			}

			// Mark that we finished at this time
			set_value('last_alert_send_time',strval($time));
		}
	}

}

