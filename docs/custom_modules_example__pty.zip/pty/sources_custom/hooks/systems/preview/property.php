<?php /*

 ocPortal
 Copyright (c) ocProducts, 2004-2008

 You may not distribute a modified version of this file, unless it is solely as an ocPortal modification.
 See text/en/licence.txt for full licencing information.

*/

class Hook_Preview_property
{

	/**
	 * Find whether this preview hook applies.
	 *
	 * @return array			 Triplet: Whether it applies, the attachment ID type, whether the forum DB is used [optional]
	 */
	function applies()
	{
		$applies=(get_param('page')=='property');
		return array($applies,'');
	}

	/**
	 * Standard modular run function for preview hooks.
	 *
	 * @return array			A pair: The preview, NULL
	 */
	function run()
	{
		require_lang('property');
		require_css('property');
		require_code('property');

		$myrow=array(
			'id'=>NULL,
			'p_will_buy'=>post_param_integer('will_buy',0),
			'p_will_rent'=>post_param_integer('will_rent',0),
			'p_guide_price'=>post_param('guide_price',''),
			'p_monthly_rent'=>post_param('monthly_rent',''),
			'p_num_bedrooms'=>post_param('num_bedrooms'),
			'p_market_position'=>post_param('market_position'),
			'p_display_all_details'=>post_param_integer('display_all_details',0),
			'p_display_time_days'=>post_param_integer('display_time_days'),
			'p_further_details'=>post_param('further_details'),
			'p_add_time'=>time(),
			'p_edit_time'=>NULL,
			'p_validated'=>1,
			'p_submitter'=>get_member(),
			'p_notes'=>post_param('notes',''),
			'p_views'=>NULL,
		);

		$features=get_property_features();
		$types=get_property_types();
		$locations=get_property_locations();

		return array(render_property_wanted_box($myrow,true,$types,$features,$locations),NULL);
	}

}

