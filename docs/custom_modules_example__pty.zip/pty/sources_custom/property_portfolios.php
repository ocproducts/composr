<?php /*

 ocPortal
 Copyright (c) ocProducts, 2004-2008

 You may not distribute a modified version of this file, unless it is solely as an ocPortal modification.
 See text/en/licence.txt for full licencing information.

*/

/**
 * Get a list of possible property portfolio features, and their set status.
 *
 * @param  ?AUTO_LINK	Property portfolio ID (NULL: we read from environment as per status after a search/add/edit)
 * @return array			List of features
 */
function get_property_portfolio_features($id=NULL)
{
	$features=array();
	
	if (!is_null($id))
	{
		$current=collapse_1d_complexity('f_feature_id',$GLOBALS['SITE_DB']->query_select('property_pfolio_features',array('f_feature_id'),array('f_portfolio_id'=>$id,'f_has'=>1)));
	}

	$rows=$GLOBALS['SITE_DB']->query_select('property_features',array('id','f_text','f_displayed'));
	foreach ($rows as $row)
	{
		if (!is_null($id))
		{
			$checked=in_array($row['id'],$current);
		} elseif (array_key_exists('features',$_POST))
		{
			$checked=in_array(strval($row['id']),$_POST['features']);
		} else
		{
			$checked=either_param_integer('feature_'.strval($row['id']),0)==1;
		}
		$features[]=array('_ID'=>strval($row['id']),'DISPLAY'=>strval($row['f_displayed']),'CHECKED'=>$checked,'TEXT'=>$row['f_text']);
	}

	return $features;
}

function add_property_portfolio($for,$features,$type,$address,$asking_price,$monthly_rent,$num_bedrooms,$further_details,$further_details_link,$photo_main,$photo_aux_1,$photo_aux_2,$photo_aux_3,$photo_main_thumb,$photo_aux_1_thumb,$photo_aux_2_thumb,$photo_aux_3_thumb,$submitter=NULL,$add_time=NULL)
{
	if (is_null($submitter)) $submitter=get_member();
	if (is_null($add_time)) $add_time=time();

	if (!has_specific_permission($submitter,'bypass_validation_midrange_content','property')) $validated=0;

	$id=$GLOBALS['SITE_DB']->query_insert('property_portfolio',array(
		'o_for'=>$for,
		'o_asking_price'=>is_null($asking_price)?'':$asking_price,
		'o_monthly_rent'=>is_null($monthly_rent)?'':$monthly_rent,
		'o_address'=>$address,
		'o_type'=>$type,
		'o_num_bedrooms'=>$num_bedrooms,
		'o_further_details'=>insert_lang_comcode($further_details,2),
		'o_further_details_link'=>$further_details_link,
		'o_photo_main'=>$photo_main,
		'o_photo_aux_1'=>$photo_aux_1,
		'o_photo_aux_2'=>$photo_aux_2,
		'o_photo_aux_3'=>$photo_aux_3,
		'o_photo_main_thumb'=>$photo_main_thumb,
		'o_photo_aux_1_thumb'=>$photo_aux_1_thumb,
		'o_photo_aux_2_thumb'=>$photo_aux_2_thumb,
		'o_photo_aux_3_thumb'=>$photo_aux_3_thumb,
		'o_add_time'=>$add_time,
		'o_member_id'=>$submitter,
	),true);

	foreach ($features as $feature_id=>$has)
	{
		$GLOBALS['SITE_DB']->query_insert('property_pfolio_features',array(
			'f_portfolio_id'=>$id,
			'f_feature_id'=>$feature_id,
			'f_has'=>$has['CHECKED']?1:0,
		));
	}

	return $id;
}

/**
 * Handle uploading and resizing for photos of property.
 *
 * @return array			A tuple of the uploads and thumbnails
 */
function handle_property_portfolio_uploading()
{
	require_code('uploads');
	require_code('images');

	$temp=get_url('photo_main_url','photo_main','uploads/website_specific/pty/property_images',0,OCP_UPLOAD_IMAGE,true);
	if ($temp[0]!='') list($photo_main,$photo_main_thumb)=$temp; else list($photo_main,$photo_main_thumb)=array('','');
	$temp=get_url('photo_aux_1_url','photo_aux_1','uploads/website_specific/pty/property_images',0,OCP_UPLOAD_IMAGE,true);
	if ($temp[0]!='') list($photo_aux_1,$photo_aux_1_thumb)=$temp; else list($photo_aux_1,$photo_aux_1_thumb)=array('','');
	$temp=get_url('photo_aux_2_url','photo_aux_2','uploads/website_specific/pty/property_images',0,OCP_UPLOAD_IMAGE,true);
	if ($temp[0]!='') list($photo_aux_2,$photo_aux_2_thumb)=$temp; else list($photo_aux_2,$photo_aux_2_thumb)=array('','');
	$temp=get_url('photo_aux_3_url','photo_aux_3','uploads/website_specific/pty/property_images',0,OCP_UPLOAD_IMAGE,true);
	if ($temp[0]!='') list($photo_aux_3,$photo_aux_3_thumb)=$temp; else list($photo_aux_3,$photo_aux_3_thumb)=array('','');

	$editing_from=post_param_integer('editing_from',NULL);
	if (!is_null($editing_from))
	{
		$rows=$GLOBALS['SITE_DB']->query_select('property_portfolio',array('*'),array('id'=>$editing_from),'',1);
		$row=$rows[0];
		if ((post_param_integer('photo_main_unlink',0)!=1) && ($photo_main==''))
		{
			$photo_main=$row['o_photo_main'];
			$photo_main_thumb=$row['o_photo_main_thumb'];
		}
		if ((post_param_integer('photo_aux_1_unlink',0)!=1) && ($photo_aux_1==''))
		{
			$photo_aux_1=$row['o_photo_aux_1'];
			$photo_aux_1_thumb=$row['o_photo_aux_1_thumb'];
		}
		if ((post_param_integer('photo_aux_2_unlink',0)!=1) && ($photo_aux_2==''))
		{
			$photo_aux_2=$row['o_photo_aux_2'];
			$photo_aux_2_thumb=$row['o_photo_aux_2_thumb'];
		}
		if ((post_param_integer('photo_aux_3_unlink',0)!=1) && ($photo_aux_3==''))
		{
			$photo_aux_3=$row['o_photo_aux_3'];
			$photo_aux_3_thumb=$row['o_photo_aux_3_thumb'];
		}
	}

	return array($photo_main,$photo_aux_1,$photo_aux_2,$photo_aux_3,$photo_main_thumb,$photo_aux_1_thumb,$photo_aux_2_thumb,$photo_aux_3_thumb);
}
