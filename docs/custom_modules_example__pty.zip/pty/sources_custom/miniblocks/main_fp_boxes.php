<?php

$tpl=request_page('_box_big_boys_summary',true,'site','comcode_custom',true);
$big_boys_summary=$tpl->evaluate();
$tpl=request_page('_box_private_adverts_summary',true,'site','comcode_custom',true);
$private_adverts_summary=$tpl->evaluate();
$tpl=request_page('_box_social_housing_summary',true,'site','comcode_custom',true);
$social_housing_summary=$tpl->evaluate();
$tpl=request_page('_box_special_needs_summary',true,'site','comcode_custom',true);
$special_needs_summary=$tpl->evaluate();

$_big_boys_url=build_url(array('page'=>'big_boys'),'site');
if (is_object($_big_boys_url)) $_big_boys_url=$_big_boys_url->evaluate();
$big_boys_url=escape_html($_big_boys_url);
$_private_adverts_url=build_url(array('page'=>'private_adverts'),'site');
if (is_object($_private_adverts_url)) $_private_adverts_url=$_private_adverts_url->evaluate();
$private_adverts_url=escape_html($_private_adverts_url);
$_social_housing_url=build_url(array('page'=>'social_housing'),'site');
if (is_object($_social_housing_url)) $_social_housing_url=$_social_housing_url->evaluate();
$social_housing_url=escape_html($_social_housing_url);
$_special_needs_url=build_url(array('page'=>'special_needs'),'site');
if (is_object($_special_needs_url)) $_special_needs_url=$_special_needs_url->evaluate();
$special_needs_url=escape_html($_special_needs_url);

echo <<<END
<table class="fp_boxes" cellspacing="0" cellpadding="0" summary="">
	<tr>
		<td class="fp_boxes_top">
			&nbsp;
		</td>

		<td class="fp_boxes_top">
			&nbsp;
		</td>
	</tr>

	<tr>
		<td class="fp_boxes_middle">
			<p style="font-weight: bold; text-align: center; margin-top: 0">The Big Boys</p>
			<p>
				{$big_boys_summary}
			</p>
		</td>

		<td class="fp_boxes_middle">
			<p style="font-weight: bold; text-align: center; margin-top: 0">The Specialists</p>
			<p>
				{$special_needs_summary}
			</p>
		</td>
	</tr>

	<tr>
		<td class="fp_boxes_bottom">
			<p class="link"><a href="{$big_boys_url}">View</a></p>
		</td>

		<td class="fp_boxes_bottom">
			<p class="link"><a href="{$special_needs_url}">View</a></p>
		</td>
	</tr>



	<tr>
		<td class="fp_boxes_top">
			&nbsp;
		</td>

		<td class="fp_boxes_top">
			&nbsp;
		</td>
	</tr>

	<tr>
		<td class="fp_boxes_middle">
			<p style="font-weight: bold; text-align: center; margin-top: 0">The Private Advertisers</p>
			<p>
				{$private_adverts_summary}
			</p>
		</td>

		<td class="fp_boxes_middle">
			<p style="font-weight: bold; text-align: center; margin-top: 0">Social Housing</p>
			<p>
				{$social_housing_summary}
			</p>
		</td>
	</tr>

	<tr>
		<td class="fp_boxes_bottom">
			<p class="link"><a href="{$private_adverts_url}">View</a></p>
		</td>

		<td class="fp_boxes_bottom">
			<p class="link"><a href="{$social_housing_url}">View</a></p>
		</td>
	</tr>
</table>
END;
