<?php /*

 ocPortal
 Copyright (c) ocProducts, 2004-2008

 You may not distribute a modified version of this file, unless it is solely as an ocPortal modification.
 See text/en/licence.txt for full licencing information.

*/

/**
 * Get a list of possible property features, and their set status.
 *
 * @param  ?AUTO_LINK	Property ID (NULL: we read from environment as per status after a search/add/edit)
 * @return array			List of features
 */
function get_property_features($id=NULL)
{
	$features=array();
	
	if (!is_null($id))
	{
		$current=collapse_1d_complexity('f_feature_id',$GLOBALS['SITE_DB']->query_select('property_wanted_features',array('f_feature_id'),array('f_property_id'=>$id,'f_desired'=>1)));
	} else
	{
		$current=array();
	}

	$rows=$GLOBALS['SITE_DB']->query_select('property_features',array('id','f_text','f_displayed'));
	foreach ($rows as $row)
	{
		if (!is_null($id))
		{
			$checked=in_array($row['id'],$current);
		} elseif (array_key_exists('features',$_POST))
		{
			$checked=in_array(strval($row['id']),$_POST['features']);
		} else
		{
			$checked=either_param_integer('feature_'.strval($row['id']),0)==1;
		}
		$row['f_displayed']=1; // 27/01/09. Client asked for all to display.
		$features[$row['id']]=array('_ID'=>strval($row['id']),'DISPLAY'=>strval($row['f_displayed']),'CHECKED'=>$checked,'TEXT'=>$row['f_text']);
	}

	return $features;
}

/**
 * Get a list of possible property types, and their set status.
 *
 * @param  ?AUTO_LINK	Property ID (NULL: we read from environment as per status after a search/add/edit)
 * @return array			List of features
 */
function get_property_types($id=NULL)
{
	$types=array();

	if (!is_null($id))
	{
		$current=collapse_1d_complexity('t_type_id',$GLOBALS['SITE_DB']->query_select('property_wanted_types',array('t_type_id'),array('t_property_id'=>$id,'t_desired'=>1)));
	} else
	{
		$current=array();
	}
	
	$rows=$GLOBALS['SITE_DB']->query_select('property_types',array('id','t_text'));
	foreach ($rows as $row)
	{
		if (!is_null($id))
		{
			$checked=in_array($row['id'],$current);
		} elseif (array_key_exists('types',$_POST))
		{
			$checked=in_array(strval($row['id']),$_POST['types']);
		} else
		{
			$checked=either_param_integer('type_'.strval($row['id']),0)==1;
		}
		$types[$row['id']]=array('_ID'=>strval($row['id']),'CHECKED'=>$checked,'TEXT'=>$row['t_text']);
	}

	return $types;
}

/**
 * Get a list of chosen property locations.
 *
 * @param  ?AUTO_LINK	Property ID (NULL: we read from environment as per status after a search/add/edit)
 * @return array			List of locations
 */
function get_property_locations($id=NULL)
{
	$locations=array();

	if (!is_null($id))
	{
		return collapse_1d_complexity('w_location_id',$GLOBALS['SITE_DB']->query_select('property_wanted_locations',array('w_location_id'),array('w_property_id'=>$id)));
	}

	if (array_key_exists('locations',$_POST))
	{
		foreach ($_POST['locations'] as $val)
		{
			if (is_numeric($val)) // Simple, by location ID
			{
				$locations[]=intval($val);
			} else // By post code
			{
				$l=$GLOBALS['SITE_DB']->query_select('property_locations',array('id'),array('l_outcode'=>$val));
				$locations=array_merge($locations,collapse_1d_complexity('id',$l));
			}
		}
	} else
	{
		foreach ($_POST as $key=>$val)
		{
			if (substr($key,0,9)=='location_')
			{
				if (is_numeric(substr($key,9))) // Simple, by location ID
				{
					$locations[]=intval(substr($key,9));
				} else // By post code
				{
					$l=$GLOBALS['SITE_DB']->query_select('property_locations',array('id'),array('l_outcode'=>substr($key,9)));
					$locations=array_merge($locations,collapse_1d_complexity('id',$l));
				}
			}
		}
	}

	return $locations;
}

/**
 * Render a box for a property-wanted listing.
 *
 * @param  array			The db row
 * @param  boolean		Whether to render a full view instead
 * @param  array			Types to render
 * @param  array			Features to render
 * @param  array			Locations to render
 * @param  ?ID_TEXT		The higher-level region (NULL: unknown)
 * @return tempcode		The rendered box
 */
function render_property_wanted_box($row,$render_view,$types,$features,$locations,$l=NULL)
{
	require_css('property');

	$full_url=build_url(array('page'=>'property','type'=>'view','id'=>$row['id'],'l'=>$l),get_module_zone('property'));
	$respond_url=build_url(array('page'=>'property','type'=>'respond','id'=>$row['id']),get_module_zone('property'));

	$map=array(
		'ID'=>strval($row['id']),
		'FULL_URL'=>$full_url,
		'STAFF_NOTES'=>$row['p_notes'],
		'NUM_BEDROOMS'=>do_lang('NB_'.$row['p_num_bedrooms']),
		'MARKET_POSITION'=>do_lang('MP_'.$row['p_market_position']),
		'WILL_BUY'=>$row['p_will_buy']==1,
		'WILL_RENT'=>$row['p_will_rent']==1,
		'BUY_PRICE'=>$row['p_guide_price'],
		'RENT_PRICE'=>$row['p_monthly_rent'],
		'FURTHER_DETAILS'=>is_integer($row['p_further_details'])?get_translated_tempcode($row['p_further_details']):comcode_to_tempcode($row['p_further_details']),
		'SUBMITTER'=>strval($row['p_submitter']),
		'RESPOND_URL'=>$respond_url,
		'DISPLAY_ALL_DETAILS'=>strval($row['p_display_all_details']),

		'TYPES'=>$types,
		'FEATURES'=>$features,
		'LOCATIONS'=>compile_locations($locations,!$render_view),
	);

	if ($render_view)
	{
		$before=$GLOBALS['SITE_DB']->query_value_null_ok('property_portfolio','o_add_time',array('o_for'=>$row['id']));
		$map['RESPONDED_BEFORE']=is_null($before)?NULL:get_timezoned_date($before);
	}

	return do_template($render_view?'PROPERTY_VIEW':'PROPERTY_BOX',$map);
}

// Get ready for templating
function compile_locations($locations,$short_wanted=false)
{
	if (count($locations)==0) return array();
	
	$tpl=array();
	$or_list='';
	foreach ($locations as $l)
	{
		if ($or_list!='') $or_list.=' OR ';
		$or_list.='id='.strval($l);
	}
	$query='SELECT * FROM '.get_table_prefix().'property_locations WHERE '.$or_list;
	$rows=$GLOBALS['SITE_DB']->query($query);
	$db_rows=list_to_map('id',$rows);

	$outcodes=array();
	foreach ($locations as $l)
	{
		if (!array_key_exists($db_rows[$l]['l_outcode'],$outcodes)) $outcodes[$db_rows[$l]['l_outcode']]=array();
		$outcodes[$db_rows[$l]['l_outcode']][]=$db_rows[$l];
	}
	uksort($outcodes,'_outcode_sorter');
	//ksort($outcodes,SORT_NUMERIC);
	foreach ($outcodes as $outcode=>$outcode_rows)
	{
		$text='<strong>'.escape_html($outcode).'</strong>';
		$t_text='';
		$checked=false;
		if ((!$short_wanted) || (count($outcodes)<8))
		{
			foreach ($outcode_rows as $row)
			{
				$checked=in_array($row['id'],$locations);

				if ($row['l_town']!='')
				{
					if ($t_text!='') $t_text.=', ';
					$t_text.='<em>'.str_replace(' ','&nbsp;',escape_html($row['l_town'])).'</em>';
				}
			}
			if ($t_text!='') $text.=' ('.$t_text.')';
		}

		$tpl[]=array(
			'L_ID'=>strval($l),
			'L_TEXT'=>protect_from_escaping($text),
			'L_OUTCODE'=>$outcode,
		);
	}

	return $tpl;
}

/**
 * Get a map betweeen regions and the number of property listed underneath.
 *
 * @param  ?BINARY		How to filter to only those that are 'will buy' (NULL: no filter)
 * @param  ?BINARY		How to filter to only those that are 'will rent' (NULL: no filter)
 * @param  ?AUTO_LINK	Property-type filter (NULL: no filter)
 * @return array			Map: machine region code=>num of property listed
 */
function get_region_data($buy_filter,$rent_filter,$type_filter=NULL)
{
	$region_data=array();
	$regions=get_county_map();
	$where_map=array('p_validated'=>1);
	if (!is_null($buy_filter)) $where_map['p_will_buy']=$buy_filter;
	if (!is_null($rent_filter)) $where_map['p_will_rent']=$rent_filter;
	$join=' LEFT JOIN '.get_table_prefix().'property_wanted_locations w ON p.id=w_property_id';
	$join.=' LEFT JOIN '.get_table_prefix().'property_locations l ON l.id=w_location_id';
	if (!is_null($type_filter))
	{
		$where_map['t.t_type_id']=$type_filter;
		$where_map['t.t_desired']=1;
		$join.=' LEFT JOIN '.get_table_prefix().'property_wanted_types t ON p.id=t.t_type_id';
	}
	$results=$GLOBALS['SITE_DB']->query_select('property_wanted p'.$join,array('l_county'),$where_map,'GROUP BY p.id');
	$all_data=array_count_values(collapse_1d_complexity('l_county',$results));
	foreach ($regions as $region=>$counties)
	{
		$region=str_replace(' ','_',$region); // This is converting the human-readable region code into a machine one. As used in PROPERTY_MAP template.
		$region_data[$region]=0;
		foreach ($counties as $county=>$val)
		{
			$region_data[$region]+=array_key_exists($county,$all_data)?$all_data[$county]:0;
		}
		$region_data[$region]=strval($region_data[$region]);
	}
	return $region_data;
}

/**
 * Get a map betweeen regions and possible counties.
 *
 * @return array			Map: region=>list of counties
 */
function get_county_map()
{
	/* NB: Choice of counties dictated by the address data we had available for free. */
	/* NB: We can assume all lower-level region names are globally unique. */

	$data=array(
		'Scotland'=>array('Inverclyde'=>1,'Renfrewshire'=>1,'West Dunbartonshire'=>1,'East Dunbartonshire'=>1,'Glasgow City'=>1,'East Renfrewshire'=>1,'North Lanarkshire'=>1,'Falkirk'=>1,'West Lothian'=>1,'City of Edinburgh'=>1,'Midlothian'=>1,'East Lothian'=>1,'Clackmannanshire'=>1,'Fife'=>1,'Dundee City'=>1,'Angus'=>1,'Aberdeenshire'=>1,'Aberdeen City'=>1,'Moray'=>1,'Highland and Isle of Skye'=>1,'Western Isles'=>1,'Argyll and Bute'=>1,'Perth and Kinross'=>1,'Stirling'=>1,'North Ayrshire'=>1,'East Ayrshire'=>1,'South Ayrshire'=>1,'Dumfries and Galloway'=>1,'South Lanarkshire'=>1,'Scottish Borders'=>1,'Orkney Islands'=>1,'Shetland Islands'=>1,), // http://en.wikipedia.org/wiki/Council_Areas_of_Scotland=http://en.wikipedia.org/wiki/Subdivisions_of_Scotland [NOT http://en.wikipedia.org/wiki/Lieutenancy_areas_of_Scotland OR http://en.wikipedia.org/wiki/Registration_county OR http://en.wikipedia.org/wiki/Large_burghs OR http://en.wikipedia.org/wiki/Regions_and_districts_of_Scotland OR http://en.wikipedia.org/wiki/Counties_of_Scotland]
		'Northern Ireland'=>array('County Antrim'=>1,'County Armagh'=>1,'County Down'=>1,'County Fermanagh'=>1,'County Londonderry'=>1,'County Tyrone'=>1),
		'Wales'=>array('Merthyr Tydfil'=>1,'Caerphilly'=>1,'Blaenau Gwent'=>1,'Torfae'=>1,'Monmouthshire'=>1,'Newport'=>1,'Cardiff'=>1,'Vale of Glamorgan'=>1,'Bridgend'=>1,'Rhondda Cynon Taff'=>1,'Neath Port Talbot'=>1,'Swansea'=>1,'Carmarthenshire'=>1,'Ceredigion'=>1,'Powys'=>1,'Wrexham'=>1,'Flintshire'=>1,'Denbighshire'=>1,'Conwy'=>1,'Gwynedd'=>1,'Isle of Anglesey'=>1,'Pembrokeshire'=>1), // http://en.wikipedia.org/wiki/Administrative_divisions_of_Wales [NOT http://en.wikipedia.org/wiki/Preserved_counties_of_Wales OR http://en.wikipedia.org/wiki/Historic_counties_of_Wales]

		// http://en.wikipedia.org/wiki/Metropolitan_and_non-metropolitan_counties_of_England
		// except Herefordshire+Worcestershire are combined
		// and the following towns weren't promoted to counties: Blackpool, Blackburn with Darwen, Nottingham, Derby, Halton, Warrington, Telford and Wrekin, Leicester, Southend-on-Sea, Thurrock, Luton, Swindon, Medway, Torbay, Plymouth
		// [NOT http://en.wikipedia.org/wiki/Ceremonial_counties_of_England OR http://en.wikipedia.org/wiki/County_borough]
		'North East'=>array('Darlington'=>1,'Middlesbrough'=>1,'Hartlepool'=>1,'Stockton-on-Tees'=>1,'Redcar and Cleveland'=>1,'Northumberland'=>1,'Tyne and Wear'=>1,'County Durham'=>1),
		'North West'=>array('Cheshire'=>1,'Cumbria'=>1,'Greater Manchester'=>1,'Lancashire'=>1,'Merseyside'=>1),
		'Yorkshire and the Humber'=>array('York'=>1,'Kingston upon Hull'=>1,'South Yorkshire'=>1,'West Yorkshire'=>1,'North Yorkshire'=>1,'East Riding of Yorkshire'=>1),
		'East Midlands'=>array('North Lincolnshire'=>1,'North East Lincolnshire'=>1,'Derbyshire'=>1,'Nottinghamshire'=>1,'Lincolnshire'=>1,'Leicestershire'=>1,'Rutland'=>1,'Northamptonshire'=>1),
		'West Midlands'=>array('Hereford and Worcester'=>1,'Shropshire'=>1,'Staffordshire'=>1,'Warwickshire'=>1,'West Midlands county'=>1),
		'East'=>array('Bedfordshire'=>1,'Cambridgeshire'=>1,'Essex'=>1,'Hertfordshire'=>1,'Norfolk'=>1,'Peterborough'=>1,'Suffolk'=>1),
		'South East'=>array('Brighton & Hove'=>1,'Portsmouth'=>1,'Southampton'=>1,'Milton Keynes'=>1,'Berkshire'=>1,'Buckinghamshire'=>1,'East Sussex'=>1,'Hampshire'=>1,'Isle of Wight'=>1,'Kent'=>1,'Oxfordshire'=>1,'Surrey'=>1,'West Sussex'=>1),
		'South West'=>array('Bath and North East Somerset'=>1,'South Gloucestershire'=>1,'North Somerset'=>1,'Bournemouth'=>1,'Poole'=>1,'Somerset'=>1,'Bristol'=>1,'Gloucestershire'=>1,'Wiltshire'=>1,'Dorset'=>1,'Devon'=>1,'Cornwall'=>1),
		'London'=>array('Central London and West End (WC, EC, W, SW)'=>1,'North London (N, EN)'=>1,'East London (E, IG, RM)'=>1,'South East London (SE, BR, DA, TN)'=>1,'South West London (SW, CR, KT, SM, TW)'=>1,'West London (W)'=>1,'North West London (NW, HA, UB)'=>1),
	);
	return $data;
}

/**
 * Convert a high-level region into a list of counties, with listings tallies.
 *
 * @param  ?SHORT_TEXT	The high-level region (NULL: all)
 * @param  ?BINARY		How to filter to only those that are 'will buy' (NULL: no filter)
 * @param  ?BINARY		How to filter to only those that are 'will rent' (NULL: no filter)
 * @param  ?AUTO_LINK	Property-type filter (NULL: no filter)
 * @return array			The list of counties, each county being a map containing a tally and the county name
 */
function get_counties_for($h=NULL,$buy_filter=NULL,$rent_filter=NULL,$type_filter=NULL)
{
	$data=get_county_map();

	if (is_null($h))
	{
		$h='*';
		$temp=array();
		foreach ($data as $array)
		{
			$temp=array_merge($temp,$array);
		}
		ksort($temp);
		$data['*']=$temp;
	}

	$ret=array();
	foreach (array_keys($data[$h]) as $v)
	{
		$where=db_string_equal_to('l.l_county',$v).' AND p_validated=1';
		$join=' LEFT JOIN '.get_table_prefix().'property_wanted_locations w ON p.id=w_property_id';
		$join.=' LEFT JOIN '.get_table_prefix().'property_locations l ON l.id=w_location_id';

		if (!is_null($buy_filter)) $where.=' AND p_will_buy='.strval($buy_filter);
		if (!is_null($rent_filter)) $where.=' AND p_will_rent='.strval($rent_filter);
		if (!is_null($type_filter))
		{
			$where.=' AND t.t_type_id='.strval((integer)$type_filter).' AND t.t_desired=1';
			$join.=' LEFT JOIN '.get_table_prefix().'property_wanted_types t ON p.id=t.t_type_id';
		}

		$query='SELECT COUNT(DISTINCT p.id) FROM '.$GLOBALS['SITE_DB']->get_table_prefix().'property_wanted p'.$join.' WHERE '.$where;
		$tally=($h=='*')?-1:($GLOBALS['SITE_DB']->query_value_null_ok_full($query));
		$ret[]=array('COUNTY'=>$v,'TALLY'=>number_format($tally));
	}

	return $ret;
}

/**
 * Get some rows, according to some filters.
 *
 * @param  integer		Search from
 * @param  ?integer		Max results (NULL: no limit)
 * @param  ?BINARY		How to filter to only those that are 'will buy' (NULL: no filter)
 * @param  ?BINARY		How to filter to only those that are 'will rent' (NULL: no filter)
 * @param  ?AUTO_LINK	Property-type filter (NULL: no filter)
 * @param  string			Search term (blank: none)
 * @param  array			Filter on these features (map between feature ID and booleans)
 * @param  ID_TEXT		Sort field
 * @param  ID_TEXT		Sort order
 * @set    ASC DESC
 * @param  ?array			Lower-level region to get results for (NULL: don't care)
 * @param  ?integer		Minimum add time (NULL: don't care). i.e. all records are at least as new as specified
 * @param  ?BINARY		Validation status required (NULL: no filter)
 * @param  ?ID_TEXT		Guide-price filter (NULL: no filter)
 * @param  ?ID_TEXT		Number of bedrooms filter (NULL: no filter)
 * @return array			A pair: The list of property wanted records, The number of records available if there was no start/max limit.
 */
function get_property_wanted_rows($start,$max,$buy_filter,$rent_filter,$type_filter,$filter,$features_filter,$sortable,$sort_order,$regions,$min_add_time=NULL,$validated=1,$guide_price_filter=NULL,$num_bedrooms_filter=NULL)
{
	// Basis of SQL query, simple filtering
	$where='1=1'; // So we don't need to decide when to tack 'AND' on. We always do now.
	if (!is_null($regions))
	{
		$region_or='';
		foreach ($regions as $l)
		{
			if ($region_or!='') $region_or.=' OR ';
			$region_or.=db_string_equal_to('l_county',$l);
		}
		if ($region_or!='') $where.=' AND ('.$region_or.')';
	}
	if (!is_null($validated)) $where.=' AND p_validated=1';
	if (!is_null($min_add_time)) $where.=' AND p_add_time>'.strval($min_add_time);
	$join=' LEFT JOIN '.get_table_prefix().'property_wanted_locations w ON w.w_property_id=r.id LEFT JOIN '.get_table_prefix().'property_locations l ON l.id=w.w_location_id';

	// Typical narrowing-down filtering
	$rb_filter='';
	if ((!is_null($buy_filter)) && ($buy_filter==1))
	{
		if ($rb_filter!='') $rb_filter.=' OR ';
		$rb_filter.='p_will_buy='.strval($buy_filter);
	}
	if ((!is_null($rent_filter)) && ($rent_filter==1))
	{
		if ($rb_filter!='') $rb_filter.=' OR ';
		$rb_filter.='p_will_rent='.strval($rent_filter);
	}
	if ($rb_filter!='') $where.=' AND ('.$rb_filter.')';

	if (!is_null($type_filter))
	{
		$join.=' LEFT JOIN '.get_table_prefix().'property_wanted_types t ON r.id=t.t_type_id';
		$where.=' AND t.t_type_id='.strval($type_filter);
		$where.=' AND t.t_desired=1';
	}
	if (!is_null($guide_price_filter)) $where.=' AND ('.db_string_equal_to('p_guide_price',$guide_price_filter).' OR p_will_rent=1)';
	if (!is_null($num_bedrooms_filter)) $where.=' AND '.db_string_equal_to('p_num_bedrooms',$num_bedrooms_filter);

	// Feature filtering
	$i=0;
	foreach ($features_filter as $id=>$f_filter)
	{
		$join.=' LEFT JOIN '.get_table_prefix().'property_wanted_features f'.strval($i).' ON r.id=f'.strval($i).'.f_property_id';
		$where.=' AND f'.strval($i).'.f_desired='.($f_filter?'1':'0').' AND f'.strval($i).'.f_feature_id='.strval((integer)$id);
		$i++;
	}

	if ($filter!='')
	{
		// Full-text search
		$content_explode=explode(' ',$filter);
		$search='';
		foreach ($content_explode as $test)
		{
			foreach (array('l.l_county','l.l_outcode','l.l_town','r.p_further_details') as $search_key)
			{
				if ($search!='') $search.=' OR ';
				$search.=$search_key.' LIKE \''.db_encode_like('%'.$test.'%').'\'';
			}
		}
		$where.=' AND ('.$search.')';
	}

	// How many might there have been? (So we know how to browse pages nicely)
	$max_rows=$GLOBALS['SITE_DB']->query_value_null_ok_full('SELECT COUNT(DISTINCT r.id) FROM '.get_table_prefix().'property_wanted r'.$join.' WHERE '.$where);

	// Fetch
	$rows=$GLOBALS['SITE_DB']->query('SELECT r.* FROM '.get_table_prefix().'property_wanted r'.$join.' WHERE '.$where.' GROUP BY r.id ORDER BY '.$sortable.' '.$sort_order,$max,$start);
	
	return array($rows,$max_rows);
}

/**
 * Get a nice property type list.
 *
 * @param  ?array			The default type selection (NULL: none)
 * @param  boolean		Whether to get in tick-set form
 * @return mixed			The list
 */
function get_nice_property_type_list($types=NULL,$tick_set=true)
{
	$list=new ocp_tempcode();
	$list_tick_set=array();

	if (is_null($types)) $types=array();

	$rows=$GLOBALS['SITE_DB']->query_select('property_types',array('id','t_text'));
	foreach ($rows as $row)
	{
		$checked=false;
		foreach ($types as $t)
		{
			if (($t['CHECKED']) && ($t['_ID']==strval($row['id']))) $checked=true;
		}
		
		if ($tick_set)
		{
			$list_tick_set[]=array($row['t_text'],'type_'.strval($row['id']),$checked,'');
		} else
		{
			$list->attach(form_input_list_entry($row['id'],$checked,$row['t_text']));
		}
	}

	if ($tick_set) return $list_tick_set;
	return $list;
}

/**
 * Get a nice property features list.
 *
 * @param  ?array			The default features selection (NULL: none)
 * @param  boolean		Whether to get in tick-set form
 * @return mixed			The list
 */
function get_nice_property_features_list($features=NULL,$tick_set=true)
{
	$list=new ocp_tempcode();
	$list_tick_set=array();

	if (is_null($features)) $features=array();

	$rows=$GLOBALS['SITE_DB']->query_select('property_features',array('id','f_text'));
	foreach ($rows as $row)
	{
		$checked=false;
		foreach ($features as $t)
		{
			if (($t['CHECKED']) && ($t['_ID']==strval($row['id']))) $checked=true;
		}

		if ($tick_set)
		{
			$list_tick_set[]=array($row['f_text'],'feature_'.strval($row['id']),$checked,'');
		} else
		{
			$list->attach(form_input_list_entry($row['id'],$checked,$row['f_text']));
		}
	}

	if ($tick_set) return $list_tick_set;
	return $list;
}

/**
 * Get a nice property locations list, of locations under a certain specifier.
 *
 * @param  string			The high-level region that locations must be under
 * @param  string			The low-level region that locations must be under
 * @param  ?array			The default features selection (NULL: none)
 * @param  boolean		Whether to get in tick-set form
 * @param  boolean		Whether to default to ticked
 * @return mixed			The list
 */
function get_nice_property_locations_list($highlevel_region,$lowlevel_region,$locations=NULL,$tick_set=true,$default_ticked=false)
{
	$list=new ocp_tempcode();
	$list_tick_set=array();

	if (is_null($locations)) $locations=array();

	$rows=$GLOBALS['SITE_DB']->query_select('property_locations',array('id','l_town','l_outcode'),array('l_county'=>$lowlevel_region),'ORDER BY l_town,l_outcode');
	/*foreach ($rows as $row)		This simple old code resulted in lists that are far too long. So now we are going to do it via outcode, grouping together the towns in that outcode by list
	{
		$checked=in_array($row['id'],$locations);

		$text=$row['l_town'];
		if ($row['l_outcode']!='')
		{
			if ($text!='') $text.=', ';
			$text.=$row['l_outcode'];
		}
		if ($tick_set)
		{
			$list_tick_set[]=array($text,'location_'.strval($row['id']),$checked,'');
		} else
		{
			$list->attach(form_input_list_entry($row['id'],$checked,$text));
		}
	}*/
	$outcodes=array();
	foreach ($rows as $row)
	{
		if (!array_key_exists($row['l_outcode'],$outcodes)) $outcodes[$row['l_outcode']]=array();
		$outcodes[$row['l_outcode']][]=$row;
	}
	uksort($outcodes,'_outcode_sorter');
	//ksort($outcodes,SORT_NUMERIC);
	foreach ($outcodes as $outcode=>$outcode_rows)
	{
		$text='<strong>'.escape_html($outcode).'</strong>';
		$t_text='';
		$checked=false;
		foreach ($outcode_rows as $row)
		{
			$checked=$default_ticked || in_array($row['id'],$locations);

			if ($row['l_town']!='')
			{
				if ($t_text!='') $t_text.=', ';
				$t_text.='<em>'.str_replace(' ','&nbsp;',escape_html($row['l_town'])).'</em>';
			}
		}
		if ($t_text!='') $text.=' ('.$t_text.')';
		if ($tick_set)
		{
			$list_tick_set[]=array(protect_from_escaping($text),'location_'.$outcode,$checked,'');
		} else
		{
			$list->attach(form_input_list_entry($outcode,$checked,protect_from_escaping($text)));
		}
	}

	if ($tick_set) return $list_tick_set;
	return $list;
}

function _outcode_sorter($a,$b)
{
	$_a=preg_replace('#\d#','',$a);
	$_b=preg_replace('#\d#','',$b);
	$string_bit_equal=$_a==$_b;
	$string_bit=$_a>$_b;

	$_a=preg_replace('#[^\d]#','',$a);
	$_b=preg_replace('#[^\d]#','',$b);
	$num_bit=intval($_a)>=intval($_b);
	
	return ($string_bit_equal && $num_bit) || ($string_bit);
}

/**
 * Get a nice number of bedrooms list.
 *
 * @param  ?string		The default placed by selection (NULL: none)
 * @param  boolean		Whether to show an 'Any' option
 * @return tempcode		The list
 */
function get_nice_num_bedrooms_list($num_bedrooms=NULL,$any_option=true)
{
	$list=new ocp_tempcode();

	$a=array('','studio','1','2','3','4','5plus');
	foreach ($a as $x)
	{
		if ((!$any_option) && ($x=='')) continue;
		$list->attach(form_input_list_entry($x,$num_bedrooms===$x,do_lang('NB_'.$x)));
	}

	return $list;
}

/**
 * Get a nice market position list.
 *
 * @param  ?string		The default placed by selection (NULL: none)
 * @return tempcode		The list
 */
function get_nice_market_position_list($market_position=NULL)
{
	$list=new ocp_tempcode();

	foreach (array('noproperty','propertysold','propertyunderoffer','propertyonmarket','hasproperty') as $x)
	{
		$list->attach(form_input_list_entry($x,$market_position===$x,do_lang('MP_'.$x)));
	}

	return $list;
}

/**
 * Get a nice price range list.
 *
 * @param  ?array			The default placed by selection (NULL: none)
 * @return tempcode		The list
 */
function get_nice_guide_price_list($guide_price=NULL)
{
	$list=new ocp_tempcode();
	
	if (!is_array($guide_price)) $guide_price=array();

	$possibilities=array(
//		'Any',		Now supports multi select
		'Less than �100,000',
		'�100,000-200,000',
		'�200,000-300,000',
		'�300,000-400,000',
		'�400,000-500,000',
		'�500,000-600,000',
		'�600,000-700,000',
		'�700,000-800,000',
		'�800,000-900,000',
		'�900,000-1,000,000',
		'�1,000,000+',
	);

	foreach ($possibilities as $x)
	{
		$list->attach(form_input_list_entry($x,in_array($x,$guide_price),$x));
	}

	return $list;
}