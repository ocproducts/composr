<?php /*

 ocPortal
 Copyright (c) ocProducts, 2004-2008

 You may not distribute a modified version of this file, unless it is solely as an ocPortal modification.
 See text/en/licence.txt for full licencing information.

*/

// Written for Property To You.
//  Assumes:
//	Full-Text search capable server
//	Accessibility conventions, and PTY site paths
//	GD capable server
//	Images are a maximum box size of 1000

require_code('aed_module');

class Module_property extends standard_aed_module
{
	var $skip_validation='_true';
	var $lang_type='PROPERTY';
	var $archive_entry_point='_SELF:_SELF:type=misc';
	var $view_entry_point='_SELF:_SELF:type=view:id=_ID';
	var $user_facing=true;
	var $send_validation_request=true;
	var $permissions_require=NULL;
	var $select_name='TITLE';
	var $select_name_description='DESCRIPTION_TITLE';
	var $title_is_multi_lang=false;
	var $orderer='id';
	var $award_type='property';
	var $second_stage_preview=true;
	var $care_please=false;

	/**
	 * Standard modular info function.
	 *
	 * @return ?array	 Map of module info (NULL: module is disabled).
	 */
	function info()
	{
		$info=array();
		$info['author']='Chris Graham'; 
		$info['organisation']='ocProducts'; 
		$info['hacked_by']=NULL; 
		$info['hack_version']=NULL;
		$info['version']=4;
		$info['locked']=true;
		return $info;
	}
	
	/**
	 * Standard modular uninstall function.
	 */
	function uninstall()
	{
		$GLOBALS['SITE_DB']->drop_if_exists('property_wanted');
		$GLOBALS['SITE_DB']->drop_if_exists('property_locations');
		$GLOBALS['SITE_DB']->drop_if_exists('property_features');
		$GLOBALS['SITE_DB']->drop_if_exists('property_types');
		$GLOBALS['SITE_DB']->drop_if_exists('property_wanted_types');
		$GLOBALS['SITE_DB']->drop_if_exists('property_wanted_locations');
		$GLOBALS['SITE_DB']->drop_if_exists('property_wanted_features');
		$GLOBALS['SITE_DB']->drop_if_exists('property_fav');
		$GLOBALS['SITE_DB']->drop_if_exists('property_portfolio');
		$GLOBALS['SITE_DB']->drop_if_exists('property_pfolio_features');
	}

	/**
	 * Standard modular install function.
	 *
	 * @param  ?integer	 What version we're upgrading from (NULL: new install)
	 * @param  ?integer	 What hack version we're upgrading from (NULL: new-install/not-upgrading-from-a-hacked-version)
	 */
	function install($upgrade_from=NULL,$upgrade_from_hack=NULL)
	{
		$GLOBALS['SITE_DB']->create_table('property_locations',array(
			'id'=>'*AUTO',
			'l_country'=>'SHORT_TEXT',
			'l_outcode'=>'ID_TEXT',
			'l_town'=>'SHORT_TEXT',
			'l_county'=>'SHORT_TEXT',
			'l_longitude'=>'ID_TEXT',
			'l_latitude'=>'ID_TEXT',
		));
		$GLOBALS['SITE_DB']->create_index('property_locations','#l_country',array('l_country'));
		$GLOBALS['SITE_DB']->create_index('property_locations','#l_outcode',array('l_outcode'));
		$GLOBALS['SITE_DB']->create_index('property_locations','#l_town',array('l_town'));
		$GLOBALS['SITE_DB']->create_index('property_locations','#l_county',array('l_county'));
		$GLOBALS['SITE_DB']->create_index('property_locations','#l_longitude',array('l_longitude'));
		$GLOBALS['SITE_DB']->create_index('property_locations','#l_latitude',array('l_latitude'));

		$GLOBALS['SITE_DB']->create_table('property_features',array(
			'id'=>'*AUTO',
			'f_displayed'=>'BINARY',
			'f_text'=>'SHORT_TEXT',
		));
		require_lang('property');
		$feature_set=array();
		$feature_set[do_lang('DETACHED')]=0;
		$feature_set=array_merge($feature_set,array(
			'Parking available (off-street or unrestricted on street)'=>1,
			'Single garage'=>1,
			'Double garage'=>1,
			'Garaging for more than two cars'=>1,
			'Garden'=>1,
			'Large garden'=>1,
			'Entrance level WC'=>1,
			'In catchment area of successful primary school'=>1,
			'In catchment area of successful secondary school'=>1,
			'Within walking distance of shops and public transport (\'Walking distance\' means no more than 0.5 kilometre!)'=>1,
			'Refurbishment opportunity'=>1,
			'Wheelchair access'=>1,
			'Retirement accommodation'=>1,
			'Assisted living (warden or other support services available)'=>1,
		));
		foreach ($feature_set as $text=>$displayed)
		{
			$GLOBALS['SITE_DB']->query_insert('property_features',array('f_displayed'=>$displayed,'f_text'=>$text));
		}

		$GLOBALS['SITE_DB']->create_table('property_types',array(
			'id'=>'*AUTO',
			't_text'=>'SHORT_TEXT',
		));
		$types_set=array(
			'House',
			'Bungalow',
			'Flat/apartment',
			'Chalet',
			'Mobile home',
		);
		foreach ($types_set as $text)
		{
			$GLOBALS['SITE_DB']->query_insert('property_types',array('t_text'=>$text));
		}

		// Listings
		$GLOBALS['SITE_DB']->create_table('property_wanted',array(
			'id'=>'*AUTO',

			// Specific fields
			'p_will_buy'=>'BINARY',
			'p_will_rent'=>'BINARY',
			'p_guide_price'=>'SHORT_TEXT', // (in pounds, may be blank)
			'p_monthly_rent'=>'SHORT_TEXT', // (in pounds, may be blank)
			'p_num_bedrooms'=>'ID_TEXT', // |studio|1|2|3|4|5plus
			'p_market_position'=>'ID_TEXT', // noproperty|propertysold|propertyunderoffer|propertyonmarket|hasproperty
			'p_further_details'=>'LONG_TRANS',
			'p_display_all_details'=>'BINARY',
			'p_display_time_days'=>'INTEGER',

			// Standard entry fields
			'p_add_time'=>'TIME',
			'p_edit_time'=>'?TIME',
			'p_validated'=>'BINARY',
			'p_submitter'=>'USER',
			'p_notes'=>'LONG_TEXT',
			'p_views'=>'?INTEGER',
			'p_delisting_sent'=>'BINARY',
		),false,true);
		$GLOBALS['SITE_DB']->create_table('property_wanted_types',array(	// Linker table
			't_property_id'=>'*AUTO_LINK',
			't_type_id'=>'*AUTO_LINK',
			't_desired'=>'BINARY',
		));
		$GLOBALS['SITE_DB']->create_table('property_wanted_locations',array(	// Linker table
			'w_property_id'=>'*AUTO_LINK',
			'w_location_id'=>'*AUTO_LINK',
		));
		$GLOBALS['SITE_DB']->create_table('property_wanted_features',array(	// Linker table
			'f_property_id'=>'*AUTO_LINK',
			'f_feature_id'=>'*AUTO_LINK',
			'f_desired'=>'BINARY',
		));
		$GLOBALS['SITE_DB']->create_index('property_wanted','p_validated',array('p_validated'));
		$GLOBALS['SITE_DB']->create_index('property_wanted','p_will_buy',array('p_will_buy'));
		$GLOBALS['SITE_DB']->create_index('property_wanted','p_will_rent',array('p_will_rent'));
		$GLOBALS['SITE_DB']->create_index('property_wanted','p_add_time',array('p_add_time'));
		$GLOBALS['SITE_DB']->create_index('property_wanted','p_edit_time',array('p_edit_time'));
		$GLOBALS['SITE_DB']->create_index('property_wanted','p_submitter',array('p_submitter'));
		$GLOBALS['SITE_DB']->create_index('property_wanted_types','t_desired',array('t_desired'));
		$GLOBALS['SITE_DB']->create_index('property_wanted_features','f_desired',array('f_desired'));
		
		// For users looking at listings
		$GLOBALS['SITE_DB']->create_table('property_fav',array(
			'f_property_id'=>'*AUTO_LINK',
			'f_member_id'=>'*USER',
			'f_time'=>'TIME',
			'f_note'=>'LONG_TEXT'
		));
		$GLOBALS['SITE_DB']->create_table('property_portfolio',array(
			'id'=>'*AUTO',
			'o_for'=>'AUTO_LINK',
			'o_member_id'=>'USER',
			'o_address'=>'LONG_TEXT',
			'o_type'=>'?AUTO_LINK',
			'o_asking_price'=>'SHORT_TEXT', // (in pounds, may be blank)
			'o_monthly_rent'=>'SHORT_TEXT', // (in pounds, may be blank)
			'o_num_bedrooms'=>'ID_TEXT', // |studio|1|2|3|4|5plus
			'o_photo_main'=>'URLPATH',
			'o_photo_aux_1'=>'URLPATH',
			'o_photo_aux_2'=>'URLPATH',
			'o_photo_aux_3'=>'URLPATH',
			'o_photo_main_thumb'=>'URLPATH',
			'o_photo_aux_1_thumb'=>'URLPATH',
			'o_photo_aux_2_thumb'=>'URLPATH',
			'o_photo_aux_3_thumb'=>'URLPATH',
			'o_further_details'=>'LONG_TRANS',
			'o_further_details_link'=>'URLPATH',
			'o_add_time'=>'TIME',
		));
		$GLOBALS['SITE_DB']->create_table('property_pfolio_features',array(	// Linker table
			'f_portfolio_id'=>'*AUTO_LINK',
			'f_feature_id'=>'*AUTO_LINK',
			'f_has'=>'BINARY',
		));
	}

	/**
	 * Standard modular entry-point finder function.
	 *
	 * @return ?array	 A map of entry points (type-code=>language-code) (NULL: disabled).
	 */
	function get_entry_points()
	{
		return array_merge(array('map'=>'FIND_PROPERTY'),parent::get_entry_points());
	}

	/**
	 * Standard aed_module run_start.
	 *
	 * @param  ID_TEXT		The type of module execution
	 * @return tempcode		The output of the run
	 */
	function run_start($type)
	{
		//removed-assert
		require_code('property');
		require_lang('property');
		require_css('property');
		require_javascript('javascript_property');

		$this->javascript="init_property_form();";
		$this->add_text=paragraph(do_lang('PROPERTY_ADD_TEXT'));
		$this->edit_text=paragraph(do_lang('PROPERTY_EDIT_TEXT'));
		$this->add_submit_name=do_lang('SUBMIT_POST');
		$this->edit_submit_name=do_lang('SUBMIT_EDIT');

		if ($type=='map') return $this->property_map();
		if ($type=='county') return $this->select_county();
		if ($type=='browse') return $this->browse();
		if ($type=='view') return $this->view();
		if ($type=='my_listings') return $this->my_listings();
		if ($type=='_renew') return $this->_renew();
		if ($type=='respond') return $this->respond();
		if ($type=='_respond') return $this->_respond();
		if ($type=='view_response') return $this->view_response();

		return new ocp_tempcode();
	}

	/**
	 * Standard modular page-link finder function (does not return the main entry-points that are not inside the tree).
	 *
	 * @param  ?integer  The number of tree levels to computer (NULL: no limit)
	 * @param  boolean	Whether to not return stuff that does not support permissions (unless it is underneath something that does).
	 * @param  ?string	Position to start at in the tree. Does not need to be respected. (NULL: from root)
	 * @return ?array	 A tuple: 1) full tree structure [made up of (pagelink, permission-module, permissions-id, title, children, ?entry point for the children, ?children permission module, ?whether there are children) OR a list of maps from a get_* function] 2) permissions-page 3) optional base entry-point for the tree 4) optional permission-module 5) optional permissions-id (NULL: disabled).
	 */
	function get_page_links($max_depth=NULL,$require_permission_support=false,$start_at=NULL)
	{
		unset($require_permission_support);

		$permission_page='property';

		return array(array(),$permission_page);
	}

	/**
	 * Standard modular specific-permission-overide finder function.
	 *
	 * @return array	  A map of specific permissions that are overridable; sp to 0 or 1. 0 means "not category overridable". 1 means "category overridable".
	 */
	function get_sp_overrides()
	{
		return array('submit_midrange_content'=>0,'bypass_validation_midrange_content'=>0,'edit_own_midrange_content'=>0,'edit_midrange_content'=>0,'delete_own_midrange_content'=>0,'delete_midrange_content'=>0);
	}

	/**
	 * View an overview of the members listings on the system.
	 *
	 * @return tempcode		The UI
	 */
	function my_listings()
	{
		$title=get_page_title('MY_LISTINGS');

		$member_id=get_param_integer('member_id',get_member());
		enforce_personal_access($member_id);

		$rows=$GLOBALS['SITE_DB']->query_select('property_wanted',array('*'),array('p_submitter'=>$member_id),'ORDER BY p_add_time DESC');
		if (count($rows)==0) warn_exit(do_lang_tempcode('NO_ENTRIES'));

		$ads=array();
		foreach ($rows as $row)
		{
			$url=build_url(array('page'=>'_SELF','type'=>'view','id'=>$row['id']),'_SELF');
			$price=NULL;//get_property_sales_price($row['p_region'],$row['p_county'],$member_id,$row['p_original_add_time']);
			$_transaction_details=NULL;
			if (is_null($price))
			{
				$edit_url=build_url(array('page'=>'_SELF','type'=>'ed','id'=>$row['id']),'_SELF');
				if (is_object($edit_url)) $edit_url=$edit_url->evaluate();
				$extra='('.do_lang('EDIT_TO_CHANGE_LISTING_LENGTH',escape_html($edit_url)).')';
			} else
			{
				$purchase_url=build_url(array('page'=>'purchase','type'=>'message','product'=>'PROPERTY_LISTING','id'=>$row['id']),get_module_zone('purchase'));
				if (is_object($purchase_url)) $purchase_url=$purchase_url->evaluate();
				$extra='('.do_lang('PURCHASE_TO_MAKE_ACTIVE',escape_html($purchase_url)).')';

				$transaction_details=$GLOBALS['SITE_DB']->query_select('transactions',array('*'),array('purchase_id'=>strval($row['id']),'item'=>do_lang('CUSTOM_PRODUCT_PROPERTY_LISTING')));
				if (count($transaction_details)==0)
				{
					$_transaction_details=mixed(); // NULL
				} else
				{
					foreach ($transaction_details as $t)
					{
						$_transaction_details[]=array(
							'ID'=>strval($t['id']),
							'PURCHASE_ID'=>strval($t['purchase_id']),
							'STATUS'=>$t['status'],
							'REASON'=>$t['reason'],
							'AMOUNT'=>number_format($t['amount']),
							'T_CURRENCY'=>$t['t_currency'],
							'LINKED'=>$t['linked'],
							'T_TIME'=>strval($t['t_time']),
							'ITEM'=>$t['item'],
							'PENDING_REASON'=>$t['pending_reason'],
							'T_MEMO'=>$t['t_memo'],
							'T_VIA'=>$t['t_via']
						);
					}
				}
			}
			$active=($row['p_validated']==1)?do_lang('YES'):(do_lang('NO').' '.$extra);
			$ads[]=array('TRANSACTION_DETAILS'=>$_transaction_details,'DATE'=>get_timezoned_date($row['p_add_time']),'ACTIVE'=>$active,'ID'=>strval($row['id']),'URL'=>$url,'NUM_VIEWS'=>number_format($row['p_views']));
		}
		return do_template('PROPERTY_LISTINGS_SCREEN',array('TITLE'=>$title,'ADS'=>$ads));
	}

	/**
	 * UI to show the property map.
	 *
	 * @return tempcode		The UI
	 */
	function property_map()
	{
		$title=get_page_title('BROWSE_PROPERTY');

		$buy_filter=get_param_integer('buy',NULL);
		$rent_filter=get_param_integer('rent',NULL);
		$type_filter=get_param_integer('p_type',NULL);

		$url=build_url(array('page'=>'_SELF','type'=>'county','buy'=>$buy_filter,'rent'=>$rent_filter,'p_type'=>$type_filter),'_SELF');

		return do_template('PROPERTY_MAP_SCREEN',array_merge(get_region_data($buy_filter,$rent_filter,$type_filter),array('TITLE'=>$title,'ADDING'=>false,'URL'=>$url)));
	}

	/**
	 * UI to browse to select a county.
	 *
	 * @return tempcode		The UI
	 */
	function select_county()
	{
		$title=get_page_title('BROWSE_PROPERTY');

		$h=get_param('h');

		$buy_filter=get_param_integer('buy',NULL);
		$rent_filter=get_param_integer('rent',NULL);
		$type_filter=get_param_integer('p_type',NULL);

		$counties=get_counties_for($h,$buy_filter,$rent_filter,$type_filter);

		$url=build_url(array('page'=>'_SELF','type'=>'browse','buy'=>$buy_filter,'rent'=>$rent_filter,'p_type'=>$type_filter),'_SELF');

		return do_template('PROPERTY_COUNTY_SCREEN',array('TITLE'=>$title,'ADDING'=>false,'URL'=>$url,'COUNTIES'=>$counties));
	}

	/**
	 * UI to browse what's in a county.
	 *
	 * @return tempcode		The UI
	 */
	function browse()
	{
		$l=get_param('l');
		
		$title=get_page_title('PROPERTY_IN',true,array($l));

		// Search for region, as we just know county
		$region='';
		$county_map=get_county_map();
		foreach ($county_map as $new_region=>$counties)
		{
			if (array_key_exists($l,$counties))
			{
				$region=$new_region;
				break;
			}
		}

		// Breadcrumbs
		breadcrumb_set_parents(array(array('property:misc',do_lang('CHOOSE_REGION')),array('property:county',$region)));

		// Pagination
		$start=get_param_integer('start',0);
		$max=get_param_integer('max',10);

		// Optional filtering
		$buy_filter=get_param_integer('buy',0);
		$rent_filter=get_param_integer('rent',0);

		$type_filter=get_param_integer('p_type',NULL);

		// Keyword search filter
		$filter=either_param('filter','');

		// Quick security check
		$order=either_param('order','p_add_time DESC');
		$sortables=array(
			'p_num_bedrooms'=>do_lang('_NUM_BEDROOMS'),
			'p_add_time'=>do_lang('DATE_TIME'),
		);
		list($sortable,$sort_order)=explode(' ',$order);
		if ((($sort_order!='ASC') && ($sort_order!='DESC')) || (!array_key_exists($sortable,$sortables)))
			log_hack_attack_and_exit('ORDERBY_HACK');

		// Get rows
		$f_filters=get_property_features();
		$feature_filters=array();
		foreach ($f_filters as $i=>$f_filter)
		{
			if ($f_filter['CHECKED']) $feature_filters[$f_filter['_ID']]=true;
		}
		list($rows,$max_rows)=get_property_wanted_rows($start,$max,$buy_filter,$rent_filter,$type_filter,$filter,$feature_filters,$sortable,$sort_order,array($l));

		// Render
		$entries=new ocp_tempcode();
		foreach ($rows as $myrow)
		{
			$entries->attach(render_property_wanted_box($myrow,false,get_property_types($myrow['id']),get_property_features($myrow['id']),get_property_locations($myrow['id']),$l));
		}		

		// Browsing, sorting, filtering
		require_code('templates_interfaces');
		$browser=results_browser(make_string_tempcode(do_lang('PROPERTY')),$l,$start,'start',$max,'max',$max_rows,NULL,'browse',true,true);
		$selectors=new ocp_tempcode();
		foreach ($sortables as $_sortable=>$text)
		{
			$selector_value=$_sortable.' ASC';
			$selected=(($sortable.' '.$sort_order)==$selector_value);
			$selectors->attach(do_template('RESULTS_BROWSER_SORTER',array('SELECTED'=>$selected,'NAME'=>$text.' ('.do_lang('ASCENDING').')','VALUE'=>$selector_value)));
			$selector_value=$_sortable.' DESC';
			$selected=(($sortable.' '.$sort_order)==$selector_value);
			$selectors->attach(do_template('RESULTS_BROWSER_SORTER',array('SELECTED'=>$selected,'NAME'=>$text.' ('.do_lang('DESCENDING').')','VALUE'=>$selector_value)));
		}
		$sort_url=get_self_url();
		$hidden=build_keep_form_fields('_SELF',true,array('filter','order'));
		$sort=do_template('RESULTS_BROWSER_SORT',array('FILTER'=>$filter,'HIDDEN'=>$hidden,'SORT'=>'order','RAND'=>uniqid(''),'URL'=>$sort_url,'SELECTORS'=>$selectors));

		$features=$f_filters;
		$skip=array('buy','rent');
		foreach (array_keys($features) as $f)
		{
			$skip[]='feature_'.strval($f);
		}
		$hidden=build_keep_form_fields('_SELF',true,$skip);
		$filter_url=get_self_url(false,false,NULL,true);
		
		$add_url=build_url(array('page'=>'_SELF','type'=>'ad','l'=>$l),'_SELF');

		return do_template('PROPERTY_BROWSE_SCREEN',array('TITLE'=>$title,'HIDDEN'=>$hidden,'SORT'=>$sort,'BROWSER'=>$browser,'BUY_CHECKED'=>$buy_filter==1,'RENT_CHECKED'=>$rent_filter==1,'ENTRIES'=>$entries,'FEATURES'=>$features,'FILTER_URL'=>$filter_url,'ADD_URL'=>$add_url));
	}

	/**
	 * UI to view a property.
	 *
	 * @return tempcode		The UI
	 */
	function view()
	{
		$title=get_page_title('PROPERTY_DETAILS');

		$id=get_param_integer('id');

		// Fetch entry
		$_myrow=$GLOBALS['SITE_DB']->query_select('property_wanted',array('*'),array('id'=>$id),'',1);
		if (!array_key_exists(0,$_myrow)) warn_exit(do_lang_tempcode('MISSING_PROPERTY_RESOURCE'));
		$myrow=$_myrow[0];

		// Build up warning details
		$warning_details=new ocp_tempcode();
		if ($myrow['p_validated']==0)
		{
			$warning_details->attach(do_template('WARNING_TABLE',array('WARNING'=>do_lang('PROPERTY_INACTIVE'))));
		}

		// Build up the back URL
		if (!is_null(get_param('l',NULL)))
		{
			$map=array('page'=>'_SELF','type'=>'browse','l'=>get_param('l'));
			$map['start']=get_param_integer('start',0);
			$map['max']=get_param_integer('max',30);
		} else
		{
			$map=array('page'=>'_SELF','type'=>'map');
		}
		$buy=get_param_integer('buy',NULL);
		if (!is_null($buy)) $map['buy']=$buy;
		$rent=get_param_integer('rent',NULL);
		if (!is_null($rent)) $map['rent']=$rent;
		$type=get_param('p_type',NULL);
		if (!is_null($type)) $map['p_type']=$type;
		$order=get_param('order','');
		if ($order!='') $map['order']=$order;
		$filter=get_param('filter','');
		if ($filter!='') $map['filter']=$filter;
		$back_url=build_url($map,'_SELF');

		// Increment view count
		if (!is_null($myrow['p_views']))
		{
			$myrow['p_views']++;
			$GLOBALS['SITE_DB']->query_update('property_wanted',array('p_views'=>$myrow['p_views']),array('id'=>$id),'',1);
		}

		// Render interface
		$types=get_property_types($id);
		$features=get_property_features($id);
		$locations=get_property_locations($id);
		global $SEO_KEYWORDS;
		if (!is_null(get_param('l',NULL))) $SEO_KEYWORDS[]=get_param('l');
		foreach (compile_locations($locations) as $location)
		{
			$SEO_KEYWORDS[]=$location['L_OUTCODE'];
		}
		$view=render_property_wanted_box($myrow,true,$types,$features,$locations,get_param('l',NULL));

		// Edit URL
		$edit_url='';
		if ((has_edit_permission('mid',get_member(),$myrow['p_submitter'],'property')))
		{
			$edit_url=build_url(array('page'=>'property','type'=>'_ed','id'=>$id),get_module_zone('property'));
		}

		// Wrapper screen
		return do_template('PROPERTY_VIEW_SCREEN',array(
			'TITLE'=>$title,
			'BACK_URL'=>$back_url,
			'WARNING_DETAILS'=>$warning_details,
			'VIEW'=>$view,
			'EDIT_URL'=>$edit_url,
		));
	}

	/**
	 * Standard modular entry list fetcher.
	 *
	 * @return tempcode	 The list
	 */
	function nice_get_entries()
	{
		$entries=new ocp_tempcode();
		$rows=$GLOBALS['SITE_DB']->query_select('property_wanted',array('*'),array('p_submitter'=>get_member()),'ORDER BY id');
		foreach ($rows as $row)
		{
			$readable='#'.strval($row['id']);
			$entries->attach(form_input_list_entry($row['id'],$row['id']===get_param_integer('id',NULL),$readable));
		}
		return $entries;
	}

	function _force_have_regions()
	{
		$highlevel_region=either_param('h',NULL);
		$lowlevel_region=either_param('l',NULL);

		$self_url=get_self_url(false,false,NULL,false,true);

		if (is_null($highlevel_region))
		{
			if (is_null($lowlevel_region))
			{
				// Show map UI
				$echo=do_header();
				$title=get_page_title('ADD_PROPERTY');
				$inside=do_template('PROPERTY_MAP_SCREEN',array_merge(get_region_data(get_param_integer('buy',1),get_param_integer('rent',1)),array('TITLE'=>$title,'ADDING'=>true,'URL'=>$self_url)));
				$echo->attach(globalise($inside));
				$echo->attach(do_footer());
				$echo->evaluate_echo();
				exit();
			} else
			{
				$map=get_county_map();
				foreach ($map as $highlevel_region=>$counties)
				{
					if (array_key_exists($lowlevel_region,$counties)) break;
				}
			}
		}
		
		if (is_null($lowlevel_region))
		{
			// Show county UI
			$counties=get_counties_for($highlevel_region,get_param_integer('buy',1),get_param_integer('rent',1));
			$echo=do_header();
			$title=get_page_title('ADD_PROPERTY');
			$inside=do_template('PROPERTY_COUNTY_SCREEN',array('TITLE'=>$title,'ADDING'=>true,'URL'=>$self_url,'COUNTIES'=>$counties));
			$echo->attach(globalise($inside));
			$echo->attach(do_footer());
			$echo->evaluate_echo();
			exit();
		}
		
		return array($highlevel_region,$lowlevel_region);
	}

	function get_form_fields($property_row=NULL,$features=NULL,$types=NULL,$locations=NULL)
	{
		if (is_null($property_row))
		{
			$id=NULL;
			$will_buy=get_param_integer('buy',1);
			$will_rent=get_param_integer('rent',0);
		} else
		{
			$id=$property_row['id'];
			$will_buy=$property_row['p_will_buy'];
			$will_rent=$property_row['p_will_rent'];
		}
		
		if (is_guest()) access_denied('NOT_AS_GUEST');

		$fields=new ocp_tempcode();
		$hidden=new ocp_tempcode();

		// Fields
		$_looking_for=array(
			array(do_lang_tempcode('FOR_SALE'),'will_buy',$will_buy==1,''),
			array(do_lang_tempcode('FOR_LET'),'will_rent',$will_rent==1,''),
		);
		$fields->attach(form_input_various_ticks($_looking_for,do_lang_tempcode('DESCRIPTION_IM_LOOKING_FOR'),NULL,do_lang_tempcode('IM_LOOKING_FOR'),true));
		$_types=get_nice_property_type_list($types);
		$fields->attach(form_input_various_ticks($_types,do_lang_tempcode('DESCRIPTION_PROPERTY_TYPE'),NULL,do_lang_tempcode('PROPERTY_TYPE'),true));
		//$fields->attach(form_input_line(do_lang_tempcode('PPRICE_sale'),do_lang_tempcode('DESCRIPTION_PPRICE_sale'),'guide_price',is_null($property_row)?'':$property_row['p_guide_price'],true));
		$fields->attach(form_input_multi_list(do_lang_tempcode('PPRICE_sale'),do_lang_tempcode('DESCRIPTION_PPRICE_sale'),'guide_price',get_nice_guide_price_list(is_null($property_row)?NULL:explode('; ',$property_row['p_guide_price'])),NULL,false,false));
		$fields->attach(form_input_line(do_lang_tempcode('PPRICE_let'),do_lang_tempcode('DESCRIPTION_PPRICE_let'),'monthly_rent',is_null($property_row)?'':$property_row['p_monthly_rent'],false));
		$fields->attach(form_input_list(do_lang_tempcode('NUM_BEDROOMS'),do_lang_tempcode('DESCRIPTION_NUM_BEDROOMS'),'num_bedrooms',get_nice_num_bedrooms_list(is_null($property_row)?NULL:$property_row['p_num_bedrooms']),NULL,false,false));
		$fields->attach(form_input_list(do_lang_tempcode('MARKET_POSITION'),do_lang_tempcode('DESCRIPTION_MARKET_POSITION'),'market_position',get_nice_market_position_list(is_null($property_row)?NULL:$property_row['p_market_position'])));
		//$fields->attach(form_input_text(do_lang_tempcode('NOTES'),do_lang_tempcode($GLOBALS['FORUM_DRIVER']->is_staff(get_member())?'STAFF_NOTES_PROPERTY':'DESCRIPTION_NOTES'),'notes',is_null($property_row)?'':$property_row['p_notes'],false));
		/*if ($GLOBALS['FORUM_DRIVER']->is_staff(get_member()))
		{
			$fields->attach(form_input_tick(do_lang_tempcode('VALIDATED'),do_lang_tempcode('DESCRIPTION_VALIDATED'),'validated',is_null($property_row)?true:($property_row['p_validated']==1)));
		} else
		{*/
			$hidden->attach(form_input_hidden('validated','1'));
		/*}*/
		//$fields->attach(form_input_tick(do_lang_tempcode('DISPLAY_ALL_DETAILS'),do_lang_tempcode('DESCRIPTION_DISPLAY_ALL_DETAILS'),'display_all_details',$display_all_details==1));
		$hidden->attach(form_input_hidden('display_all_details','1'));
		/*$display_time_dayss=new ocp_tempcode();
		if ((get_member()==29) || ($submitter==29))
		{
			$display_time_dayss->attach(form_input_list_entry('6',$display_time_days==6,number_format(6)));
		} else
		{
			$display_time_dayss->attach(form_input_list_entry('7',$display_time_days==7,number_format(7)));
		}
		$display_time_dayss->attach(form_input_list_entry('14',$display_time_days==14,number_format(14)));
		$display_time_dayss->attach(form_input_list_entry('31',($display_time_days==31) || (is_null($display_time_days)),number_format(31)));
		$display_time_dayss->attach(form_input_list_entry('90',$display_time_days==90,number_format(90)));
		$display_time_dayss->attach(form_input_list_entry('10000',$display_time_days>=10000,do_lang('INDEFINITELY')));
		$fields->attach(form_input_list(do_lang_tempcode('DISPLAY_TIME_DAYS'),do_lang_tempcode('DESCRIPTION_DISPLAY_TIME_DAYS'),'display_time_days',$display_time_dayss));*/
		$hidden->attach(form_input_hidden('display_time_days','60'));

		// Location
		if (is_null($id))
		{
			list($highlevel_region,$lowlevel_region)=$this->_force_have_regions();
		} else
		{
			$lowlevel_region=$GLOBALS['SITE_DB']->query_value('property_locations','l_county',array('id'=>$locations[0]));
			$county_map=get_county_map();
			foreach ($county_map as $highlevel_region=>$in_there)
			{
				if (array_key_exists($lowlevel_region,$in_there)) break;
			}
		}
		$fields->attach(do_template('FORM_SCREEN_FIELD_SPACER',array('TITLE'=>do_lang_tempcode('PROPERTY_SUBHEADING_LOCATION'),'HELP'=>do_lang_tempcode('PROPERTY_SUBHEADING_LOCATION_DESCRIPTION',escape_html($highlevel_region),escape_html($lowlevel_region)))));
		$map=get_county_map();
		$__locations=array();
		foreach (array_keys($map[$highlevel_region]) as $_lowlevel_region)
		{
			$_locations=get_nice_property_locations_list($highlevel_region,$_lowlevel_region,$locations,true/*,is_null($property_row) && ($_lowlevel_region==$lowlevel_region)*/);
			$__locations[]=array($_locations,$_lowlevel_region==$lowlevel_region,$_lowlevel_region);
		}
		$locs=$this->form_input_various_ticks_memory_nice($__locations,do_lang_tempcode('DESCRIPTION_LOCATIONS'),NULL,do_lang_tempcode('LOCATIONS'));
		$fields->attach($locs->evaluate());
		unset($locs);

		// Features
		$fields->attach(do_template('FORM_SCREEN_FIELD_SPACER',array('TITLE'=>do_lang_tempcode('PROPERTY_SUBHEADING_FEATURES'),'HELP'=>do_lang_tempcode('PROPERTY_SUBHEADING_FEATURES_DESCRIPTION'))));
		$_features=get_nice_property_features_list($features);
		$fields->attach(form_input_various_ticks($_features,do_lang_tempcode('DESCRIPTION_FEATURES'),NULL,do_lang_tempcode('FEATURES'),true));
		$fields->attach(form_input_huge(do_lang_tempcode('FURTHER_DETAILS'),do_lang_tempcode('DESCRIPTION_FURTHER_DETAILS'),'further_details',is_null($property_row)?'':get_translated_text($property_row['p_further_details']),true));

		return array(make_string_tempcode($fields->evaluate()),$hidden);
	}

	/**
	 * Get the tempcode for a bank of tick boxes. WRITTEN FOR LARGE DATA SETS, TO AVOID GOING OVER MEMORY LIMITS.
	 *
	 * @param  array			A list of tuples: (prettyname, name, value, description)
	 * @param  mixed			A description for this input field
	 * @param  ?integer		The tab index of the field (NULL: not specified)
	 * @param  mixed			A human intelligible name for this input field (blank: use default)
	 * @return tempcode		The input field
	 */
	function form_input_various_ticks_memory_nice($options,$description,$_tabindex=NULL,$_pretty_name='')
	{
		if (count($options)==0) return new ocp_tempcode();

		if (is_null($_tabindex))
		{
			$tabindex=get_form_field_tabindex(NULL);
		} else
		{
			$_tabindex++;
			$tabindex=$_tabindex;
		}

		if ((is_string($_pretty_name)) && ($_pretty_name=='')) $_pretty_name=do_lang_tempcode('OPTIONS');

		$input='';

		if (count($options[0])!=3)
		{
			$options=array(array($options,NULL,new ocp_tempcode()));
		}
		foreach ($options as $_option)
		{
			$inner='';
			foreach ($_option[0] as $option)
			{
				list($pretty_name,$name,$value,$_description)=$option;

				$value=(filter_form_field_default($name,$value?'1':'0')=='1');

				$tmp=do_template('FORM_SCREEN_INPUT_VARIOUS_TICKS_INNER',array('SECTION_TITLE'=>$_option[2],'EXPANDED'=>$_option[1],'CHECKED'=>$value,'TABINDEX'=>strval($tabindex),'NAME'=>$name,'PRETTY_NAME'=>$pretty_name,'DESCRIPTION'=>$_description));
				$inner.=$tmp->evaluate();
			}

			$tmp=do_template('FORM_SCREEN_INPUT_VARIOUS_TICKS_OUTER',array('_GUID'=>'a6212f61304a101fb2754e334a8b4212','SECTION_TITLE'=>$_option[2],'EXPANDED'=>$_option[1],'INNER'=>$inner));
			$input.=$tmp->evaluate();
		}
		return _form_input('',$_pretty_name,$description,$input,false,false,$tabindex);
	}

	/**
	 * Standard aed_module submitter getter.
	 *
	 * @param  AUTO_LINK		The entry for which the submitter is sought
	 * @return MEMBER			The submitter
	 */
	function get_submitter($id)
	{
		return $GLOBALS['SITE_DB']->query_value_null_ok('property_wanted','p_submitter',array('id'=>$id));
	}

	/**
	 * Standard aed_module edit form filler.
	 *
	 * @param  AUTO_LINK		The entry being edited
	 * @return array			A pair: fields, hidden
	 */
	function fill_in_edit_form($id)
	{
		$rows=$GLOBALS['SITE_DB']->query_select('property_wanted',array('*'),array('id'=>$id));
		if (!array_key_exists(0,$rows))
		{
			warn_exit(do_lang_tempcode('MISSING_RESOURCE'));
		}
		$property_row=$rows[0];

		$features=get_property_features($id);
		$types=get_property_types($id);
		$locations=get_property_locations($id);

		list($fields,$hidden)=$this->get_form_fields($property_row,$features,$types,$locations);

		return array($fields,$hidden);
	}

	/**
	 * Standard aed_module add actualiser.
	 *
	 * @return ID_TEXT		The entry added
	 */
	function add_actualisation()
	{
		require_code('property_action');

		if (is_guest()) access_denied('NOT_AS_GUEST');

		list($types,$will_buy,$will_rent,$locations,$guide_price,$monthly_rent,$num_bedrooms,$market_position,$features,$further_details,$display_all_details,$display_time_days,$validated,$notes)=$this->_read_in();

		$id=add_property_listing($types,$will_buy,$will_rent,$locations,$guide_price,$monthly_rent,$num_bedrooms,$market_position,$features,$further_details,$display_all_details,$display_time_days,$validated,$notes);

		return strval($id);
	}

	/**
	 * Actualiser to renew a listing.
	 *
	 * @return tempcode		UI
	 */
	function _renew()
	{
		$title=get_page_title('LISTING_RENEWED');
		
		$id=get_param_integer('id');
		
		$GLOBALS['SITE_DB']->query_update('property_wanted',array('p_validated'=>1,'p_delisting_sent'=>0,'p_edit_time'=>time(),),array('id'=>$id),'',1);
		
		return inform_screen($title,do_lang_tempcode('LISTING_RENEWED_BODY'));
	}

	/**
	 * Read in data to add/edit.
	 *
	 * @return array			Big tuple of data that was read in
	 */
	function _read_in()
	{
		$will_buy=post_param_integer('will_buy',0);
		$will_rent=post_param_integer('will_rent',0);
		$guide_price=@strval(implode('; ',$_POST['guide_price']));
		if (substr($guide_price,-2)=='; ') $guide_price=substr($guide_price,0,strlen($guide_price)-2);
		$monthly_rent=post_param('monthly_rent','');
		$num_bedrooms=post_param('num_bedrooms');
		$market_position=post_param('market_position');
		$further_details=post_param('further_details');
		$display_all_details=post_param_integer('display_all_details',0);
		$display_time_days=post_param_integer('display_time_days');
		$validated=post_param_integer('validated',0);
		$notes=post_param('notes','');
		
		$features=get_property_features();
		$types=get_property_types();
		$locations=get_property_locations();

		return array($types,$will_buy,$will_rent,$locations,$guide_price,$monthly_rent,$num_bedrooms,$market_position,$features,$further_details,$display_all_details,$display_time_days,$validated,$notes);
	}

	/**
	 * Standard aed_module edit actualiser.
	 *
	 * @param  ID_TEXT		 The entry being edited
	 */
	function edit_actualisation($id)
	{
		require_code('property_action');

		$rows=$GLOBALS['SITE_DB']->query_select('property_wanted',array('p_submitter'),array('id'=>intval($id)),'',1);
		if (!array_key_exists(0,$rows)) warn_exit(do_lang_tempcode('MISSING_RESOURCE'));
		$submitter=$rows[0]['p_submitter'];
		check_edit_permission('mid',$submitter);

		list($types,$will_buy,$will_rent,$locations,$guide_price,$monthly_rent,$num_bedrooms,$market_position,$features,$further_details,$display_all_details,$display_time_days,$validated,$notes)=$this->_read_in();

		edit_property_listing(intval($id),$types,$will_buy,$will_rent,$locations,$guide_price,$monthly_rent,$num_bedrooms,$market_position,$features,$further_details,$display_all_details,$display_time_days,$validated,$notes);
	}

	/**
	 * Standard aed_module delete actualiser.
	 *
	 * @param  ID_TEXT		 The entry being deleted
	 */
	function delete_actualisation($id)
	{
		require_code('property_action');

		$rows=$GLOBALS['SITE_DB']->query_select('property_wanted',array('p_submitter'),array('id'=>intval($id)),'',1);
		if (!array_key_exists(0,$rows)) warn_exit(do_lang_tempcode('MISSING_RESOURCE'));
		$submitter=$rows[0]['p_submitter'];
		check_delete_permission('mid',$submitter);

		delete_property_listing(intval($id));
	}

	/**
	 * The do-next manager for after content management.
	 *
	 * @param  tempcode		 The title (output of get_page_title)
	 * @param  tempcode		 Some description to show, saying what happened
	 * @param  ?ID_TEXT		 The ID of whatever we are working with (NULL: deleted)
	 * @return tempcode		 The UI
	 */
	function do_next_manager($title,$description,$id)
	{
		// Show it worked / Refresh
		if ((is_null($id)) || ($id==''))
		{
			$url=build_url(array('page'=>'_SELF','type'=>'my_listings'),'_SELF');
		} else
		{
			$url=build_url(array('page'=>'_SELF','type'=>'view','id'=>$id),'_SELF');
		}
		assign_refresh($url,1.0);
		return redirect_screen($title,$url,do_lang_tempcode('SUCCESS'));
	}

	function get_form_fields_portfolio($portfolio_row=NULL,$features=NULL)
	{
		if (is_guest()) access_denied('NOT_AS_GUEST');

		$fields=new ocp_tempcode();
		$hidden=new ocp_tempcode();

		// Fields
		$fields->attach(form_input_text(do_lang_tempcode('PROPERTY_ADDRESS'),do_lang_tempcode('DESCRIPTION_PROPERTY_ADDRESS'),'address',is_null($portfolio_row)?'':$portfolio_row['o_address'],false));
		$_types=get_nice_property_type_list(is_null($portfolio_row)?NULL:array($portfolio_row['o_type']),false);
		$fields->attach(form_input_list(do_lang_tempcode('PROPERTY_TYPE_PORTFOLIO'),do_lang_tempcode('DESCRIPTION_PROPERTY_TYPE_PORTFOLIO'),'type',$_types));
		$fields->attach(form_input_line(do_lang_tempcode('PPRICE_sale_PORTFOLIO'),do_lang_tempcode('DESCRIPTION_PPRICE_sale_PORTFOLIO'),'asking_price',is_null($portfolio_row)?'':$portfolio_row['o_asking_price'],false));
		$fields->attach(form_input_line(do_lang_tempcode('PPRICE_let_PORTFOLIO'),do_lang_tempcode('DESCRIPTION_PPRICE_let_PORTFOLIO'),'monthly_rent',is_null($portfolio_row)?'':$portfolio_row['o_monthly_rent'],false));
		$fields->attach(form_input_list(do_lang_tempcode('NUM_BEDROOMS_PORTFOLIO'),do_lang_tempcode('DESCRIPTION_NUM_BEDROOMS_PORTFOLIO'),'num_bedrooms',get_nice_num_bedrooms_list(is_null($portfolio_row)?'':$portfolio_row['o_num_bedrooms'],false)));

		// Photos
		if (is_null($portfolio_row))
		{
			$photo_main='';
			$photo_aux_1='';
			$photo_aux_2='';
			$photo_aux_3='';
		} else
		{
			$photo_main=$portfolio_row['o_photo_main'];
			$photo_aux_1=$portfolio_row['o_photo_aux_1'];
			$photo_aux_2=$portfolio_row['o_photo_aux_2'];
			$photo_aux_3=$portfolio_row['o_photo_aux_3'];
			$hidden->attach(form_input_hidden('editing_from',strval($portfolio_row['id'])));
		}
		$phelp=do_lang_tempcode('PROPERTY_SUBHEADING_PHOTOGRAPHS_DESCRIPTION');
		if (($photo_main!='') || ($photo_aux_1!='') || ($photo_aux_2!='') || ($photo_aux_3!=''))
			$phelp->attach(do_lang_tempcode('PROPERTY_SUBHEADING_PHOTOGRAPHS_DESCRIPTION_EDIT'));
		$fields->attach(do_template('FORM_SCREEN_FIELD_SPACER',array('TITLE'=>do_lang_tempcode('PROPERTY_SUBHEADING_PHOTOGRAPHS'),'HELP'=>$phelp)));
		$fields->attach(form_input_upload(do_lang_tempcode('PHOTO_MAIN'),do_lang_tempcode('DESCRIPTION_PHOTO_MAIN'),'photo_main',false,$photo_main));
		$fields->attach(form_input_upload(do_lang_tempcode('PHOTO_AUX_1'),do_lang_tempcode('DESCRIPTION_PHOTO_AUX_1'),'photo_aux_1',false,$photo_aux_1));
		$fields->attach(form_input_upload(do_lang_tempcode('PHOTO_AUX_2'),do_lang_tempcode('DESCRIPTION_PHOTO_AUX_2'),'photo_aux_2',false,$photo_aux_2));
		$fields->attach(form_input_upload(do_lang_tempcode('PHOTO_AUX_3'),do_lang_tempcode('DESCRIPTION_PHOTO_AUX_3'),'photo_aux_3',false,$photo_aux_3));

		// Features
		$fields->attach(do_template('FORM_SCREEN_FIELD_SPACER',array('TITLE'=>do_lang_tempcode('PROPERTY_SUBHEADING_FEATURES_PORTFOLIO'),'HELP'=>do_lang_tempcode('PROPERTY_SUBHEADING_FEATURES_DESCRIPTION_PORTFOLIO'))));
		$_features=get_nice_property_features_list($features);
		$fields->attach(form_input_various_ticks($_features,do_lang_tempcode('DESCRIPTION_FEATURES_PORTFOLIO'),NULL,do_lang_tempcode('FEATURES'),true));
		$fields->attach(form_input_huge(do_lang_tempcode('FURTHER_DETAILS'),do_lang_tempcode('DESCRIPTION_FURTHER_DETAILS_PORTFOLIO'),'further_details',is_null($portfolio_row)?'':get_translated_text($portfolio_row['o_further_details']),true));
		$fields->attach(form_input_line(do_lang_tempcode('FURTHER_DETAILS_LINK'),do_lang_tempcode('DESCRIPTION_FURTHER_DETAILS_LINK'),'further_details_link',is_null($portfolio_row)?'':$portfolio_row['o_further_details_link'],false));

		// Mini fields
		$mini_fields=new ocp_tempcode();
		$mini_fields->attach(form_input_line(do_lang_tempcode('FURTHER_DETAILS_LINK'),do_lang_tempcode('DESCRIPTION_FURTHER_DETAILS_LINK_2'),'further_details_link',is_null($portfolio_row)?'':$portfolio_row['o_further_details_link'],true));

		return array(make_string_tempcode($fields->evaluate()),$hidden,$mini_fields);
	}

	/**
	 * Interface to respond to a listing.
	 *
	 * @return tempcode		UI
	 */
	function respond()
	{
		$title=get_page_title('RESPOND_TO_LISTING');
		
		$id=get_param_integer('id');

		require_code('property_portfolios');

		require_code('form_templates');

		$portfolio_id=post_param_integer('portfolio_id',NULL);

		$portfolio_rows=list_to_map('id',$GLOBALS['SITE_DB']->query_select('property_portfolio',array('*'),array('o_member_id'=>get_member()),'ORDER BY id DESC'));
		if (is_null($portfolio_id))
		{
			if (count($portfolio_rows)>0)
			{
				// Let them choose a portfolio row
				$portfolios=new ocp_tempcode();
				$portfolios->attach(form_input_list_entry('-1',false,do_lang('CLEAN_RESPONSE')));
				foreach ($portfolio_rows as $row)
				{
					$portfolios->attach(form_input_list_entry(strval($row['id']),false,get_timezoned_date($row['o_add_time'],true).' - '.substr(str_replace(chr(10),', ',trim($row['o_address'])),0,12)));
				}
				$fields=form_input_list(do_lang_tempcode('PAST_RESPONSE'),do_lang_tempcode('DESCRIPTION_PAST_RESPONSE'),'portfolio_id',$portfolios,NULL,false,false);
				$post_url=get_self_url(false,false,NULL,false,true);
				$text=do_lang_tempcode('CHOOSE_FROM_PORTFOLIO');
				return do_template('FORM_SCREEN',array('SKIP_VALIDATION'=>true,'HIDDEN'=>'','SUBMIT_NAME'=>do_lang_tempcode('PROCEED'),'TITLE'=>$title,'FIELDS'=>$fields,'URL'=>$post_url,'TEXT'=>$text,'JAVASCRIPT'=>''));
			}
			$portfolio_row=NULL;
			$features=NULL;
		} else
		{
			if ($portfolio_id==-1)
			{
				$portfolio_row=NULL;
				$features=NULL;
			} else
			{
				$portfolio_row=$portfolio_rows[$portfolio_id];
				$features=get_property_portfolio_features($portfolio_id);
			}
		}

		list($fields,$hidden,$mini_fields)=$this->get_form_fields_portfolio($portfolio_row,$features);

		$post_url=build_url(array('page'=>'_SELF','type'=>'_respond','id'=>$id),'_SELF');

		$mini_form=do_template('FORM',array('SKIP_REQUIRED'=>true,'TEXT'=>'','SKIP_VALIDATION'=>true,'HIDDEN'=>$hidden,'SUBMIT_NAME'=>do_lang_tempcode('QUICK_PROPERTY_REPLY_DO'),'FIELDS'=>$mini_fields,'URL'=>$post_url));

		$main_form=do_template('FORM',array('SKIP_REQUIRED'=>true,'TEXT'=>'','SKIP_VALIDATION'=>true,'HIDDEN'=>$hidden,'SUBMIT_NAME'=>do_lang_tempcode('PROCEED'),'FIELDS'=>$fields,'URL'=>$post_url));

		return do_template('PROPERTY_RESPONSE_FORM_SCREEN',array('TITLE'=>$title,'MINI_FORM'=>$mini_form,'MAIN_FORM'=>$main_form));
	}

	/**
	 * Actualiser to respond to a listing.
	 *
	 * @return tempcode		UI
	 */
	function _respond()
	{
		$title=get_page_title('RESPOND_TO_LISTING');

		require_code('property_portfolios');

		$id=get_param_integer('id');
		
		$_property_row=$GLOBALS['SITE_DB']->query_select('property_wanted',array('*'),array('id'=>$id),'',1);
		if (!array_key_exists(0,$_property_row)) warn_exit(do_lang_tempcode('MISSING_RESOURCE'));

		// Save to portfolio
		$features=get_property_portfolio_features();
		require_code('property_portfolios');
		list($photo_main,$photo_aux_1,$photo_aux_2,$photo_aux_3,$photo_main_thumb,$photo_aux_1_thumb,$photo_aux_2_thumb,$photo_aux_3_thumb)=handle_property_portfolio_uploading();
		$portfolio_id=add_property_portfolio($id,$features,post_param_integer('type',NULL),post_param('address',''),post_param('asking_price',''),post_param('monthly_rent',''),post_param('num_bedrooms',''),post_param('further_details',''),post_param('further_details_link',''),$photo_main,$photo_aux_1,$photo_aux_2,$photo_aux_3,$photo_main_thumb,$photo_aux_1_thumb,$photo_aux_2_thumb,$photo_aux_3_thumb);

		// Send email
		require_code('mail');
		$to_name=$GLOBALS['FORUM_DRIVER']->get_username($_property_row[0]['p_submitter']);
		$to_email=$GLOBALS['FORUM_DRIVER']->get_member_email_address($_property_row[0]['p_submitter']);
		$html=do_template('PROPERTY_AVAILABLE_NOTIFICATION_MAIL',array(
			'ADDRESS'=>post_param('address',''),
			'TYPE'=>is_null(post_param_integer('type',NULL))?'':$GLOBALS['SITE_DB']->query_value('property_types','t_text',array('id'=>post_param_integer('type',NULL))),
			'ASKING_PRICE'=>post_param('asking_price',''),
			'MONTHLY_RENT'=>post_param('monthly_rent',''),
			'NUM_BEDROOMS'=>(post_param('num_bedrooms','')=='')?'':do_lang('NB_'.post_param('num_bedrooms','')),
			'PHOTO_MAIN'=>url_is_local($photo_main)?(get_custom_base_url().'/'.$photo_main):'',
			'PHOTO_AUX_1'=>url_is_local($photo_aux_1)?(get_custom_base_url().'/'.$photo_aux_1):'',
			'PHOTO_AUX_2'=>url_is_local($photo_aux_2)?(get_custom_base_url().'/'.$photo_aux_2):'',
			'PHOTO_AUX_3'=>url_is_local($photo_aux_3)?(get_custom_base_url().'/'.$photo_aux_3):'',
			'PHOTO_MAIN_THUMB'=>(url_is_local($photo_main_thumb)&&($photo_main_thumb!=''))?(get_custom_base_url().'/'.$photo_main_thumb):'',
			'PHOTO_AUX_1_THUMB'=>(url_is_local($photo_aux_1_thumb)&&($photo_aux_1_thumb!=''))?(get_custom_base_url().'/'.$photo_aux_1_thumb):'',
			'PHOTO_AUX_2_THUMB'=>(url_is_local($photo_aux_2_thumb)&&($photo_aux_2_thumb!=''))?(get_custom_base_url().'/'.$photo_aux_2_thumb):'',
			'PHOTO_AUX_3_THUMB'=>(url_is_local($photo_aux_3_thumb)&&($photo_aux_3_thumb!=''))?(get_custom_base_url().'/'.$photo_aux_3_thumb):'',
			'FEATURES'=>get_property_portfolio_features($portfolio_id),
			'FURTHER_DETAILS'=>post_param('further_details',''),
			'FURTHER_DETAILS_LINK'=>post_param('further_details_link'),
			'VIEW_URL'=>build_url(array('page'=>'_SELF','type'=>'view_response','id'=>$portfolio_id),'_SELF'),
			'LISTING_URL'=>build_url(array('page'=>'_SELF','type'=>'view','id'=>$id),'_SELF'),
		));

		mail_wrap(do_lang('PROPERTY_AVAILABLE_NOTIFICATION'),$html->evaluate(),array($to_email),array($to_name),$GLOBALS['FORUM_DRIVER']->get_username(get_member()));

		return inform_screen($title,do_lang_tempcode('ADVERTISER_CONTACTED'));
	}
	
	/**
	 * View a saved response (using portfolio table).
	 *
	 * @return tempcode		UI
	 */
	function view_response()
	{
		$title=get_page_title('PROPERTY_AVAILABLE_TITLE');

		$id=get_param_integer('id');

		require_code('property_portfolios');
		require_lang('ocf');
		require_css('property');

		$portfolio_rows=$GLOBALS['SITE_DB']->query_select('property_portfolio',array('*'),array('id'=>$id),'',1);
		if (!array_key_exists(0,$portfolio_rows)) warn_exit(do_lang_tempcode('MISSING_RESOURCE'));
		$portfolio_row=$portfolio_rows[0];

		$photo_main=$portfolio_row['o_photo_main'];
		$photo_aux_1=$portfolio_row['o_photo_aux_1'];
		$photo_aux_2=$portfolio_row['o_photo_aux_2'];
		$photo_aux_3=$portfolio_row['o_photo_aux_3'];

		$photo_main_thumb=$portfolio_row['o_photo_main_thumb'];
		$photo_aux_1_thumb=$portfolio_row['o_photo_aux_1_thumb'];
		$photo_aux_2_thumb=$portfolio_row['o_photo_aux_2_thumb'];
		$photo_aux_3_thumb=$portfolio_row['o_photo_aux_3_thumb'];

		return do_template('PROPERTY_AVAILABLE_SCREEN',array(
			'TITLE'=>$title,
			'ADDRESS'=>$portfolio_row['o_address'],
			'TYPE'=>is_null($portfolio_row['o_type'])?'':$GLOBALS['SITE_DB']->query_value('property_types','t_text',array('id'=>$portfolio_row['o_type'])),
			'ASKING_PRICE'=>$portfolio_row['o_asking_price'],
			'MONTHLY_RENT'=>$portfolio_row['o_monthly_rent'],
			'NUM_BEDROOMS'=>($portfolio_row['o_num_bedrooms']=='')?'':do_lang('NB_'.$portfolio_row['o_num_bedrooms']),
			'PHOTO_MAIN'=>url_is_local($photo_main)?(get_custom_base_url().'/'.$photo_main):'',
			'PHOTO_AUX_1'=>url_is_local($photo_aux_1)?(get_custom_base_url().'/'.$photo_aux_1):'',
			'PHOTO_AUX_2'=>url_is_local($photo_aux_2)?(get_custom_base_url().'/'.$photo_aux_2):'',
			'PHOTO_AUX_3'=>url_is_local($photo_aux_3)?(get_custom_base_url().'/'.$photo_aux_3):'',
			'PHOTO_MAIN_THUMB'=>(url_is_local($photo_main_thumb)&&($photo_main_thumb!=''))?(get_custom_base_url().'/'.$photo_main_thumb):'',
			'PHOTO_AUX_1_THUMB'=>(url_is_local($photo_aux_1_thumb)&&($photo_aux_1_thumb!=''))?(get_custom_base_url().'/'.$photo_aux_1_thumb):'',
			'PHOTO_AUX_2_THUMB'=>(url_is_local($photo_aux_2_thumb)&&($photo_aux_2_thumb!=''))?(get_custom_base_url().'/'.$photo_aux_2_thumb):'',
			'PHOTO_AUX_3_THUMB'=>(url_is_local($photo_aux_3_thumb)&&($photo_aux_3_thumb!=''))?(get_custom_base_url().'/'.$photo_aux_3_thumb):'',
			'FEATURES'=>get_property_portfolio_features($id),
			'FURTHER_DETAILS'=>get_translated_tempcode($portfolio_row['o_further_details']),
			'FURTHER_DETAILS_LINK'=>$portfolio_row['o_further_details_link'],
			'LISTING_URL'=>build_url(array('page'=>'_SELF','type'=>'view','id'=>$portfolio_row['o_for']),'_SELF'),
			'SENDER'=>strval($portfolio_row['o_member_id']),
		));
	}
}

