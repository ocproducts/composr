CREATE TABLE cms_aggregate_type_instances
(
     id integer auto_increment NULL,
     aggregate_label varchar(255) NOT NULL,
     aggregate_type varchar(80) NOT NULL,
     other_parameters longtext NOT NULL,
     add_time integer unsigned NOT NULL,
     edit_time integer unsigned NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

