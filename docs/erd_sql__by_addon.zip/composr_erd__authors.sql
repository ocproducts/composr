CREATE TABLE cms_authors
(
     author varchar(80) NULL,
     url varchar(255) NOT NULL,
     member_id integer NOT NULL,
     description integer NOT NULL,
     skills integer NOT NULL,

     PRIMARY KEY (author)
) engine=InnoDB;

CREATE TABLE cms_f_members
(
     id integer auto_increment NULL,
     m_username varchar(80) NOT NULL,
     m_pass_hash_salted varchar(255) NOT NULL,
     m_pass_salt varchar(255) NOT NULL,
     m_theme varchar(80) NOT NULL,
     m_avatar_url varchar(255) NOT NULL,
     m_validated tinyint(1) NOT NULL,
     m_validated_email_confirm_code varchar(255) NOT NULL,
     m_cache_num_posts integer NOT NULL,
     m_cache_warnings integer NOT NULL,
     m_join_time integer unsigned NOT NULL,
     m_timezone_offset varchar(255) NOT NULL,
     m_primary_group integer NOT NULL,
     m_last_visit_time integer unsigned NOT NULL,
     m_last_submit_time integer unsigned NOT NULL,
     m_signature integer NOT NULL,
     m_is_perm_banned tinyint(1) NOT NULL,
     m_preview_posts tinyint(1) NOT NULL,
     m_dob_day tinyint NOT NULL,
     m_dob_month tinyint NOT NULL,
     m_dob_year integer NOT NULL,
     m_reveal_age tinyint(1) NOT NULL,
     m_email_address varchar(255) NOT NULL,
     m_title varchar(255) NOT NULL,
     m_photo_url varchar(255) NOT NULL,
     m_photo_thumb_url varchar(255) NOT NULL,
     m_views_signatures tinyint(1) NOT NULL,
     m_auto_monitor_contrib_content tinyint(1) NOT NULL,
     m_language varchar(80) NOT NULL,
     m_ip_address varchar(40) NOT NULL,
     m_allow_emails tinyint(1) NOT NULL,
     m_allow_emails_from_staff tinyint(1) NOT NULL,
     m_highlighted_name tinyint(1) NOT NULL,
     m_pt_allow varchar(255) NOT NULL,
     m_pt_rules_text integer NOT NULL,
     m_max_email_attach_size_mb integer NOT NULL,
     m_password_change_code varchar(255) NOT NULL,
     m_password_compat_scheme varchar(80) NOT NULL,
     m_on_probation_until integer unsigned NOT NULL,
     m_profile_views integer unsigned NOT NULL,
     m_total_sessions integer unsigned NOT NULL,
     m_auto_mark_read tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_groups
(
     id integer auto_increment NULL,
     g_name integer NOT NULL,
     g_is_default tinyint(1) NOT NULL,
     g_is_presented_at_install tinyint(1) NOT NULL,
     g_is_super_admin tinyint(1) NOT NULL,
     g_is_super_moderator tinyint(1) NOT NULL,
     g_group_leader integer NOT NULL,
     g_title integer NOT NULL,
     g_promotion_target integer NOT NULL,
     g_promotion_threshold integer NOT NULL,
     g_flood_control_submit_secs integer NOT NULL,
     g_flood_control_access_secs integer NOT NULL,
     g_gift_points_base integer NOT NULL,
     g_gift_points_per_day integer NOT NULL,
     g_max_daily_upload_mb integer NOT NULL,
     g_max_attachments_per_post integer NOT NULL,
     g_max_avatar_width integer NOT NULL,
     g_max_avatar_height integer NOT NULL,
     g_max_post_length_comcode integer NOT NULL,
     g_max_sig_length_comcode integer NOT NULL,
     g_enquire_on_new_ips tinyint(1) NOT NULL,
     g_rank_image varchar(80) NOT NULL,
     g_hidden tinyint(1) NOT NULL,
     g_order integer NOT NULL,
     g_rank_image_pri_only tinyint(1) NOT NULL,
     g_open_membership tinyint(1) NOT NULL,
     g_is_private_club tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;


CREATE INDEX `authors.member_id` ON cms_authors(member_id);
ALTER TABLE cms_authors ADD FOREIGN KEY `authors.member_id` (member_id) REFERENCES cms_f_members (id);

CREATE INDEX `f_members.m_primary_group` ON cms_f_members(m_primary_group);
ALTER TABLE cms_f_members ADD FOREIGN KEY `f_members.m_primary_group` (m_primary_group) REFERENCES cms_f_groups (id);

CREATE INDEX `f_groups.g_group_leader` ON cms_f_groups(g_group_leader);
ALTER TABLE cms_f_groups ADD FOREIGN KEY `f_groups.g_group_leader` (g_group_leader) REFERENCES cms_f_members (id);

CREATE INDEX `f_groups.g_promotion_target` ON cms_f_groups(g_promotion_target);
ALTER TABLE cms_f_groups ADD FOREIGN KEY `f_groups.g_promotion_target` (g_promotion_target) REFERENCES cms_f_groups (id);
