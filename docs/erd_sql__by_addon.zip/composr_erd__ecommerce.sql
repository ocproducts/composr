CREATE TABLE cms_trans_expecting
(
     id varchar(80) NULL,
     e_purchase_id varchar(80) NOT NULL,
     e_item_name varchar(255) NOT NULL,
     e_member_id integer NOT NULL,
     e_amount varchar(255) NOT NULL,
     e_currency varchar(80) NOT NULL,
     e_ip_address varchar(40) NOT NULL,
     e_session_id varchar(80) NOT NULL,
     e_time integer unsigned NOT NULL,
     e_length integer NOT NULL,
     e_length_units varchar(80) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_transactions
(
     id varchar(80) NULL,
     t_type_code varchar(80) NOT NULL,
     t_purchase_id varchar(80) NOT NULL,
     t_status varchar(255) NOT NULL,
     t_reason varchar(255) NOT NULL,
     t_amount varchar(255) NOT NULL,
     t_currency varchar(80) NOT NULL,
     t_parent_txn_id varchar(80) NOT NULL,
     t_time integer unsigned NULL,
     t_pending_reason varchar(255) NOT NULL,
     t_memo longtext NOT NULL,
     t_via varchar(80) NOT NULL,

     PRIMARY KEY (id,t_time)
) engine=InnoDB;

CREATE TABLE cms_subscriptions
(
     id integer auto_increment NULL,
     s_type_code varchar(80) NOT NULL,
     s_member_id integer NOT NULL,
     s_state varchar(80) NOT NULL,
     s_amount varchar(255) NOT NULL,
     s_purchase_id varchar(80) NOT NULL,
     s_time integer unsigned NOT NULL,
     s_auto_fund_source varchar(80) NOT NULL,
     s_auto_fund_key varchar(255) NOT NULL,
     s_via varchar(80) NOT NULL,
     s_length integer NOT NULL,
     s_length_units varchar(255) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_usergroup_subs
(
     id integer auto_increment NULL,
     s_title integer NOT NULL,
     s_description integer NOT NULL,
     s_cost varchar(255) NOT NULL,
     s_length integer NOT NULL,
     s_length_units varchar(255) NOT NULL,
     s_auto_recur tinyint(1) NOT NULL,
     s_group_id integer NOT NULL,
     s_enabled tinyint(1) NOT NULL,
     s_mail_start integer NOT NULL,
     s_mail_end integer NOT NULL,
     s_mail_uhoh integer NOT NULL,
     s_uses_primary tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_usergroup_sub_mails
(
     id integer auto_increment NULL,
     m_usergroup_sub_id integer NOT NULL,
     m_ref_point varchar(80) NOT NULL,
     m_ref_point_offset integer NOT NULL,
     m_subject integer NOT NULL,
     m_body integer NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_invoices
(
     id integer auto_increment NULL,
     i_type_code varchar(80) NOT NULL,
     i_member_id integer NOT NULL,
     i_state varchar(80) NOT NULL,
     i_amount varchar(255) NOT NULL,
     i_special varchar(255) NOT NULL,
     i_time integer unsigned NOT NULL,
     i_note longtext NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_members
(
     id integer auto_increment NULL,
     m_username varchar(80) NOT NULL,
     m_pass_hash_salted varchar(255) NOT NULL,
     m_pass_salt varchar(255) NOT NULL,
     m_theme varchar(80) NOT NULL,
     m_avatar_url varchar(255) NOT NULL,
     m_validated tinyint(1) NOT NULL,
     m_validated_email_confirm_code varchar(255) NOT NULL,
     m_cache_num_posts integer NOT NULL,
     m_cache_warnings integer NOT NULL,
     m_join_time integer unsigned NOT NULL,
     m_timezone_offset varchar(255) NOT NULL,
     m_primary_group integer NOT NULL,
     m_last_visit_time integer unsigned NOT NULL,
     m_last_submit_time integer unsigned NOT NULL,
     m_signature integer NOT NULL,
     m_is_perm_banned tinyint(1) NOT NULL,
     m_preview_posts tinyint(1) NOT NULL,
     m_dob_day tinyint NOT NULL,
     m_dob_month tinyint NOT NULL,
     m_dob_year integer NOT NULL,
     m_reveal_age tinyint(1) NOT NULL,
     m_email_address varchar(255) NOT NULL,
     m_title varchar(255) NOT NULL,
     m_photo_url varchar(255) NOT NULL,
     m_photo_thumb_url varchar(255) NOT NULL,
     m_views_signatures tinyint(1) NOT NULL,
     m_auto_monitor_contrib_content tinyint(1) NOT NULL,
     m_language varchar(80) NOT NULL,
     m_ip_address varchar(40) NOT NULL,
     m_allow_emails tinyint(1) NOT NULL,
     m_allow_emails_from_staff tinyint(1) NOT NULL,
     m_highlighted_name tinyint(1) NOT NULL,
     m_pt_allow varchar(255) NOT NULL,
     m_pt_rules_text integer NOT NULL,
     m_max_email_attach_size_mb integer NOT NULL,
     m_password_change_code varchar(255) NOT NULL,
     m_password_compat_scheme varchar(80) NOT NULL,
     m_on_probation_until integer unsigned NOT NULL,
     m_profile_views integer unsigned NOT NULL,
     m_total_sessions integer unsigned NOT NULL,
     m_auto_mark_read tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_groups
(
     id integer auto_increment NULL,
     g_name integer NOT NULL,
     g_is_default tinyint(1) NOT NULL,
     g_is_presented_at_install tinyint(1) NOT NULL,
     g_is_super_admin tinyint(1) NOT NULL,
     g_is_super_moderator tinyint(1) NOT NULL,
     g_group_leader integer NOT NULL,
     g_title integer NOT NULL,
     g_promotion_target integer NOT NULL,
     g_promotion_threshold integer NOT NULL,
     g_flood_control_submit_secs integer NOT NULL,
     g_flood_control_access_secs integer NOT NULL,
     g_gift_points_base integer NOT NULL,
     g_gift_points_per_day integer NOT NULL,
     g_max_daily_upload_mb integer NOT NULL,
     g_max_attachments_per_post integer NOT NULL,
     g_max_avatar_width integer NOT NULL,
     g_max_avatar_height integer NOT NULL,
     g_max_post_length_comcode integer NOT NULL,
     g_max_sig_length_comcode integer NOT NULL,
     g_enquire_on_new_ips tinyint(1) NOT NULL,
     g_rank_image varchar(80) NOT NULL,
     g_hidden tinyint(1) NOT NULL,
     g_order integer NOT NULL,
     g_rank_image_pri_only tinyint(1) NOT NULL,
     g_open_membership tinyint(1) NOT NULL,
     g_is_private_club tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;


CREATE INDEX `trans_expecting.e_member_id` ON cms_trans_expecting(e_member_id);
ALTER TABLE cms_trans_expecting ADD FOREIGN KEY `trans_expecting.e_member_id` (e_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `subscriptions.s_member_id` ON cms_subscriptions(s_member_id);
ALTER TABLE cms_subscriptions ADD FOREIGN KEY `subscriptions.s_member_id` (s_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `f_usergroup_subs.s_group_id` ON cms_f_usergroup_subs(s_group_id);
ALTER TABLE cms_f_usergroup_subs ADD FOREIGN KEY `f_usergroup_subs.s_group_id` (s_group_id) REFERENCES cms_f_groups (id);

CREATE INDEX `f_usergroup_sub_mails.m_usergroup_sub_id` ON cms_f_usergroup_sub_mails(m_usergroup_sub_id);
ALTER TABLE cms_f_usergroup_sub_mails ADD FOREIGN KEY `f_usergroup_sub_mails.m_usergroup_sub_id` (m_usergroup_sub_id) REFERENCES cms_f_usergroup_subs (id);

CREATE INDEX `invoices.i_member_id` ON cms_invoices(i_member_id);
ALTER TABLE cms_invoices ADD FOREIGN KEY `invoices.i_member_id` (i_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `f_members.m_primary_group` ON cms_f_members(m_primary_group);
ALTER TABLE cms_f_members ADD FOREIGN KEY `f_members.m_primary_group` (m_primary_group) REFERENCES cms_f_groups (id);

CREATE INDEX `f_groups.g_group_leader` ON cms_f_groups(g_group_leader);
ALTER TABLE cms_f_groups ADD FOREIGN KEY `f_groups.g_group_leader` (g_group_leader) REFERENCES cms_f_members (id);

CREATE INDEX `f_groups.g_promotion_target` ON cms_f_groups(g_promotion_target);
ALTER TABLE cms_f_groups ADD FOREIGN KEY `f_groups.g_promotion_target` (g_promotion_target) REFERENCES cms_f_groups (id);
