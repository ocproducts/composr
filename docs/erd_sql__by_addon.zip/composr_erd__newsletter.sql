CREATE TABLE cms_newsletter_subscribers
(
     id integer auto_increment NULL,
     email varchar(255) NOT NULL,
     join_time integer unsigned NOT NULL,
     code_confirm integer NOT NULL,
     the_password varchar(255) NOT NULL,
     pass_salt varchar(80) NOT NULL,
     language varchar(80) NOT NULL,
     n_forename varchar(255) NOT NULL,
     n_surname varchar(255) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_newsletter_archive
(
     id integer auto_increment NULL,
     date_and_time integer NOT NULL,
     subject varchar(255) NOT NULL,
     newsletter longtext NOT NULL,
     language varchar(80) NOT NULL,
     importance_level integer NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_newsletters
(
     id integer auto_increment NULL,
     title integer NOT NULL,
     description integer NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_newsletter_subscribe
(
     newsletter_id integer NULL,
     the_level tinyint NOT NULL,
     email varchar(255) NULL,

     PRIMARY KEY (newsletter_id,email)
) engine=InnoDB;

CREATE TABLE cms_newsletter_drip_send
(
     id integer auto_increment NULL,
     d_inject_time integer unsigned NOT NULL,
     d_subject varchar(255) NOT NULL,
     d_message integer NOT NULL,
     d_html_only tinyint(1) NOT NULL,
     d_to_email varchar(255) NOT NULL,
     d_to_name varchar(255) NOT NULL,
     d_from_email varchar(255) NOT NULL,
     d_from_name varchar(255) NOT NULL,
     d_priority tinyint NOT NULL,
     d_template varchar(80) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_newsletter_periodic
(
     id integer auto_increment NULL,
     np_message longtext NOT NULL,
     np_subject longtext NOT NULL,
     np_lang varchar(5) NOT NULL,
     np_send_details longtext NOT NULL,
     np_html_only tinyint(1) NOT NULL,
     np_from_email varchar(255) NOT NULL,
     np_from_name varchar(255) NOT NULL,
     np_priority tinyint NOT NULL,
     np_csv_data longtext NOT NULL,
     np_frequency varchar(255) NOT NULL,
     np_day tinyint NOT NULL,
     np_in_full tinyint(1) NOT NULL,
     np_template varchar(80) NOT NULL,
     np_last_sent integer unsigned NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;


CREATE INDEX `newsletter_subscribe.newsletter_id` ON cms_newsletter_subscribe(newsletter_id);
ALTER TABLE cms_newsletter_subscribe ADD FOREIGN KEY `newsletter_subscribe.newsletter_id` (newsletter_id) REFERENCES cms_newsletters (id);
