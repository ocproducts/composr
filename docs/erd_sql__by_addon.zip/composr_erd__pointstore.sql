CREATE TABLE cms_prices
(
     name varchar(80) NULL,
     price integer NOT NULL,

     PRIMARY KEY (name)
) engine=InnoDB;

CREATE TABLE cms_sales
(
     id integer auto_increment NULL,
     date_and_time integer unsigned NOT NULL,
     memberid integer NOT NULL,
     purchasetype varchar(80) NOT NULL,
     details varchar(255) NOT NULL,
     details2 varchar(255) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_pstore_customs
(
     id integer auto_increment NULL,
     c_title integer NOT NULL,
     c_description integer NOT NULL,
     c_mail_subject integer NOT NULL,
     c_mail_body integer NOT NULL,
     c_enabled tinyint(1) NOT NULL,
     c_cost integer NOT NULL,
     c_one_per_member tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_pstore_permissions
(
     id integer auto_increment NULL,
     p_title integer NOT NULL,
     p_description integer NOT NULL,
     p_mail_subject integer NOT NULL,
     p_mail_body integer NOT NULL,
     p_enabled tinyint(1) NOT NULL,
     p_cost integer NOT NULL,
     p_hours integer NOT NULL,
     p_type varchar(80) NOT NULL,
     p_privilege varchar(80) NOT NULL,
     p_zone varchar(80) NOT NULL,
     p_page varchar(80) NOT NULL,
     p_module varchar(80) NOT NULL,
     p_category varchar(80) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_members
(
     id integer auto_increment NULL,
     m_username varchar(80) NOT NULL,
     m_pass_hash_salted varchar(255) NOT NULL,
     m_pass_salt varchar(255) NOT NULL,
     m_theme varchar(80) NOT NULL,
     m_avatar_url varchar(255) NOT NULL,
     m_validated tinyint(1) NOT NULL,
     m_validated_email_confirm_code varchar(255) NOT NULL,
     m_cache_num_posts integer NOT NULL,
     m_cache_warnings integer NOT NULL,
     m_join_time integer unsigned NOT NULL,
     m_timezone_offset varchar(255) NOT NULL,
     m_primary_group integer NOT NULL,
     m_last_visit_time integer unsigned NOT NULL,
     m_last_submit_time integer unsigned NOT NULL,
     m_signature integer NOT NULL,
     m_is_perm_banned tinyint(1) NOT NULL,
     m_preview_posts tinyint(1) NOT NULL,
     m_dob_day tinyint NOT NULL,
     m_dob_month tinyint NOT NULL,
     m_dob_year integer NOT NULL,
     m_reveal_age tinyint(1) NOT NULL,
     m_email_address varchar(255) NOT NULL,
     m_title varchar(255) NOT NULL,
     m_photo_url varchar(255) NOT NULL,
     m_photo_thumb_url varchar(255) NOT NULL,
     m_views_signatures tinyint(1) NOT NULL,
     m_auto_monitor_contrib_content tinyint(1) NOT NULL,
     m_language varchar(80) NOT NULL,
     m_ip_address varchar(40) NOT NULL,
     m_allow_emails tinyint(1) NOT NULL,
     m_allow_emails_from_staff tinyint(1) NOT NULL,
     m_highlighted_name tinyint(1) NOT NULL,
     m_pt_allow varchar(255) NOT NULL,
     m_pt_rules_text integer NOT NULL,
     m_max_email_attach_size_mb integer NOT NULL,
     m_password_change_code varchar(255) NOT NULL,
     m_password_compat_scheme varchar(80) NOT NULL,
     m_on_probation_until integer unsigned NOT NULL,
     m_profile_views integer unsigned NOT NULL,
     m_total_sessions integer unsigned NOT NULL,
     m_auto_mark_read tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_privilege_list
(
     p_section varchar(80) NOT NULL,
     the_name varchar(80) NULL,
     the_default tinyint(1) NULL,

     PRIMARY KEY (the_name,the_default)
) engine=InnoDB;

CREATE TABLE cms_zones
(
     zone_name varchar(80) NULL,
     zone_title integer NOT NULL,
     zone_default_page varchar(80) NOT NULL,
     zone_header_text integer NOT NULL,
     zone_theme varchar(80) NOT NULL,
     zone_require_session tinyint(1) NOT NULL,

     PRIMARY KEY (zone_name)
) engine=InnoDB;

CREATE TABLE cms_modules
(
     module_the_name varchar(80) NULL,
     module_author varchar(80) NOT NULL,
     module_organisation varchar(80) NOT NULL,
     module_hacked_by varchar(80) NOT NULL,
     module_hack_version integer NOT NULL,
     module_version integer NOT NULL,

     PRIMARY KEY (module_the_name)
) engine=InnoDB;

CREATE TABLE cms_f_groups
(
     id integer auto_increment NULL,
     g_name integer NOT NULL,
     g_is_default tinyint(1) NOT NULL,
     g_is_presented_at_install tinyint(1) NOT NULL,
     g_is_super_admin tinyint(1) NOT NULL,
     g_is_super_moderator tinyint(1) NOT NULL,
     g_group_leader integer NOT NULL,
     g_title integer NOT NULL,
     g_promotion_target integer NOT NULL,
     g_promotion_threshold integer NOT NULL,
     g_flood_control_submit_secs integer NOT NULL,
     g_flood_control_access_secs integer NOT NULL,
     g_gift_points_base integer NOT NULL,
     g_gift_points_per_day integer NOT NULL,
     g_max_daily_upload_mb integer NOT NULL,
     g_max_attachments_per_post integer NOT NULL,
     g_max_avatar_width integer NOT NULL,
     g_max_avatar_height integer NOT NULL,
     g_max_post_length_comcode integer NOT NULL,
     g_max_sig_length_comcode integer NOT NULL,
     g_enquire_on_new_ips tinyint(1) NOT NULL,
     g_rank_image varchar(80) NOT NULL,
     g_hidden tinyint(1) NOT NULL,
     g_order integer NOT NULL,
     g_rank_image_pri_only tinyint(1) NOT NULL,
     g_open_membership tinyint(1) NOT NULL,
     g_is_private_club tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;


CREATE INDEX `sales.memberid` ON cms_sales(memberid);
ALTER TABLE cms_sales ADD FOREIGN KEY `sales.memberid` (memberid) REFERENCES cms_f_members (id);

CREATE INDEX `pstore_permissions.p_privilege` ON cms_pstore_permissions(p_privilege);
ALTER TABLE cms_pstore_permissions ADD FOREIGN KEY `pstore_permissions.p_privilege` (p_privilege) REFERENCES cms_privilege_list (the_name);

CREATE INDEX `pstore_permissions.p_zone` ON cms_pstore_permissions(p_zone);
ALTER TABLE cms_pstore_permissions ADD FOREIGN KEY `pstore_permissions.p_zone` (p_zone) REFERENCES cms_zones (zone_name);

CREATE INDEX `pstore_permissions.p_page` ON cms_pstore_permissions(p_page);
ALTER TABLE cms_pstore_permissions ADD FOREIGN KEY `pstore_permissions.p_page` (p_page) REFERENCES cms_modules (module_the_name);

CREATE INDEX `f_members.m_primary_group` ON cms_f_members(m_primary_group);
ALTER TABLE cms_f_members ADD FOREIGN KEY `f_members.m_primary_group` (m_primary_group) REFERENCES cms_f_groups (id);

CREATE INDEX `f_groups.g_group_leader` ON cms_f_groups(g_group_leader);
ALTER TABLE cms_f_groups ADD FOREIGN KEY `f_groups.g_group_leader` (g_group_leader) REFERENCES cms_f_members (id);

CREATE INDEX `f_groups.g_promotion_target` ON cms_f_groups(g_promotion_target);
ALTER TABLE cms_f_groups ADD FOREIGN KEY `f_groups.g_promotion_target` (g_promotion_target) REFERENCES cms_f_groups (id);
