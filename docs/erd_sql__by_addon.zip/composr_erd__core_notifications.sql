CREATE TABLE cms_notification_lockdown
(
     l_notification_code varchar(80) NULL,
     l_setting integer NOT NULL,

     PRIMARY KEY (l_notification_code)
) engine=InnoDB;

