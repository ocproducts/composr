CREATE TABLE cms_match_key_messages
(
     id integer auto_increment NULL,
     k_message integer NOT NULL,
     k_match_key varchar(255) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

