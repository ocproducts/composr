CREATE TABLE cms_content_reviews
(
     content_type varchar(80) NULL,
     content_id varchar(80) NULL,
     review_freq integer NOT NULL,
     next_review_time integer unsigned NOT NULL,
     auto_action varchar(80) NOT NULL,
     review_notification_happened tinyint(1) NOT NULL,
     display_review_status tinyint(1) NOT NULL,
     last_reviewed_time integer unsigned NOT NULL,

     PRIMARY KEY (content_type,content_id)
) engine=InnoDB;

