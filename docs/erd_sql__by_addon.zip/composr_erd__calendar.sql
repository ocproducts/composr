CREATE TABLE cms_calendar_events
(
     id integer auto_increment NULL,
     e_submitter integer NOT NULL,
     e_member_calendar integer NOT NULL,
     e_views integer NOT NULL,
     e_title integer NOT NULL,
     e_content integer NOT NULL,
     e_add_date integer unsigned NOT NULL,
     e_edit_date integer unsigned NOT NULL,
     e_recurrence varchar(80) NOT NULL,
     e_recurrences tinyint NOT NULL,
     e_seg_recurrences tinyint(1) NOT NULL,
     e_start_year integer NOT NULL,
     e_start_month tinyint NOT NULL,
     e_start_day tinyint NOT NULL,
     e_start_monthly_spec_type varchar(80) NOT NULL,
     e_start_hour tinyint NOT NULL,
     e_start_minute tinyint NOT NULL,
     e_end_year integer NOT NULL,
     e_end_month tinyint NOT NULL,
     e_end_day tinyint NOT NULL,
     e_end_monthly_spec_type varchar(80) NOT NULL,
     e_end_hour tinyint NOT NULL,
     e_end_minute tinyint NOT NULL,
     e_timezone varchar(80) NOT NULL,
     e_do_timezone_conv tinyint(1) NOT NULL,
     e_priority tinyint NOT NULL,
     allow_rating tinyint(1) NOT NULL,
     allow_comments tinyint NOT NULL,
     allow_trackbacks tinyint(1) NOT NULL,
     notes longtext NOT NULL,
     e_type integer NOT NULL,
     validated tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_calendar_types
(
     id integer auto_increment NULL,
     t_title integer NOT NULL,
     t_logo varchar(255) NOT NULL,
     t_external_feed varchar(255) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_calendar_reminders
(
     id integer auto_increment NULL,
     e_id integer NOT NULL,
     n_member_id integer NOT NULL,
     n_seconds_before integer NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_calendar_interests
(
     i_member_id integer NULL,
     t_type integer NULL,

     PRIMARY KEY (i_member_id,t_type)
) engine=InnoDB;

CREATE TABLE cms_calendar_jobs
(
     id integer auto_increment NULL,
     j_time integer unsigned NOT NULL,
     j_reminder_id integer NOT NULL,
     j_member_id integer NOT NULL,
     j_event_id integer NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_members
(
     id integer auto_increment NULL,
     m_username varchar(80) NOT NULL,
     m_pass_hash_salted varchar(255) NOT NULL,
     m_pass_salt varchar(255) NOT NULL,
     m_theme varchar(80) NOT NULL,
     m_avatar_url varchar(255) NOT NULL,
     m_validated tinyint(1) NOT NULL,
     m_validated_email_confirm_code varchar(255) NOT NULL,
     m_cache_num_posts integer NOT NULL,
     m_cache_warnings integer NOT NULL,
     m_join_time integer unsigned NOT NULL,
     m_timezone_offset varchar(255) NOT NULL,
     m_primary_group integer NOT NULL,
     m_last_visit_time integer unsigned NOT NULL,
     m_last_submit_time integer unsigned NOT NULL,
     m_signature integer NOT NULL,
     m_is_perm_banned tinyint(1) NOT NULL,
     m_preview_posts tinyint(1) NOT NULL,
     m_dob_day tinyint NOT NULL,
     m_dob_month tinyint NOT NULL,
     m_dob_year integer NOT NULL,
     m_reveal_age tinyint(1) NOT NULL,
     m_email_address varchar(255) NOT NULL,
     m_title varchar(255) NOT NULL,
     m_photo_url varchar(255) NOT NULL,
     m_photo_thumb_url varchar(255) NOT NULL,
     m_views_signatures tinyint(1) NOT NULL,
     m_auto_monitor_contrib_content tinyint(1) NOT NULL,
     m_language varchar(80) NOT NULL,
     m_ip_address varchar(40) NOT NULL,
     m_allow_emails tinyint(1) NOT NULL,
     m_allow_emails_from_staff tinyint(1) NOT NULL,
     m_highlighted_name tinyint(1) NOT NULL,
     m_pt_allow varchar(255) NOT NULL,
     m_pt_rules_text integer NOT NULL,
     m_max_email_attach_size_mb integer NOT NULL,
     m_password_change_code varchar(255) NOT NULL,
     m_password_compat_scheme varchar(80) NOT NULL,
     m_on_probation_until integer unsigned NOT NULL,
     m_profile_views integer unsigned NOT NULL,
     m_total_sessions integer unsigned NOT NULL,
     m_auto_mark_read tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_groups
(
     id integer auto_increment NULL,
     g_name integer NOT NULL,
     g_is_default tinyint(1) NOT NULL,
     g_is_presented_at_install tinyint(1) NOT NULL,
     g_is_super_admin tinyint(1) NOT NULL,
     g_is_super_moderator tinyint(1) NOT NULL,
     g_group_leader integer NOT NULL,
     g_title integer NOT NULL,
     g_promotion_target integer NOT NULL,
     g_promotion_threshold integer NOT NULL,
     g_flood_control_submit_secs integer NOT NULL,
     g_flood_control_access_secs integer NOT NULL,
     g_gift_points_base integer NOT NULL,
     g_gift_points_per_day integer NOT NULL,
     g_max_daily_upload_mb integer NOT NULL,
     g_max_attachments_per_post integer NOT NULL,
     g_max_avatar_width integer NOT NULL,
     g_max_avatar_height integer NOT NULL,
     g_max_post_length_comcode integer NOT NULL,
     g_max_sig_length_comcode integer NOT NULL,
     g_enquire_on_new_ips tinyint(1) NOT NULL,
     g_rank_image varchar(80) NOT NULL,
     g_hidden tinyint(1) NOT NULL,
     g_order integer NOT NULL,
     g_rank_image_pri_only tinyint(1) NOT NULL,
     g_open_membership tinyint(1) NOT NULL,
     g_is_private_club tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;


CREATE INDEX `calendar_events.e_submitter` ON cms_calendar_events(e_submitter);
ALTER TABLE cms_calendar_events ADD FOREIGN KEY `calendar_events.e_submitter` (e_submitter) REFERENCES cms_f_members (id);

CREATE INDEX `calendar_events.e_member_calendar` ON cms_calendar_events(e_member_calendar);
ALTER TABLE cms_calendar_events ADD FOREIGN KEY `calendar_events.e_member_calendar` (e_member_calendar) REFERENCES cms_f_members (id);

CREATE INDEX `calendar_events.e_type` ON cms_calendar_events(e_type);
ALTER TABLE cms_calendar_events ADD FOREIGN KEY `calendar_events.e_type` (e_type) REFERENCES cms_calendar_types (id);

CREATE INDEX `calendar_reminders.e_id` ON cms_calendar_reminders(e_id);
ALTER TABLE cms_calendar_reminders ADD FOREIGN KEY `calendar_reminders.e_id` (e_id) REFERENCES cms_calendar_events (id);

CREATE INDEX `calendar_reminders.n_member_id` ON cms_calendar_reminders(n_member_id);
ALTER TABLE cms_calendar_reminders ADD FOREIGN KEY `calendar_reminders.n_member_id` (n_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `calendar_interests.i_member_id` ON cms_calendar_interests(i_member_id);
ALTER TABLE cms_calendar_interests ADD FOREIGN KEY `calendar_interests.i_member_id` (i_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `calendar_interests.t_type` ON cms_calendar_interests(t_type);
ALTER TABLE cms_calendar_interests ADD FOREIGN KEY `calendar_interests.t_type` (t_type) REFERENCES cms_calendar_types (id);

CREATE INDEX `calendar_jobs.j_reminder_id` ON cms_calendar_jobs(j_reminder_id);
ALTER TABLE cms_calendar_jobs ADD FOREIGN KEY `calendar_jobs.j_reminder_id` (j_reminder_id) REFERENCES cms_calendar_reminders (id);

CREATE INDEX `calendar_jobs.j_member_id` ON cms_calendar_jobs(j_member_id);
ALTER TABLE cms_calendar_jobs ADD FOREIGN KEY `calendar_jobs.j_member_id` (j_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `calendar_jobs.j_event_id` ON cms_calendar_jobs(j_event_id);
ALTER TABLE cms_calendar_jobs ADD FOREIGN KEY `calendar_jobs.j_event_id` (j_event_id) REFERENCES cms_calendar_events (id);

CREATE INDEX `f_members.m_primary_group` ON cms_f_members(m_primary_group);
ALTER TABLE cms_f_members ADD FOREIGN KEY `f_members.m_primary_group` (m_primary_group) REFERENCES cms_f_groups (id);

CREATE INDEX `f_groups.g_group_leader` ON cms_f_groups(g_group_leader);
ALTER TABLE cms_f_groups ADD FOREIGN KEY `f_groups.g_group_leader` (g_group_leader) REFERENCES cms_f_members (id);

CREATE INDEX `f_groups.g_promotion_target` ON cms_f_groups(g_promotion_target);
ALTER TABLE cms_f_groups ADD FOREIGN KEY `f_groups.g_promotion_target` (g_promotion_target) REFERENCES cms_f_groups (id);
