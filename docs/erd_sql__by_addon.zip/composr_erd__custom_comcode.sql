CREATE TABLE cms_custom_comcode
(
     tag_tag varchar(80) NULL,
     tag_title integer NOT NULL,
     tag_description integer NOT NULL,
     tag_replace longtext NOT NULL,
     tag_example longtext NOT NULL,
     tag_parameters varchar(255) NOT NULL,
     tag_enabled tinyint(1) NOT NULL,
     tag_dangerous_tag tinyint(1) NOT NULL,
     tag_block_tag tinyint(1) NOT NULL,
     tag_textual_tag tinyint(1) NOT NULL,

     PRIMARY KEY (tag_tag)
) engine=InnoDB;

