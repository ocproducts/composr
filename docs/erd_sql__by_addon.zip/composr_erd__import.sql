CREATE TABLE cms_import_parts_done
(
     id integer auto_increment NULL,
     imp_id varchar(255) NOT NULL,
     imp_session varchar(80) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_import_session
(
     imp_session varchar(80) NULL,
     imp_old_base_dir varchar(255) NOT NULL,
     imp_db_name varchar(80) NOT NULL,
     imp_db_user varchar(80) NOT NULL,
     imp_hook varchar(80) NOT NULL,
     imp_db_table_prefix varchar(80) NOT NULL,
     imp_db_host varchar(80) NOT NULL,
     imp_refresh_time integer NOT NULL,

     PRIMARY KEY (imp_session)
) engine=InnoDB;

CREATE TABLE cms_import_id_remap
(
     id_old varchar(80) NULL,
     id_new integer NOT NULL,
     id_type varchar(80) NULL,
     id_session varchar(80) NULL,

     PRIMARY KEY (id_old,id_type,id_session)
) engine=InnoDB;


CREATE INDEX `import_parts_done.imp_session` ON cms_import_parts_done(imp_session);
ALTER TABLE cms_import_parts_done ADD FOREIGN KEY `import_parts_done.imp_session` (imp_session) REFERENCES cms_import_session (imp_session);

CREATE INDEX `import_id_remap.id_session` ON cms_import_id_remap(id_session);
ALTER TABLE cms_import_id_remap ADD FOREIGN KEY `import_id_remap.id_session` (id_session) REFERENCES cms_import_session (imp_session);
