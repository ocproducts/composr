CREATE TABLE cms_feature_lifetime_monitor
(
     content_id varchar(80) NULL,
     block_cache_id varchar(80) NULL,
     run_period integer NOT NULL,
     running_now tinyint(1) NOT NULL,
     last_update integer unsigned NOT NULL,

     PRIMARY KEY (content_id,block_cache_id)
) engine=InnoDB;

CREATE TABLE cms_menu_items
(
     id integer auto_increment NULL,
     i_menu varchar(80) NOT NULL,
     i_order integer NOT NULL,
     i_parent integer NOT NULL,
     i_caption integer NOT NULL,
     i_caption_long integer NOT NULL,
     i_url varchar(255) NOT NULL,
     i_check_permissions tinyint(1) NOT NULL,
     i_expanded tinyint(1) NOT NULL,
     i_new_window tinyint(1) NOT NULL,
     i_include_sitemap tinyint NOT NULL,
     i_page_only varchar(80) NOT NULL,
     i_theme_img_code varchar(80) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_trackbacks
(
     id integer auto_increment NULL,
     trackback_for_type varchar(80) NOT NULL,
     trackback_for_id varchar(80) NOT NULL,
     trackback_ip varchar(40) NOT NULL,
     trackback_time integer unsigned NOT NULL,
     trackback_url varchar(255) NOT NULL,
     trackback_title varchar(255) NOT NULL,
     trackback_excerpt longtext NOT NULL,
     trackback_name varchar(255) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_captchas
(
     si_session_id varchar(80) NULL,
     si_time integer unsigned NOT NULL,
     si_code varchar(80) NOT NULL,

     PRIMARY KEY (si_session_id)
) engine=InnoDB;

CREATE TABLE cms_member_tracking
(
     mt_member_id integer NULL,
     mt_cache_username varchar(80) NOT NULL,
     mt_time integer unsigned NULL,
     mt_page varchar(80) NULL,
     mt_type varchar(80) NULL,
     mt_id varchar(80) NULL,

     PRIMARY KEY (mt_member_id,mt_time,mt_page,mt_type,mt_id)
) engine=InnoDB;

CREATE TABLE cms_cache_on
(
     cached_for varchar(80) NULL,
     cache_on longtext NOT NULL,
     special_cache_flags integer NOT NULL,
     cache_ttl integer NOT NULL,

     PRIMARY KEY (cached_for)
) engine=InnoDB;

CREATE TABLE cms_webstandards_checked_once
(
     hash varchar(255) NULL,

     PRIMARY KEY (hash)
) engine=InnoDB;

CREATE TABLE cms_edit_pings
(
     id integer auto_increment NULL,
     the_page varchar(80) NOT NULL,
     the_type varchar(80) NOT NULL,
     the_id varchar(80) NOT NULL,
     the_time integer unsigned NOT NULL,
     the_member integer NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_values_elective
(
     the_name varchar(80) NULL,
     the_value longtext NOT NULL,
     date_and_time integer unsigned NOT NULL,

     PRIMARY KEY (the_name)
) engine=InnoDB;

CREATE TABLE cms_tutorial_links
(
     the_name varchar(80) NULL,
     the_value longtext NOT NULL,

     PRIMARY KEY (the_name)
) engine=InnoDB;

CREATE TABLE cms_member_privileges
(
     member_id integer NULL,
     privilege varchar(80) NULL,
     the_page varchar(80) NULL,
     module_the_name varchar(80) NULL,
     category_name varchar(80) NULL,
     the_value tinyint(1) NOT NULL,
     active_until integer unsigned NOT NULL,

     PRIMARY KEY (member_id,privilege,the_page,module_the_name,category_name)
) engine=InnoDB;

CREATE TABLE cms_member_zone_access
(
     zone_name varchar(80) NULL,
     member_id integer NULL,
     active_until integer unsigned NOT NULL,

     PRIMARY KEY (zone_name,member_id)
) engine=InnoDB;

CREATE TABLE cms_member_page_access
(
     page_name varchar(80) NULL,
     zone_name varchar(80) NULL,
     member_id integer NULL,
     active_until integer unsigned NOT NULL,

     PRIMARY KEY (page_name,zone_name,member_id)
) engine=InnoDB;

CREATE TABLE cms_member_category_access
(
     module_the_name varchar(80) NULL,
     category_name varchar(80) NULL,
     member_id integer NULL,
     active_until integer unsigned NOT NULL,

     PRIMARY KEY (module_the_name,category_name,member_id)
) engine=InnoDB;

CREATE TABLE cms_autosave
(
     id integer auto_increment NULL,
     a_member_id integer NOT NULL,
     a_key longtext NOT NULL,
     a_value longtext NOT NULL,
     a_time integer unsigned NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_messages_to_render
(
     id integer auto_increment NULL,
     r_session_id varchar(80) NOT NULL,
     r_message longtext NOT NULL,
     r_type varchar(80) NOT NULL,
     r_time integer unsigned NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_url_title_cache
(
     id integer auto_increment NULL,
     t_url varchar(255) NOT NULL,
     t_title varchar(255) NOT NULL,
     t_meta_title longtext NOT NULL,
     t_keywords longtext NOT NULL,
     t_description longtext NOT NULL,
     t_image_url varchar(255) NOT NULL,
     t_mime_type varchar(80) NOT NULL,
     t_json_discovery varchar(255) NOT NULL,
     t_xml_discovery varchar(255) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_rating
(
     id integer auto_increment NULL,
     rating_for_type varchar(80) NOT NULL,
     rating_for_id varchar(80) NOT NULL,
     rating_member integer NOT NULL,
     rating_ip varchar(40) NOT NULL,
     rating_time integer unsigned NOT NULL,
     rating tinyint NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_comcode_pages
(
     the_zone varchar(80) NULL,
     the_page varchar(80) NULL,
     p_parent_page varchar(80) NOT NULL,
     p_validated tinyint(1) NOT NULL,
     p_edit_date integer unsigned NOT NULL,
     p_add_date integer unsigned NOT NULL,
     p_submitter integer NOT NULL,
     p_show_as_edit tinyint(1) NOT NULL,
     p_order integer NOT NULL,

     PRIMARY KEY (the_zone,the_page)
) engine=InnoDB;

CREATE TABLE cms_cached_comcode_pages
(
     the_zone varchar(80) NULL,
     the_page varchar(80) NULL,
     string_index integer NOT NULL,
     the_theme varchar(80) NULL,
     cc_page_title integer NOT NULL,

     PRIMARY KEY (the_zone,the_page,the_theme)
) engine=InnoDB;

CREATE TABLE cms_url_id_monikers
(
     id integer auto_increment NULL,
     m_resource_page varchar(80) NOT NULL,
     m_resource_type varchar(80) NOT NULL,
     m_resource_id varchar(80) NOT NULL,
     m_moniker varchar(255) NOT NULL,
     m_moniker_reversed varchar(255) NOT NULL,
     m_deprecated tinyint(1) NOT NULL,
     m_manually_chosen tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_review_supplement
(
     r_post_id integer NULL,
     r_rating_type varchar(80) NULL,
     r_rating tinyint NOT NULL,
     r_topic_id integer NOT NULL,
     r_rating_for_id varchar(80) NOT NULL,
     r_rating_for_type varchar(80) NOT NULL,

     PRIMARY KEY (r_post_id,r_rating_type)
) engine=InnoDB;

CREATE TABLE cms_logged_mail_messages
(
     id integer auto_increment NULL,
     m_subject longtext NOT NULL,
     m_message longtext NOT NULL,
     m_to_email longtext NOT NULL,
     m_extra_cc_addresses longtext NOT NULL,
     m_extra_bcc_addresses longtext NOT NULL,
     m_join_time integer unsigned NOT NULL,
     m_to_name longtext NOT NULL,
     m_from_email varchar(255) NOT NULL,
     m_from_name varchar(255) NOT NULL,
     m_priority tinyint NOT NULL,
     m_attachments longtext NOT NULL,
     m_no_cc tinyint(1) NOT NULL,
     m_as integer NOT NULL,
     m_as_admin tinyint(1) NOT NULL,
     m_in_html tinyint(1) NOT NULL,
     m_date_and_time integer unsigned NOT NULL,
     m_member_id integer NOT NULL,
     m_url longtext NOT NULL,
     m_queued tinyint(1) NOT NULL,
     m_template varchar(80) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_link_tracker
(
     id integer auto_increment NULL,
     c_date_and_time integer unsigned NOT NULL,
     c_member_id integer NOT NULL,
     c_ip_address varchar(40) NOT NULL,
     c_url varchar(255) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_incoming_uploads
(
     id integer auto_increment NULL,
     i_submitter integer NOT NULL,
     i_date_and_time integer unsigned NOT NULL,
     i_orig_filename varchar(255) NOT NULL,
     i_save_url varchar(255) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_cache
(
     id integer auto_increment NULL,
     cached_for varchar(80) NOT NULL,
     identifier varchar(40) NOT NULL,
     the_theme varchar(40) NOT NULL,
     staff_status tinyint(1) NOT NULL,
     the_member integer NOT NULL,
     groups varchar(255) NOT NULL,
     is_bot tinyint(1) NOT NULL,
     timezone varchar(40) NOT NULL,
     lang varchar(5) NOT NULL,
     the_value longtext NOT NULL,
     dependencies longtext NOT NULL,
     date_and_time integer unsigned NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_group_member_timeouts
(
     member_id integer NULL,
     group_id integer NULL,
     timeout integer unsigned NOT NULL,

     PRIMARY KEY (member_id,group_id)
) engine=InnoDB;

CREATE TABLE cms_temp_block_permissions
(
     id integer auto_increment NULL,
     p_session_id varchar(80) NOT NULL,
     p_block_constraints longtext NOT NULL,
     p_time integer unsigned NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_cron_caching_requests
(
     id integer auto_increment NULL,
     c_codename varchar(80) NOT NULL,
     c_map longtext NOT NULL,
     c_lang varchar(5) NOT NULL,
     c_theme varchar(80) NOT NULL,
     c_staff_status tinyint(1) NOT NULL,
     c_member integer NOT NULL,
     c_groups varchar(255) NOT NULL,
     c_is_bot tinyint(1) NOT NULL,
     c_timezone varchar(40) NOT NULL,
     c_store_as_tempcode tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_notifications_enabled
(
     id integer auto_increment NULL,
     l_member_id integer NOT NULL,
     l_notification_code varchar(80) NOT NULL,
     l_code_category varchar(255) NOT NULL,
     l_setting integer NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_digestives_tin
(
     id integer auto_increment NULL,
     d_subject longtext NOT NULL,
     d_message integer NOT NULL,
     d_from_member_id integer NOT NULL,
     d_to_member_id integer NOT NULL,
     d_priority tinyint NOT NULL,
     d_no_cc tinyint(1) NOT NULL,
     d_date_and_time integer unsigned NOT NULL,
     d_notification_code varchar(80) NOT NULL,
     d_code_category varchar(255) NOT NULL,
     d_frequency integer NOT NULL,
     d_read tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_digestives_consumed
(
     c_member_id integer NULL,
     c_frequency integer NULL,
     c_time integer unsigned NOT NULL,

     PRIMARY KEY (c_member_id,c_frequency)
) engine=InnoDB;

CREATE TABLE cms_seo_meta_keywords
(
     id integer auto_increment NULL,
     meta_for_type varchar(80) NOT NULL,
     meta_for_id varchar(80) NOT NULL,
     meta_keyword integer NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_alternative_ids
(
     resource_type varchar(80) NULL,
     resource_id varchar(80) NULL,
     resource_moniker varchar(80) NOT NULL,
     resource_label varchar(255) NOT NULL,
     resource_guid varchar(80) NOT NULL,
     resource_resource_fs_hook varchar(80) NOT NULL,

     PRIMARY KEY (resource_type,resource_id)
) engine=InnoDB;

CREATE TABLE cms_email_bounces
(
     id integer auto_increment NULL,
     b_email_address varchar(255) NOT NULL,
     b_time integer unsigned NOT NULL,
     b_subject varchar(255) NOT NULL,
     b_body longtext NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_content_privacy
(
     content_type varchar(80) NULL,
     content_id varchar(80) NULL,
     guest_view tinyint(1) NOT NULL,
     member_view tinyint(1) NOT NULL,
     friend_view tinyint(1) NOT NULL,

     PRIMARY KEY (content_type,content_id)
) engine=InnoDB;

CREATE TABLE cms_content_privacy__members
(
     content_type varchar(80) NULL,
     content_id varchar(80) NULL,
     member_id integer NULL,

     PRIMARY KEY (content_type,content_id,member_id)
) engine=InnoDB;

CREATE TABLE cms_task_queue
(
     id integer auto_increment NULL,
     t_title varchar(255) NOT NULL,
     t_hook varchar(80) NOT NULL,
     t_args longtext NOT NULL,
     t_member_id integer NOT NULL,
     t_secure_ref varchar(80) NOT NULL,
     t_send_notification tinyint(1) NOT NULL,
     t_locked tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_sitemap_cache
(
     page_link varchar(255) NULL,
     set_number integer NOT NULL,
     add_date integer unsigned NOT NULL,
     edit_date integer unsigned NOT NULL,
     last_updated integer unsigned NOT NULL,
     is_deleted tinyint(1) NOT NULL,
     priority real NOT NULL,
     refreshfreq varchar(80) NOT NULL,
     guest_access tinyint(1) NOT NULL,

     PRIMARY KEY (page_link)
) engine=InnoDB;

CREATE TABLE cms_urls_checked
(
     id integer auto_increment NULL,
     url longtext NOT NULL,
     url_exists tinyint(1) NOT NULL,
     url_check_time integer unsigned NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_content_regions
(
     content_type varchar(80) NULL,
     content_id varchar(80) NULL,
     region varchar(80) NULL,

     PRIMARY KEY (content_type,content_id,region)
) engine=InnoDB;

CREATE TABLE cms_unbannable_ip
(
     ip varchar(40) NULL,
     note varchar(255) NOT NULL,

     PRIMARY KEY (ip)
) engine=InnoDB;

CREATE TABLE cms_failedlogins
(
     id integer auto_increment NULL,
     failed_account varchar(80) NOT NULL,
     date_and_time integer unsigned NOT NULL,
     ip varchar(40) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_group_zone_access
(
     zone_name varchar(80) NULL,
     group_id integer NULL,

     PRIMARY KEY (zone_name,group_id)
) engine=InnoDB;

CREATE TABLE cms_group_page_access
(
     page_name varchar(80) NULL,
     zone_name varchar(80) NULL,
     group_id integer NULL,

     PRIMARY KEY (page_name,zone_name,group_id)
) engine=InnoDB;

CREATE TABLE cms_attachments
(
     id integer auto_increment NULL,
     a_member_id integer NOT NULL,
     a_file_size integer NOT NULL,
     a_url varchar(255) NOT NULL,
     a_description varchar(255) NOT NULL,
     a_thumb_url varchar(255) NOT NULL,
     a_original_filename varchar(255) NOT NULL,
     a_num_downloads integer NOT NULL,
     a_last_downloaded_time integer NOT NULL,
     a_add_time integer NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_attachment_refs
(
     id integer auto_increment NULL,
     r_referer_type varchar(80) NOT NULL,
     r_referer_id varchar(80) NOT NULL,
     a_id integer NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_blocks
(
     block_name varchar(80) NULL,
     block_author varchar(80) NOT NULL,
     block_organisation varchar(80) NOT NULL,
     block_hacked_by varchar(80) NOT NULL,
     block_hack_version integer NOT NULL,
     block_version integer NOT NULL,

     PRIMARY KEY (block_name)
) engine=InnoDB;

CREATE TABLE cms_config
(
     c_name varchar(80) NULL,
     c_set tinyint(1) NOT NULL,
     c_value longtext NOT NULL,
     c_value_trans integer NOT NULL,
     c_needs_dereference tinyint(1) NOT NULL,

     PRIMARY KEY (c_name)
) engine=InnoDB;

CREATE TABLE cms_group_category_access
(
     module_the_name varchar(80) NULL,
     category_name varchar(80) NULL,
     group_id integer NULL,

     PRIMARY KEY (module_the_name,category_name,group_id)
) engine=InnoDB;

CREATE TABLE cms_group_privileges
(
     group_id integer NULL,
     privilege varchar(80) NULL,
     the_page varchar(80) NULL,
     module_the_name varchar(80) NULL,
     category_name varchar(80) NULL,
     the_value tinyint(1) NOT NULL,

     PRIMARY KEY (group_id,privilege,the_page,module_the_name,category_name)
) engine=InnoDB;

CREATE TABLE cms_https_pages
(
     https_page_name varchar(80) NULL,

     PRIMARY KEY (https_page_name)
) engine=InnoDB;

CREATE TABLE cms_modules
(
     module_the_name varchar(80) NULL,
     module_author varchar(80) NOT NULL,
     module_organisation varchar(80) NOT NULL,
     module_hacked_by varchar(80) NOT NULL,
     module_hack_version integer NOT NULL,
     module_version integer NOT NULL,

     PRIMARY KEY (module_the_name)
) engine=InnoDB;

CREATE TABLE cms_privilege_list
(
     p_section varchar(80) NOT NULL,
     the_name varchar(80) NULL,
     the_default tinyint(1) NULL,

     PRIMARY KEY (the_name,the_default)
) engine=InnoDB;

CREATE TABLE cms_seo_meta
(
     id integer auto_increment NULL,
     meta_for_type varchar(80) NOT NULL,
     meta_for_id varchar(80) NOT NULL,
     meta_description integer NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_sessions
(
     the_session varchar(80) NULL,
     last_activity integer unsigned NOT NULL,
     member_id integer NOT NULL,
     ip varchar(40) NOT NULL,
     session_confirmed tinyint(1) NOT NULL,
     session_invisible tinyint(1) NOT NULL,
     cache_username varchar(255) NOT NULL,
     the_zone varchar(80) NOT NULL,
     the_page varchar(80) NOT NULL,
     the_type varchar(80) NOT NULL,
     the_id varchar(80) NOT NULL,
     the_title varchar(255) NOT NULL,

     PRIMARY KEY (the_session)
) engine=InnoDB;

CREATE TABLE cms_values
(
     the_name varchar(80) NULL,
     the_value varchar(255) NOT NULL,
     date_and_time integer unsigned NOT NULL,

     PRIMARY KEY (the_name)
) engine=InnoDB;

CREATE TABLE cms_zones
(
     zone_name varchar(80) NULL,
     zone_title integer NOT NULL,
     zone_default_page varchar(80) NOT NULL,
     zone_header_text integer NOT NULL,
     zone_theme varchar(80) NOT NULL,
     zone_require_session tinyint(1) NOT NULL,

     PRIMARY KEY (zone_name)
) engine=InnoDB;

CREATE TABLE cms_f_members
(
     id integer auto_increment NULL,
     m_username varchar(80) NOT NULL,
     m_pass_hash_salted varchar(255) NOT NULL,
     m_pass_salt varchar(255) NOT NULL,
     m_theme varchar(80) NOT NULL,
     m_avatar_url varchar(255) NOT NULL,
     m_validated tinyint(1) NOT NULL,
     m_validated_email_confirm_code varchar(255) NOT NULL,
     m_cache_num_posts integer NOT NULL,
     m_cache_warnings integer NOT NULL,
     m_join_time integer unsigned NOT NULL,
     m_timezone_offset varchar(255) NOT NULL,
     m_primary_group integer NOT NULL,
     m_last_visit_time integer unsigned NOT NULL,
     m_last_submit_time integer unsigned NOT NULL,
     m_signature integer NOT NULL,
     m_is_perm_banned tinyint(1) NOT NULL,
     m_preview_posts tinyint(1) NOT NULL,
     m_dob_day tinyint NOT NULL,
     m_dob_month tinyint NOT NULL,
     m_dob_year integer NOT NULL,
     m_reveal_age tinyint(1) NOT NULL,
     m_email_address varchar(255) NOT NULL,
     m_title varchar(255) NOT NULL,
     m_photo_url varchar(255) NOT NULL,
     m_photo_thumb_url varchar(255) NOT NULL,
     m_views_signatures tinyint(1) NOT NULL,
     m_auto_monitor_contrib_content tinyint(1) NOT NULL,
     m_language varchar(80) NOT NULL,
     m_ip_address varchar(40) NOT NULL,
     m_allow_emails tinyint(1) NOT NULL,
     m_allow_emails_from_staff tinyint(1) NOT NULL,
     m_highlighted_name tinyint(1) NOT NULL,
     m_pt_allow varchar(255) NOT NULL,
     m_pt_rules_text integer NOT NULL,
     m_max_email_attach_size_mb integer NOT NULL,
     m_password_change_code varchar(255) NOT NULL,
     m_password_compat_scheme varchar(80) NOT NULL,
     m_on_probation_until integer unsigned NOT NULL,
     m_profile_views integer unsigned NOT NULL,
     m_total_sessions integer unsigned NOT NULL,
     m_auto_mark_read tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_posts
(
     id integer auto_increment NULL,
     p_title varchar(255) NOT NULL,
     p_post integer NOT NULL,
     p_ip_address varchar(40) NOT NULL,
     p_time integer unsigned NOT NULL,
     p_poster integer NOT NULL,
     p_intended_solely_for integer NOT NULL,
     p_poster_name_if_guest varchar(80) NOT NULL,
     p_validated tinyint(1) NOT NULL,
     p_topic_id integer NOT NULL,
     p_cache_forum_id integer NOT NULL,
     p_last_edit_time integer unsigned NOT NULL,
     p_last_edit_by integer NOT NULL,
     p_is_emphasised tinyint(1) NOT NULL,
     p_skip_sig tinyint(1) NOT NULL,
     p_parent_id integer NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_topics
(
     id integer auto_increment NULL,
     t_pinned tinyint(1) NOT NULL,
     t_sunk tinyint(1) NOT NULL,
     t_cascading tinyint(1) NOT NULL,
     t_forum_id integer NOT NULL,
     t_pt_from integer NOT NULL,
     t_pt_to integer NOT NULL,
     t_pt_from_category varchar(255) NOT NULL,
     t_pt_to_category varchar(255) NOT NULL,
     t_description varchar(255) NOT NULL,
     t_description_link varchar(255) NOT NULL,
     t_emoticon varchar(255) NOT NULL,
     t_num_views integer NOT NULL,
     t_validated tinyint(1) NOT NULL,
     t_is_open tinyint(1) NOT NULL,
     t_poll_id integer NOT NULL,
     t_cache_first_post_id integer NOT NULL,
     t_cache_first_time integer unsigned NOT NULL,
     t_cache_first_title varchar(255) NOT NULL,
     t_cache_first_post integer NOT NULL,
     t_cache_first_username varchar(80) NOT NULL,
     t_cache_first_member_id integer NOT NULL,
     t_cache_last_post_id integer NOT NULL,
     t_cache_last_time integer unsigned NOT NULL,
     t_cache_last_title varchar(255) NOT NULL,
     t_cache_last_username varchar(80) NOT NULL,
     t_cache_last_member_id integer NOT NULL,
     t_cache_num_posts integer NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_groups
(
     id integer auto_increment NULL,
     g_name integer NOT NULL,
     g_is_default tinyint(1) NOT NULL,
     g_is_presented_at_install tinyint(1) NOT NULL,
     g_is_super_admin tinyint(1) NOT NULL,
     g_is_super_moderator tinyint(1) NOT NULL,
     g_group_leader integer NOT NULL,
     g_title integer NOT NULL,
     g_promotion_target integer NOT NULL,
     g_promotion_threshold integer NOT NULL,
     g_flood_control_submit_secs integer NOT NULL,
     g_flood_control_access_secs integer NOT NULL,
     g_gift_points_base integer NOT NULL,
     g_gift_points_per_day integer NOT NULL,
     g_max_daily_upload_mb integer NOT NULL,
     g_max_attachments_per_post integer NOT NULL,
     g_max_avatar_width integer NOT NULL,
     g_max_avatar_height integer NOT NULL,
     g_max_post_length_comcode integer NOT NULL,
     g_max_sig_length_comcode integer NOT NULL,
     g_enquire_on_new_ips tinyint(1) NOT NULL,
     g_rank_image varchar(80) NOT NULL,
     g_hidden tinyint(1) NOT NULL,
     g_order integer NOT NULL,
     g_rank_image_pri_only tinyint(1) NOT NULL,
     g_open_membership tinyint(1) NOT NULL,
     g_is_private_club tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_forums
(
     id integer auto_increment NULL,
     f_name varchar(255) NOT NULL,
     f_description integer NOT NULL,
     f_forum_grouping_id integer NOT NULL,
     f_parent_forum integer NOT NULL,
     f_position integer NOT NULL,
     f_order_sub_alpha tinyint(1) NOT NULL,
     f_post_count_increment tinyint(1) NOT NULL,
     f_intro_question integer NOT NULL,
     f_intro_answer varchar(255) NOT NULL,
     f_cache_num_topics integer NOT NULL,
     f_cache_num_posts integer NOT NULL,
     f_cache_last_topic_id integer NOT NULL,
     f_cache_last_title varchar(255) NOT NULL,
     f_cache_last_time integer unsigned NOT NULL,
     f_cache_last_username varchar(255) NOT NULL,
     f_cache_last_member_id integer NOT NULL,
     f_cache_last_forum_id integer NOT NULL,
     f_redirection varchar(255) NOT NULL,
     f_order varchar(80) NOT NULL,
     f_is_threaded tinyint(1) NOT NULL,
     f_allows_anonymous_posts tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_polls
(
     id integer auto_increment NULL,
     po_question varchar(255) NOT NULL,
     po_cache_total_votes integer NOT NULL,
     po_is_private tinyint(1) NOT NULL,
     po_is_open tinyint(1) NOT NULL,
     po_minimum_selections integer NOT NULL,
     po_maximum_selections integer NOT NULL,
     po_requires_reply tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;

CREATE TABLE cms_f_forum_groupings
(
     id integer auto_increment NULL,
     c_title varchar(255) NOT NULL,
     c_description longtext NOT NULL,
     c_expanded_by_default tinyint(1) NOT NULL,

     PRIMARY KEY (id)
) engine=InnoDB;


CREATE INDEX `menu_items.i_parent` ON cms_menu_items(i_parent);
ALTER TABLE cms_menu_items ADD FOREIGN KEY `menu_items.i_parent` (i_parent) REFERENCES cms_menu_items (id);

CREATE INDEX `member_tracking.mt_member_id` ON cms_member_tracking(mt_member_id);
ALTER TABLE cms_member_tracking ADD FOREIGN KEY `member_tracking.mt_member_id` (mt_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `edit_pings.the_member` ON cms_edit_pings(the_member);
ALTER TABLE cms_edit_pings ADD FOREIGN KEY `edit_pings.the_member` (the_member) REFERENCES cms_f_members (id);

CREATE INDEX `member_privileges.privilege` ON cms_member_privileges(privilege);
ALTER TABLE cms_member_privileges ADD FOREIGN KEY `member_privileges.privilege` (privilege) REFERENCES cms_privilege_list (the_name);

CREATE INDEX `member_privileges.the_page` ON cms_member_privileges(the_page);
ALTER TABLE cms_member_privileges ADD FOREIGN KEY `member_privileges.the_page` (the_page) REFERENCES cms_modules (module_the_name);

CREATE INDEX `member_zone_access.zone_name` ON cms_member_zone_access(zone_name);
ALTER TABLE cms_member_zone_access ADD FOREIGN KEY `member_zone_access.zone_name` (zone_name) REFERENCES cms_zones (zone_name);

CREATE INDEX `member_zone_access.member_id` ON cms_member_zone_access(member_id);
ALTER TABLE cms_member_zone_access ADD FOREIGN KEY `member_zone_access.member_id` (member_id) REFERENCES cms_f_members (id);

CREATE INDEX `member_page_access.page_name` ON cms_member_page_access(page_name);
ALTER TABLE cms_member_page_access ADD FOREIGN KEY `member_page_access.page_name` (page_name) REFERENCES cms_modules (module_the_name);

CREATE INDEX `member_page_access.zone_name` ON cms_member_page_access(zone_name);
ALTER TABLE cms_member_page_access ADD FOREIGN KEY `member_page_access.zone_name` (zone_name) REFERENCES cms_zones (zone_name);

CREATE INDEX `member_page_access.member_id` ON cms_member_page_access(member_id);
ALTER TABLE cms_member_page_access ADD FOREIGN KEY `member_page_access.member_id` (member_id) REFERENCES cms_f_members (id);

CREATE INDEX `member_category_access.member_id` ON cms_member_category_access(member_id);
ALTER TABLE cms_member_category_access ADD FOREIGN KEY `member_category_access.member_id` (member_id) REFERENCES cms_f_members (id);

CREATE INDEX `autosave.a_member_id` ON cms_autosave(a_member_id);
ALTER TABLE cms_autosave ADD FOREIGN KEY `autosave.a_member_id` (a_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `messages_to_render.r_session_id` ON cms_messages_to_render(r_session_id);
ALTER TABLE cms_messages_to_render ADD FOREIGN KEY `messages_to_render.r_session_id` (r_session_id) REFERENCES cms_sessions (the_session);

CREATE INDEX `rating.rating_for_id` ON cms_rating(rating_for_id);
ALTER TABLE cms_rating ADD FOREIGN KEY `rating.rating_for_id` (rating_for_id) REFERENCES cms_modules (module_the_name);

CREATE INDEX `rating.rating_member` ON cms_rating(rating_member);
ALTER TABLE cms_rating ADD FOREIGN KEY `rating.rating_member` (rating_member) REFERENCES cms_f_members (id);

CREATE INDEX `comcode_pages.p_submitter` ON cms_comcode_pages(p_submitter);
ALTER TABLE cms_comcode_pages ADD FOREIGN KEY `comcode_pages.p_submitter` (p_submitter) REFERENCES cms_f_members (id);

CREATE INDEX `cached_comcode_pages.the_zone` ON cms_cached_comcode_pages(the_zone);
ALTER TABLE cms_cached_comcode_pages ADD FOREIGN KEY `cached_comcode_pages.the_zone` (the_zone) REFERENCES cms_zones (zone_name);

CREATE INDEX `review_supplement.r_post_id` ON cms_review_supplement(r_post_id);
ALTER TABLE cms_review_supplement ADD FOREIGN KEY `review_supplement.r_post_id` (r_post_id) REFERENCES cms_f_posts (id);

CREATE INDEX `review_supplement.r_topic_id` ON cms_review_supplement(r_topic_id);
ALTER TABLE cms_review_supplement ADD FOREIGN KEY `review_supplement.r_topic_id` (r_topic_id) REFERENCES cms_f_topics (id);

CREATE INDEX `review_supplement.r_rating_for_id` ON cms_review_supplement(r_rating_for_id);
ALTER TABLE cms_review_supplement ADD FOREIGN KEY `review_supplement.r_rating_for_id` (r_rating_for_id) REFERENCES cms_modules (module_the_name);

CREATE INDEX `logged_mail_messages.m_as` ON cms_logged_mail_messages(m_as);
ALTER TABLE cms_logged_mail_messages ADD FOREIGN KEY `logged_mail_messages.m_as` (m_as) REFERENCES cms_f_members (id);

CREATE INDEX `logged_mail_messages.m_member_id` ON cms_logged_mail_messages(m_member_id);
ALTER TABLE cms_logged_mail_messages ADD FOREIGN KEY `logged_mail_messages.m_member_id` (m_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `link_tracker.c_member_id` ON cms_link_tracker(c_member_id);
ALTER TABLE cms_link_tracker ADD FOREIGN KEY `link_tracker.c_member_id` (c_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `incoming_uploads.i_submitter` ON cms_incoming_uploads(i_submitter);
ALTER TABLE cms_incoming_uploads ADD FOREIGN KEY `incoming_uploads.i_submitter` (i_submitter) REFERENCES cms_f_members (id);

CREATE INDEX `cache.the_member` ON cms_cache(the_member);
ALTER TABLE cms_cache ADD FOREIGN KEY `cache.the_member` (the_member) REFERENCES cms_f_members (id);

CREATE INDEX `f_group_member_timeouts.member_id` ON cms_f_group_member_timeouts(member_id);
ALTER TABLE cms_f_group_member_timeouts ADD FOREIGN KEY `f_group_member_timeouts.member_id` (member_id) REFERENCES cms_f_members (id);

CREATE INDEX `f_group_member_timeouts.group_id` ON cms_f_group_member_timeouts(group_id);
ALTER TABLE cms_f_group_member_timeouts ADD FOREIGN KEY `f_group_member_timeouts.group_id` (group_id) REFERENCES cms_f_groups (id);

CREATE INDEX `temp_block_permissions.p_session_id` ON cms_temp_block_permissions(p_session_id);
ALTER TABLE cms_temp_block_permissions ADD FOREIGN KEY `temp_block_permissions.p_session_id` (p_session_id) REFERENCES cms_sessions (the_session);

CREATE INDEX `cron_caching_requests.c_member` ON cms_cron_caching_requests(c_member);
ALTER TABLE cms_cron_caching_requests ADD FOREIGN KEY `cron_caching_requests.c_member` (c_member) REFERENCES cms_f_members (id);

CREATE INDEX `notifications_enabled.l_member_id` ON cms_notifications_enabled(l_member_id);
ALTER TABLE cms_notifications_enabled ADD FOREIGN KEY `notifications_enabled.l_member_id` (l_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `digestives_tin.d_from_member_id` ON cms_digestives_tin(d_from_member_id);
ALTER TABLE cms_digestives_tin ADD FOREIGN KEY `digestives_tin.d_from_member_id` (d_from_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `digestives_tin.d_to_member_id` ON cms_digestives_tin(d_to_member_id);
ALTER TABLE cms_digestives_tin ADD FOREIGN KEY `digestives_tin.d_to_member_id` (d_to_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `digestives_consumed.c_member_id` ON cms_digestives_consumed(c_member_id);
ALTER TABLE cms_digestives_consumed ADD FOREIGN KEY `digestives_consumed.c_member_id` (c_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `content_privacy__members.member_id` ON cms_content_privacy__members(member_id);
ALTER TABLE cms_content_privacy__members ADD FOREIGN KEY `content_privacy__members.member_id` (member_id) REFERENCES cms_f_members (id);

CREATE INDEX `task_queue.t_member_id` ON cms_task_queue(t_member_id);
ALTER TABLE cms_task_queue ADD FOREIGN KEY `task_queue.t_member_id` (t_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `group_zone_access.zone_name` ON cms_group_zone_access(zone_name);
ALTER TABLE cms_group_zone_access ADD FOREIGN KEY `group_zone_access.zone_name` (zone_name) REFERENCES cms_zones (zone_name);

CREATE INDEX `group_zone_access.group_id` ON cms_group_zone_access(group_id);
ALTER TABLE cms_group_zone_access ADD FOREIGN KEY `group_zone_access.group_id` (group_id) REFERENCES cms_f_groups (id);

CREATE INDEX `group_page_access.zone_name` ON cms_group_page_access(zone_name);
ALTER TABLE cms_group_page_access ADD FOREIGN KEY `group_page_access.zone_name` (zone_name) REFERENCES cms_zones (zone_name);

CREATE INDEX `group_page_access.group_id` ON cms_group_page_access(group_id);
ALTER TABLE cms_group_page_access ADD FOREIGN KEY `group_page_access.group_id` (group_id) REFERENCES cms_f_groups (id);

CREATE INDEX `attachments.a_member_id` ON cms_attachments(a_member_id);
ALTER TABLE cms_attachments ADD FOREIGN KEY `attachments.a_member_id` (a_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `attachment_refs.a_id` ON cms_attachment_refs(a_id);
ALTER TABLE cms_attachment_refs ADD FOREIGN KEY `attachment_refs.a_id` (a_id) REFERENCES cms_attachments (id);

CREATE INDEX `group_category_access.group_id` ON cms_group_category_access(group_id);
ALTER TABLE cms_group_category_access ADD FOREIGN KEY `group_category_access.group_id` (group_id) REFERENCES cms_f_groups (id);

CREATE INDEX `group_privileges.privilege` ON cms_group_privileges(privilege);
ALTER TABLE cms_group_privileges ADD FOREIGN KEY `group_privileges.privilege` (privilege) REFERENCES cms_privilege_list (the_name);

CREATE INDEX `group_privileges.the_page` ON cms_group_privileges(the_page);
ALTER TABLE cms_group_privileges ADD FOREIGN KEY `group_privileges.the_page` (the_page) REFERENCES cms_modules (module_the_name);

CREATE INDEX `sessions.member_id` ON cms_sessions(member_id);
ALTER TABLE cms_sessions ADD FOREIGN KEY `sessions.member_id` (member_id) REFERENCES cms_f_members (id);

CREATE INDEX `f_members.m_primary_group` ON cms_f_members(m_primary_group);
ALTER TABLE cms_f_members ADD FOREIGN KEY `f_members.m_primary_group` (m_primary_group) REFERENCES cms_f_groups (id);

CREATE INDEX `f_posts.p_poster` ON cms_f_posts(p_poster);
ALTER TABLE cms_f_posts ADD FOREIGN KEY `f_posts.p_poster` (p_poster) REFERENCES cms_f_members (id);

CREATE INDEX `f_posts.p_intended_solely_for` ON cms_f_posts(p_intended_solely_for);
ALTER TABLE cms_f_posts ADD FOREIGN KEY `f_posts.p_intended_solely_for` (p_intended_solely_for) REFERENCES cms_f_members (id);

CREATE INDEX `f_posts.p_topic_id` ON cms_f_posts(p_topic_id);
ALTER TABLE cms_f_posts ADD FOREIGN KEY `f_posts.p_topic_id` (p_topic_id) REFERENCES cms_f_topics (id);

CREATE INDEX `f_posts.p_cache_forum_id` ON cms_f_posts(p_cache_forum_id);
ALTER TABLE cms_f_posts ADD FOREIGN KEY `f_posts.p_cache_forum_id` (p_cache_forum_id) REFERENCES cms_f_forums (id);

CREATE INDEX `f_posts.p_last_edit_by` ON cms_f_posts(p_last_edit_by);
ALTER TABLE cms_f_posts ADD FOREIGN KEY `f_posts.p_last_edit_by` (p_last_edit_by) REFERENCES cms_f_members (id);

CREATE INDEX `f_posts.p_parent_id` ON cms_f_posts(p_parent_id);
ALTER TABLE cms_f_posts ADD FOREIGN KEY `f_posts.p_parent_id` (p_parent_id) REFERENCES cms_f_posts (id);

CREATE INDEX `f_topics.t_forum_id` ON cms_f_topics(t_forum_id);
ALTER TABLE cms_f_topics ADD FOREIGN KEY `f_topics.t_forum_id` (t_forum_id) REFERENCES cms_f_forums (id);

CREATE INDEX `f_topics.t_pt_from` ON cms_f_topics(t_pt_from);
ALTER TABLE cms_f_topics ADD FOREIGN KEY `f_topics.t_pt_from` (t_pt_from) REFERENCES cms_f_members (id);

CREATE INDEX `f_topics.t_pt_to` ON cms_f_topics(t_pt_to);
ALTER TABLE cms_f_topics ADD FOREIGN KEY `f_topics.t_pt_to` (t_pt_to) REFERENCES cms_f_members (id);

CREATE INDEX `f_topics.t_poll_id` ON cms_f_topics(t_poll_id);
ALTER TABLE cms_f_topics ADD FOREIGN KEY `f_topics.t_poll_id` (t_poll_id) REFERENCES cms_f_polls (id);

CREATE INDEX `f_topics.t_cache_first_post_id` ON cms_f_topics(t_cache_first_post_id);
ALTER TABLE cms_f_topics ADD FOREIGN KEY `f_topics.t_cache_first_post_id` (t_cache_first_post_id) REFERENCES cms_f_posts (id);

CREATE INDEX `f_topics.t_cache_first_member_id` ON cms_f_topics(t_cache_first_member_id);
ALTER TABLE cms_f_topics ADD FOREIGN KEY `f_topics.t_cache_first_member_id` (t_cache_first_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `f_topics.t_cache_last_post_id` ON cms_f_topics(t_cache_last_post_id);
ALTER TABLE cms_f_topics ADD FOREIGN KEY `f_topics.t_cache_last_post_id` (t_cache_last_post_id) REFERENCES cms_f_posts (id);

CREATE INDEX `f_topics.t_cache_last_member_id` ON cms_f_topics(t_cache_last_member_id);
ALTER TABLE cms_f_topics ADD FOREIGN KEY `f_topics.t_cache_last_member_id` (t_cache_last_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `f_groups.g_group_leader` ON cms_f_groups(g_group_leader);
ALTER TABLE cms_f_groups ADD FOREIGN KEY `f_groups.g_group_leader` (g_group_leader) REFERENCES cms_f_members (id);

CREATE INDEX `f_groups.g_promotion_target` ON cms_f_groups(g_promotion_target);
ALTER TABLE cms_f_groups ADD FOREIGN KEY `f_groups.g_promotion_target` (g_promotion_target) REFERENCES cms_f_groups (id);

CREATE INDEX `f_forums.f_forum_grouping_id` ON cms_f_forums(f_forum_grouping_id);
ALTER TABLE cms_f_forums ADD FOREIGN KEY `f_forums.f_forum_grouping_id` (f_forum_grouping_id) REFERENCES cms_f_forum_groupings (id);

CREATE INDEX `f_forums.f_parent_forum` ON cms_f_forums(f_parent_forum);
ALTER TABLE cms_f_forums ADD FOREIGN KEY `f_forums.f_parent_forum` (f_parent_forum) REFERENCES cms_f_forums (id);

CREATE INDEX `f_forums.f_cache_last_topic_id` ON cms_f_forums(f_cache_last_topic_id);
ALTER TABLE cms_f_forums ADD FOREIGN KEY `f_forums.f_cache_last_topic_id` (f_cache_last_topic_id) REFERENCES cms_f_topics (id);

CREATE INDEX `f_forums.f_cache_last_member_id` ON cms_f_forums(f_cache_last_member_id);
ALTER TABLE cms_f_forums ADD FOREIGN KEY `f_forums.f_cache_last_member_id` (f_cache_last_member_id) REFERENCES cms_f_members (id);

CREATE INDEX `f_forums.f_cache_last_forum_id` ON cms_f_forums(f_cache_last_forum_id);
ALTER TABLE cms_f_forums ADD FOREIGN KEY `f_forums.f_cache_last_forum_id` (f_cache_last_forum_id) REFERENCES cms_f_forums (id);
