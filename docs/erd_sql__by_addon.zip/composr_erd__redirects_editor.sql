CREATE TABLE cms_redirects
(
     r_from_page varchar(80) NULL,
     r_from_zone varchar(80) NULL,
     r_to_page varchar(80) NOT NULL,
     r_to_zone varchar(80) NOT NULL,
     r_is_transparent tinyint(1) NOT NULL,

     PRIMARY KEY (r_from_page,r_from_zone)
) engine=InnoDB;

CREATE TABLE cms_zones
(
     zone_name varchar(80) NULL,
     zone_title integer NOT NULL,
     zone_default_page varchar(80) NOT NULL,
     zone_header_text integer NOT NULL,
     zone_theme varchar(80) NOT NULL,
     zone_require_session tinyint(1) NOT NULL,

     PRIMARY KEY (zone_name)
) engine=InnoDB;


CREATE INDEX `redirects.r_from_zone` ON cms_redirects(r_from_zone);
ALTER TABLE cms_redirects ADD FOREIGN KEY `redirects.r_from_zone` (r_from_zone) REFERENCES cms_zones (zone_name);

CREATE INDEX `redirects.r_to_zone` ON cms_redirects(r_to_zone);
ALTER TABLE cms_redirects ADD FOREIGN KEY `redirects.r_to_zone` (r_to_zone) REFERENCES cms_zones (zone_name);
