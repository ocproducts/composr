CREATE TABLE cms_wordfilter
(
     id integer auto_increment NULL,
     word varchar(255) NOT NULL,
     w_replacement varchar(255) NOT NULL,
     w_substr tinyint(1) NULL,

     PRIMARY KEY (id,w_substr)
) engine=InnoDB;

