<?php /*

 ocPortal
 Copyright (c) ocProducts, 2004-2008

 See text/en/licence.txt for full licencing information.

*/

/**
 * @license		http://opensource.org/licenses/cpal_1.0 Common Public Attribution License
 * @copyright	ocProducts Ltd
 * @package		leagues
 */

/*

This is an example ocPortal module called 'leagues' (as per the file name, and the fact the main *class* in the file is called 'Module_leagues').

It is also being noted (above) as being in the 'leagues' addon-- an addon usually contains multiple files and it is kind of a coincidence that the name of the module is the same as the name of the addon (well not really, but I just mean an addon can contain lots of modules with different names).

*/

class Module_leagues
{

	/**
	 * Standard modular info function. This function returns information about our module, so ocPortal can properly manage it.
	 *
	 * @return ?array	Map of module info (NULL: module is disabled).
	 */
	function info()
	{
		$info=array();
		$info['author']='Chris Graham'; // The guy who wrote it. Anything can be entered here, and it is used for display purposes only.
		$info['organisation']='ocProducts'; // The group the guy that wrote it did it under. Anything can be entered here, and it is used for display purposes only.

		// The version number of the module. Usually we only raise this number when database structure changes. It is to do with compatibility really - then number goes up when an upgrade is required (database compatiblity broken).
		// Once the database structure changes it's necessary to also set $info['update_requires_upgrade']=true and to restructure the "install" function to pay close attention to it's upgrade-identificaction parameters (i.e. not just doing a full install regardless of whether it was an upgrade requested). In this code it's our first version so our install version is not yet smart enough to handle upgrades.
		$info['version']=1;

		// Usually these are left NULL. It is here so that modified versions of the module can be tracked and passed through upgrade cycles without having to do it by making unauthorised new primary version numbers (which would introduce a lot of confusion if different people choose the same version numbers for their own independant versions!).
		$info['hacked_by']=NULL;
		$info['hack_version']=NULL;

		$info['locked']=false; // This means the modules may be uninstalled. Only a few core ocPortal modules are 'locked'-- few need to be.

		return $info;
	}
	
	/**
	 * Standard modular install function. This function handles installation of our module. If we had set "$info['update_requires_upgrade']=true" in our info() function, it would also have to be written to handle upgrades. But we don't need to do that as we're still on version 1.
	 *
	 * @param  ?integer	What version we're upgrading from (NULL: new install). As we did not set "$info['update_requires_upgrade']=true" we know that this will ALWAYS be NULL, and we can totally ignore it. Later on this parameter would become essential as we would use it to determine what code to run, to handle either upgrading, or installation, depending on the value of the parameter.
	 * @param  ?integer	What hack version we're upgrading from (NULL: new-install/not-upgrading-from-a-hacked-version). As above, this will ALWAYS be NULL.
	 */
	function install($upgrade_from=NULL,$upgrade_from_hack=NULL)
	{
		// The install function creates our database tables
		// It is done using the SITE_DB database driver, which is almost always the driver we use as it points to our main database.

		// The process of deciding what tables to have in a database is called "data modelling", and the code in this function is essentially the same thing as a "database schema".
		
		// First create our team table.
		//  The function takes two parameters. The first is a table name. The second is a map array of fields to go into the table. The map array maps between field name and field type. The type codes are special to ocPortal (and listed in our Code Book), but get translated automatically into MySQL data types, as well as key settings.
		$GLOBALS['SITE_DB']->create_table('league_teams',array(
			'id'=>'*AUTO', // An "auto-incrementing" number, that is our table's key (which the * is indicating). Most tables are given auto-incrementing keys, as it's rare you can rely on anything else to be unique. In this case "t_name" is likely to be unique, but does not have to be (conveivably two different teams might have the same name); generally there is no point risking it, and numeric keys are easier to manage anyway (no problem of having to do a multi-row rename operation if the team name changes - you just need to change one row).
			't_name'=>'SHORT_TEXT', // The name of the team. This is a short piece of text (defined as text less than 255 characters in length).
			't_division'=>'SHORT_TEXT', // The division the team is in. If we were doing this module perfectly we would make this an AUTO_LINK pointing to the ID field of a proper league_divisions table. However for simplicity we will avoid maintaining an extra table and simply assume that there is only one league (a league_divisions table would have allowed us to model which league each division is in, and also make it easier to rename divisions should we need to)
			't_email_contact'=>'SHORT_TEXT', // The email contact for the team, probably the coach. When fixture tables are updated all these people will be emailed.
		));

		// Next create our fixtures table.
		$GLOBALS['SITE_DB']->create_table('league_fixtures',array(
			'id'=>'*AUTO', // Auto-incrementing key, so we don't have to assume that any particular date will only have one fixture on like we would if we made 'f_date' the key.
			'f_date'=>'TIME', // The date and time of the fixture. In ocPortal we store these as a "unix timestamp" (the number of seconds since 1970). This is nice because we can do calculations on it very easily, and it's system/software independent.

			// We will assume any fixture is played at "home" by one of the team's, and the team's don't share a home. It doesn't really matter, we could have called these fields "f_team_a" and "f_team_b" -- but I wanted to make it a bit clearer.
			'f_home_team'=>'AUTO_LINK', // An "AUTO_LINK" field type is a field type that points to an "AUTO" field, usually in another table. In this case it will be used for pointing to the 'id' value identifying a row in the 'league_teams' table. In database design this is called a "foreign key".
			'f_away_team'=>'AUTO_LINK',

			// The number of points to assign in the division standings. This essentially encodes the finished game's "score".
			'f_result_home_points'=>'?INTEGER', // "?" indicates the field may take a NULL value (meaning "unset"). For an unplayed game the value here will be NULL.
			'f_result_away_points'=>'?INTEGER',
		));
		
		
		// We don't have time to make an interface for adding/editing/deleting teams so for this example we're just going to hard-code some rows into the database inside this install function. The database can manually be edited to manage the teams.
		// We'll define it all in a big array structure, then go and insert that into the database.
		$default_teams=array(
			array(
				't_name'=>'Team Aardvark',
				't_division'=>'Little troopers',
				't_email_contact'=>'moo@example.com',
			),

			array(
				't_name'=>'Team Bacon',
				't_division'=>'Little troopers',
				't_email_contact'=>'oink@example.com',
			),

			array(
				't_name'=>'Team Double Cheese',
				't_division'=>'Little troopers',
				't_email_contact'=>'cholesterol@example.com',
			),
		);
		foreach ($default_teams as $team) // Go through each of the above 3 defined teams
		{
			$GLOBALS['SITE_DB']->query_insert('league_teams',$team); // Insert into the 'league_fixtures' table. This line of code is particularly simple as I structured the default data exactly in the same format as the database rows -- and hence it is a simple direct pass.
		}
	}

	/**
	 * Standard modular uninstall function. This function handles uninstallation of our module.
	 */
	function uninstall()
	{
		// If module is uninstalled we have to clean away our database tables
		// "drop_if_exists" is the only ocPortal function for deleting tables, and is named because it won't complain if you try and delete a non-existent table.
		$GLOBALS['SITE_DB']->drop_if_exists('league_teams');
		$GLOBALS['SITE_DB']->drop_if_exists('league_fixtures');
	}

	/**
	 * Standard modular entry-point finder function. This function lists all the 'type' codes that can be used to jump into this module and maps those codes to the name of a language string that entitles the nature of the screen that they access. The menu editor uses this function to make linking easy.
	 *
	 * @return ?array	A map of entry points (type-code=>language-code) (NULL: disabled).
	 */
	function get_entry_points()
	{
		return array('misc'=>'SHOW_STANDINGS','manage'=>'MANAGE_FIXTURES');
	}

	/**
	 * Standard modular run function. Every module has a 'run' function, which is called up when it is loaded as a page via a URL.
	 *
	 * @return tempcode	The result of execution. The result is returned back to ocPortal, which puts it between the panels etc.
	 */
	function run()
	{
		require_lang('leagues'); // Load up the leagues.ini language file, so we can use it's strings. We actually don't use this as much as we ordinarily would - for simplicity the templates have been hard-coded in English.

		if (is_guest()) access_denied('NOT_AS_GUEST');

		// Decide what we're doing. The 'type' parameter is conventionally used for this in ocPortal. 'misc' is the conventionally the default type if non is given, which is why most modules define one of the screens to be accessed via 'misc' (the most important one usually).
		$type=get_param('type','misc');

		if ($type=='misc') return $this->show_standings(); // This will show a standings table for each division in the league.

		if ($type=='manage') return $this->manage(); // This will provide an interface to manage all our teams.

		// This will actually save the data defined in the above 'manage' screen.
		if ($type=='_manage') return $this->_manage(); // Note how this was NOT in the get_entry_points() array. This is because it is not an entry-point -- it is not independant, it requires POSTed parameters to be sent (from the 'manage' screen).

		return new ocp_tempcode();
	}
						  
	/**
	 * Show the standings table for each division in the league.
	 *
	 * @return tempcode		The standings table
	 */
	function show_standings()
	{
		// Load up our screen title
		$title=get_page_title('SHOW_STANDINGS');

		// Read in our data
		$teams=$GLOBALS['SITE_DB']->query_select('league_teams'); // Read in all rows from the 'league_teams' table into $teams (which will be an array of rows, each row being an array map mapping field names to field values).

		// Go through the teams, organising them into divisions
		$divisions=array(); // We are building up $divisions as a map array mapping division names to a list of teams in that division.
		foreach ($teams as $team)
		{
			$divisions[$team['t_division']][]=$team; // We append another team onto the list of teams in the division this team is in.
		}

		// Simple maths to calculate a standings table for each division. We will put it in a nice structure suitable for the templating system (lots of upper case names that will get bound as template parameters when we go through the array's in our templates using Tempcode LOOP's).
		$standings=array();
		foreach ($divisions as $division=>$teams) // Go through each division
		{
			// Find out stats for each of our division's team, and prepare it in a nice Tempcode-ready structure (array)
			$template_ready_teams=array();
			foreach ($teams as $team)
			{
				// Read in stats for the team from the database
				// This is an SQL query that counts how many fixtures $team['id'] (the team we're currently looking at) has been involved with. "query_value_null_ok_full" is used to read in a single value from a database query, rather than returning a complex row structure like "query_select" does.
				$total_fixtures=$GLOBALS['SITE_DB']->query_value_null_ok_full('SELECT COUNT(*) FROM '.get_table_prefix().'league_fixtures WHERE f_home_team='.strval($team['id']).' OR f_away_team='.strval($team['id']));
				// These SQL queries sum how many points $team['id'] has earned.
				$total_points=0;
				$total_points+=@intval($GLOBALS['SITE_DB']->query_value_null_ok_full('SELECT SUM(f_result_home_points) FROM '.get_table_prefix().'league_fixtures WHERE f_home_team='.strval($team['id'])));
				$total_points+=@intval($GLOBALS['SITE_DB']->query_value_null_ok_full('SELECT SUM(f_result_away_points) FROM '.get_table_prefix().'league_fixtures WHERE f_away_team='.strval($team['id'])));

				$template_ready_teams[]=array(
					'TEAM'=>$team['t_name'],
					'TOTAL_FIXTURES'=>number_format($total_fixtures), // "number_format" makes a number into a string, using commas between groups of thousands so it looks nice. We aren't allowed to pass raw numbers into templates.
					'TOTAL_POINTS'=>number_format($total_points),
				);
			}
			
			// Sort the data. This is done using some special sort code ocPortal has available in it's API. It sorts based on 'TOTAL_POINTS' in the structure.
			global $M_SORT_KEY;
			$M_SORT_KEY='TOTAL_POINTS';
			uasort($template_ready_teams,'multi_sort');
			$template_ready_teams=array_reverse($template_ready_teams); // Top points go first, so we need to reverse the array to achieve that
			
			// Add the division to the standings structure
			$standings[]=array(
				'DIVISION'=>$division,
				'TEAMS'=>$template_ready_teams,
			);
		}

		// Pass all our data through a template called 'STANDINGS_SCREEN', mapping it to a parameter named 'STANDINGS'.
		return do_template('LEAGUE_STANDINGS_SCREEN',array('TITLE'=>$title,'STANDINGS'=>$standings));
	}

	/**
	 * The UI to add a bookmark.
	 *
	 * @return tempcode		The UI
	 */
	function manage()
	{
		// Basic security. We use our forum driver to check to see if the current user is staff. If they are not, ocPortal exits with a warning.
		if (!$GLOBALS['FORUM_DRIVER']->is_staff(get_member()))
			warn_exit('This is for staff only!'); // Normally we would use a language string, like warn_exit(do_lang_tempcode('SOME_LANGUAGE_STRING')) -- but I didn't for simplicity.

		$title=get_page_title('MANAGE_FIXTURES');

		// The form will save to this URL
		$save_url=build_url(array('page'=>'_SELF','type'=>'_manage'),'_SELF');

		// Build up a structure of all teams
		$teams=array();
		$team_rows=$GLOBALS['SITE_DB']->query_select('league_teams',NULL,NULL,'ORDER BY t_name');
		foreach ($team_rows as $team)
		{
			$teams[]=array(
				'TEAM_ID'=>strval($team['id']), // "strval" is to make it a string, but it shouldn't be "pretty" ("number_format") as it's going to be used by code (not for human reading)
				'TEAM_NAME'=>$team['t_name'],
			);
		}

		// Build up a structure of the current fixtures
		$fixtures=array();
		$fixture_rows=$GLOBALS['SITE_DB']->query_select('league_fixtures',NULL,NULL,'ORDER BY f_date'); // Load up all fixture rows, ordered by date
		foreach ($fixture_rows as $fixture)
		{
			$fixtures[]=array(
				'ID'=>strval($fixture['id']),
				'DATE'=>date('Y/m/d',$fixture['f_date']),
				'HOME_TEAM_ID'=>strval($fixture['f_home_team']),
				'AWAY_TEAM_ID'=>strval($fixture['f_away_team']),
				'POINTS_HOME'=>is_null($fixture['f_result_home_points'])?'':strval($fixture['f_result_home_points']), // If it is NULL convert it to a blank string, otherwise do a numeric conversion to a string.
				'POINTS_AWAY'=>is_null($fixture['f_result_away_points'])?'':strval($fixture['f_result_away_points']),
			);
		}

		// Add in 20 extra fixture rows to allow saving new fixtures
		for ($i=0;$i<20;$i++)
		{
			$fixtures[]=array(
				'ID'=>'', // We will program our code to recognise this blank value as meaning "new"
				'DATE'=>'YYYY/mm/dd', // Written like this so people understand how to fill it in
				'HOME_TEAM_ID'=>'',
				'AWAY_TEAM_ID'=>'',
				'POINTS_HOME'=>'',
				'POINTS_AWAY'=>'',
			);
		}
		
		// Pass all our data into the template "LEAGUE_MANAGE_SCREEN"
		return do_template('LEAGUE_MANAGE_SCREEN',array('TITLE'=>$title,'SAVE_URL'=>$save_url,'FIXTURES'=>$fixtures,'TEAMS'=>$teams));
	}

	/**
	 * The actualiser to add a bookmark.
	 *
	 * @return tempcode		The UI
	 */
	function _manage()
	{
		// Basic security again. This has to be applied here as well as for the 'manage' screen that is "in front of it" -- as a hacker could easily get here bypassing the 'manage' screen.
		if (!$GLOBALS['FORUM_DRIVER']->is_staff(get_member()))
			warn_exit('This is for staff only!');

		$title=get_page_title('MANAGE_FIXTURES');

		// Save, by going through POSTed data looking to see what there is. We don't normally access $_POST directly but it is good if we don't know what/how-many parameters are necessarily going to come through
		foreach ($_POST as $key=>$val)
		{
			if (substr($key,-strlen('_id'))=='_id') // If the POSTed field name ends '_id' then we have found an ID field representing a fixture, so we now move to analysing all details relating to this fixture, and then save in an appropriate way
			{
				$sequence_number=substr($key,strlen('fixture'),strlen($key)-strlen('fixture')-strlen('_id')); // POSTed field name is fixture<sequence_number>_id -- so this little extraction will get the sequence_number out from the middle.

				$id=$val; // Will be blank for a new fixture, otherwise it's the "league_fixtures" ID value of an existing row to edit/delete
				// Reading in the rest of the fields is very simple using the "post_param" API function...
				$date=post_param('fixture'.$sequence_number.'_date');
				if ($date=='YYYY/mm/dd') $date='';
				$hometeam=post_param('fixture'.$sequence_number.'_hometeam');
				$awayteam=post_param('fixture'.$sequence_number.'_awayteam');
				$pointshome=post_param('fixture'.$sequence_number.'_pointshome');
				$pointsaway=post_param('fixture'.$sequence_number.'_pointsaway');
				
				if ($id=='') // Adding
				{
					if ($date!='') // If it was actually filled in
					{
						$GLOBALS['SITE_DB']->query_insert('league_fixtures',array(
							//'id' will be auto-generated, as it's an auto-increment field
							'f_date'=>strtotime($date), // "strtotime" is a standard PHP function to change human-readable dates into unix timestamps. It is pretty clever.
							'f_home_team'=>intval($hometeam),
							'f_away_team'=>intval($awayteam),
							'f_result_home_points'=>($pointshome=='')?NULL:intval($pointshome),
							'f_result_away_points'=>($pointsaway=='')?NULL:intval($pointsaway),
						));
					}
				} elseif ($date!='') // Editing
				{
					$GLOBALS['SITE_DB']->query_update('league_fixtures',array( // Changes to make
						'f_date'=>strtotime($date), // "strtotime" is a standard PHP function to change human-readable dates into unix timestamps. It is pretty clever.
						'f_home_team'=>intval($hometeam),
						'f_away_team'=>intval($awayteam),
						'f_result_home_points'=>($pointshome=='')?NULL:intval($pointshome),
						'f_result_away_points'=>($pointsaway=='')?NULL:intval($pointsaway),
					),array( // Where clause
						'id'=>intval($id),
					));
				} else // Deleting
				{
					$GLOBALS['SITE_DB']->query_delete('league_fixtures',array( // Where clause
						'id'=>intval($id),
					));
				}
			}
		}

		// Send e-mails to all the teams
		$email_addresses=collapse_1d_complexity('t_email_contact',$GLOBALS['SITE_DB']->query_select('league_teams',array('t_email_contact'))); // Read from the database and use ocPortal's "collapse_1d_complexity" function to turn the complex database results into a very simple list
		require_code('mail'); // Our email API is in this file, which is not loaded up by default
		mail_wrap('Fixtures changed','Hello, the fixtures in the league system have now been changed.',$email_addresses); // This is very primitive. Really we need to send a fixture table to them, but there's no time to write this.

		// Say we're done
		return inform_screen($title,do_lang_tempcode('SUCCESS'));
	}

}


